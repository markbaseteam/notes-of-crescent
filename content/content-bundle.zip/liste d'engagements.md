#🌲 [[organisation]]
___
engagements|100%
--|--
[[blog]] |5%
[[Basson]]|75%
Rangement / [[evergreen note]]|10%
corps et santé|5%
trouver des trucs à faire en informatique|5%

Ma liste d'engagement répond à un besoin (qui semble être [autistique](autisme)) qui est de ce concentrer sur les choses les plus pertinentes.
## Archive d'engagements
philosophie / Psychologie
___
# Références
[The Commitment Inventory: Get More Done By Saying "No"](https://todoist.com/productivity-methods/commitment-inventory)