#☀️ [[vocabulaire allemand]]
___
die Figur ; le personnage
die Hauptfigur ; le personnage principal
die Nebenfigur ; le personnage secondaire
der Feind ; l'ennemi
die Haudlung ; l'intrigue
die Ausgangssituation ; la situation initiale
der Störfaktor ; l'élément perturbateur
der Held ; le héros
das Ziel ; le but
der Abenteuer ; l'aventure
der Ausgang ; le dénouement
die Lehre ; l'enseignement / la morale
das Szenario; le scénario
die Folge ; l'épisode
die Staffel ; la saison