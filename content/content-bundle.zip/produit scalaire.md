#☀️ [[Cours_maths]]
___
c'est la multiplication de deux vecteurs et le résultat est un nombre