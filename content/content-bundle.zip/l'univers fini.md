[[maths]] #☀️/cours
___
En probabilité, l'[[univers]] fini désigne le fait que l'on a un quantifié, on l'associe souvent à une expérience aléatoire