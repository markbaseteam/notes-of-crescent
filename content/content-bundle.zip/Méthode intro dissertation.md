[[méthode dissert]] #📝/cours 
___
L'intro comporte 4 étapes :
- Un préambule qui précise le contexte dans lequel la suestion se pose
- qui explicite les enjeux et donne les termes
- la problématique présentée sous la forme interrogative (direct ou indirect)
- l'annonce du plan qui met en évidence les rapports logiques entre les grandes parties
# exemple :
Selon vous, lorsqu'on lit un roman, cherche t'on à être diverti par des aventures extraordinaire ?
Problématique : Mais lorsqu'on lit un roman, cherche t-on uniquement à être diverti par des aventures extraordinaires ? Lit-on pour s'évader hors de la banalité de la vie réelle, ou au contraire pour retrouver la réalité et réfléchir à son sujet ?