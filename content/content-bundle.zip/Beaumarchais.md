[[auteur]] [[bac_français]]
___
**Pierre-Augustin Caron de Beaumarchais** est un écrivain et un dramaturge français du 18° siècle. Il est une figure majeure du siècle des Lumières ; il est espion et marchand d'armes pour le compte du roi. Il est considéré comme l'annonciateur de la révolution française tant il ne paraissait jamais désarmé face à l'adversité ; il défend la liberté et écrit dans *le mariage de figaro* : 
- Sans la liberté de blâmer, il n'est point d'éloge flatteur, il n'y a que les petits hommes qui redoutent les petits écrits
___
# Référence
[Wikipédia](https://fr.wikipedia.org/wiki/Pierre-Augustin_Caron_de_Beaumarchais)