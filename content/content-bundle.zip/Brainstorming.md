[[méthode]] #📥 
___
Le brainstorming est le fait de prendre 20 idées pour résoudre un problématique. Les 5 premières sont faciles, les 5 suivantes sont compliquées et les 10 dernières sont extrêmement compliqués à trouver.