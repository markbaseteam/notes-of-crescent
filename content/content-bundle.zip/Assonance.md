[[français]] [[bac_français]] [[figure de style]]
___
répétition de voyelles dans un groupe