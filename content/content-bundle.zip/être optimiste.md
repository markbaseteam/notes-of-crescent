[[motivation]]
___
1. Apprendre tout le temps des choses sur le sujet qui nous intéresse
2. Essayer le plus possible quelque chose d'intéressant
3. Être le plus perceverant possible
___
# Référence
[L'ESSENTIEL POUR DEVENIR MILLIONNAIRE | Brian Tracy | Partie 3/3 - YouTube](https://www.youtube.com/watch?v=felTEJAt5fU&t=16s)