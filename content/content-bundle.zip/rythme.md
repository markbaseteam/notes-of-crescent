[[Formation musicale]]
1. Mise en place de la battue
2. Croche = croche
3. Être une boule d'énergie, dynamique
4. Dire les rythmes sur *ta*
5. Essayer avec clic **la pulsation est un rebond**
6. Quart de soupir attrapé nigauds