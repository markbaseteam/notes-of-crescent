[[auteur]] [[bac_français]]
___
Marie Gouze (dite Olympe de Gouges) est une autrice du 18°, elle est devenue une femme politique (ce qui extrêmement compliqué à cette époque)

Elle est contre la terreur et pour Robespierre et comme de nombreux Girondins sera exécutée. Elle a aussi écrit des pièces de théâtre qui sont des réquisitoires contre l'esclavage. Comme la révolution française donne des droits aux citoyens mais pas aux citoyennes, elle réécrit la DDHC et propose une DDFC pour défendre la cause des femmes, cette déclaration sera placardée sur les murs de Paris. Il s agit d une oeuvre inclassable qui s'adresse a la reine MA, les hommes, l'assemblée et les hommes. Sur un ton de défie elle remet en question la domination masculine pour démontrer son illégitimité en fondant son argumentation sur l'exemple donne par la nature. Ce préambule se rattache a la fois au genre de l'essai par sa moralité et met en scène la confrontation de Olympe de Gouge avec un interlocuteur masculin.
___
# Référence
[Wikipédia](https://fr.wikipedia.org/wiki/Olympe_de_Gouges)