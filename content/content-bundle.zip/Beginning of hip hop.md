[[Anglais séquence Activism]] [[compréhension ecrite]] #📥 
___
1. African and Latino teenagers, and many of these found a job as DJ in discos
2. The master of ceremony make a better feeling and flow with the music. 
3. With some MC encourage to talk with the beat of the music ; it's make rap. The rap is an issue with the stress there was in theirs streets. 