#📥 [[MOOC_Ecriture]] [[poeme]]
___
# Idée
saint d'esprit et saint de corps -> éviter la fatigue