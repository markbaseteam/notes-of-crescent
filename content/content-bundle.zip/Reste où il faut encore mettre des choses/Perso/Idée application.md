Une application qui calcule en fonction de n'importe quelle fraction et qui repartie pour le nombre de douche, qui peut mettre un report. 
Elle pourrait aussi arrêter les addictions en répétant des phrases, en résonnant avec des citations. 

On pourrait le faire sous forme de modules communautaires. 

Programmer visuellement dans l'application, et pour les développeurs ils voient sous forme de code et pourront ajouter des fonctionnalités qui ne sont pas encore visualisés.  