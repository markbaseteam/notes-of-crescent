#🏷️/cours 
___
# [[Taches_Allemand]]
[[Verbes forts]]
[[Allemand woher oder wohin]]
[[allemand voca expression orale]]
[[all Fiction et réalité]]
[[all_verbes de modalité]]