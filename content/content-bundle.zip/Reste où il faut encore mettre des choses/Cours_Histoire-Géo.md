#🏷️/cours [[histoire-géo]]
___
# [[taches_Histoire-Géo]]
[[méthode_question_problématisée]]
[[Géo des paysages ruraux en transformations]]
[[Grille histoire]]
[[H3 1]]