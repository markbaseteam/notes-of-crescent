#🏷️/cours 
____
# [[Taches_Physique-Chimie]]
[[Formation des ions et des molécules]]
[[Cohésion des liquides et des solides 18-03-2022]]
[[Tableau_périodique_des_éléments.svg]]