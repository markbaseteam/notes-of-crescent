[[auteur]] [[bac_français]]
___
Molière, grand dramaturge du XVII° siècle, est l'auteur de très nombreuses farces, de comédies-ballets et de grandes-comédies (*Le Tartuffe ; Le Misanthrope et d'autres...*).
Il a formé la troupe de *L'illustre théâtre* mais ne parvient pas à s'imposer à Paris ; il parcoura pendant 12 ans (1646-1658) les provinces du sud (méridionales) du royaume. Au sein de cette période la troupe est entretenue par plusieurs protecteurs successivement, Molière va écrire des petites comédies et farces ainsi que ses deux grandes premières comédies.
L'une d'entre-elle, Le malade imaginaire (1673) se veut être à la fois une farce satirique et une comédie-ballet mais avec des accents dramatiques. à l'image de ce que Molière voulait faire puisque c'est un grand créateur de formes dramatiques. il s'agit de la dernière pièce de Molière (ce dernier s'évanouira sur scène lors de 4° présentation et mourra chez lui).
___
# Référence
[Wikipédia](https://fr.wikipedia.org/wiki/Moli%C3%A8re)