[[Compréhension oral]] #📥/cours
___
*Spiederman ist jetzt entarvt: Farst zu zweit die Szene zusammen und uberlegt euch, wie es weitergehen konnte*
Schreibt in der Vergangentieitsform 

- Spiderman helftet die Lauten. Spiederman habt gefallt im Apfel. Spiderman war ein Star aber es enterlarvt war.
- Spiderman habt gegangen ([[Verbes forts]]) zu sehen Tante May. Er wollt zu essen Cookies, und zu schlafen. Spiederman ist habt ungewöhnlichen Rhythmus, und er herumlauft. Der nächste Tag, Spiderman war noch müde. Die Straßenräuben [pillent] das Bank. Tante May wollte aufwecken Spiderman, damit er im Bild [crash]. Odin sendt in im [son royaume]. Odin sagt [lui] d'assumer ses responsabilités.