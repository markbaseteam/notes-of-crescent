
# Woher und wohin
- tache finale : discours où on présente une migration
Die Heimat = lieu où on se sent chez soi (pays d'origine, natal, d'acueil, ville)

[[vocabulaire woher und wohin]]
[[allemand compréhension écrite]]
[[allemand_expression écrite]]