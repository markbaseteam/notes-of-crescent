[[Black Lives Matter]]

---
# Compréhension orale 
1. 
	august 1963 including civil rights activist, tweet 100 cities
	key difference is the instrument and use together to peace : ==internet== or ==with phones== 
	organasing the mouvement. in a presse -> much faster. 
	self, very fly
2. 
	- 250.000 people marched on Washington (in August) in 1963
	- Today more than 50 years later, there seems to be a new scene of urgency
	- They were protests in over 100 cities that happened since 1965
5. 
60's (Dr.Carson)|BLM
--|--
telephone, the press|internet
w.a.t.s|twitter
face to face|
7. One big key difference is how the use of technology has been an instrumental tool in bringing folks together at a pace that really was unheard of in 60's.
8. That's still happening today the only thing that's difference is that's much faster
9. One big key difference is how appreciative of the fact whenever young people are concerned about things other than themselves, that's a positive sign. I think he would've been very, very open to using social. He would have had millions of followers on Twitter
10. 