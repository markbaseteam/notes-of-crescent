[[bac_français]]
a. "Tu lis les prospectus les catalogues les affiches qui chantent tout haut"
==nombre de propositions== -> nombre de verbes : 2 
-> [==nature proposition(s)==] -> regarder mots, *ou si il y a une virgule* -> pronom relatif ==donc== subordonnée relative
==Ce qui fait que l'autre proposition est== la principale, *ou juxtaposée*.

b. "Seul en Europe tu n'es pas antique ô Christianisme" **[[négation]]** :
**répérer** : n'es pas
**analyser** : totalle car si on supprrime on a une affirmative

c. "Fugitive beauté dont le regard m'a fait soudainement renaître, ne te verrais-je plus que dans l'éternité ?" **[[interrogation]]**
interrogation direct, totalle. 



