## Yasmine : Chelsea Manning
accès à des fichiers hautement sécurisé. 
- 2007 entrée dans l'armée
- 2009-2010 rassemble des informations 
- contact avec Wikileaks
- accusé de 22 infractions
- récompensé pour le prix pour la paix
## Edward Snowden
informaticien -> engagé dans l'armée ; ensuite NSA, ensuite CIA. La NSA peut prendre des données sur des millions de personne, il a extrai une quatité de données énorme, surveillance web des téléphones portables et systèmes d'écoutes. S'exile à Hong-Kong puis en Russie ; 22 octobre 2020 titre résidence permanente en Russie. 
## Chloé : Jeffrey Wigand
Dans le domaine de cigarette, le deuxième poste en rapport avec la chimie et il s'est rendu compte qui faisait de gros dégats sur le cerveau ; viréé puis menacé par le directeur, et en particulier sur ça fille. il a refusé de parler pendant de long années ; re-menacé, quitté par sa femme. Il enseignera le japonais au lycée, mais l'entreprise l'a discrédité mais ça n'a pas marché. Ils ont juré sur l'honneur qu'ils ne connaissaient pas les dégats que le produit faisait. interview. 
## Candice : Frances Haugen
Elle travaillait chez Facebook et révèle les "Facebook Papers" ; Facebook a modifié ses algorithmes, mais met en avant des contenus violents. Médias qui veulent provoquer les engagements. 
## Andrea : Erin Brokovich
Autodidacte, Etats-Unis, participee à un concours de beauté ; a eu plusieurs divorces, au chomage, a trois enfants. A été victime d'un accident, a perdu le procès. Elle enquête sur *Pacific gaz & electric  Company* et particulièrement sur un produit qui cause le cancer de poumon et probablement la mort. 600 familles soit 33 millions ont été infecté. Un film a été fait et elle a obtenu un oscar. 