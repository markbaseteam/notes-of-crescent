#🏷️/cours 
# Hashtag Activism
## Problematic
How has Black Lives Matter paved the way for new forms of protest ? 
## Final Task
**EOI :** *Debate* -> on some of the Black Lives Matter issues 
- clair
- bien s'exprimer
- variété de formulations
### Liste de cours
[[anglais compréhension oral 4-3-2022]]
[[anglais_analyse_poster 7-4-2022]]
[[anglais info]]
[[anglais_compréhension oral 14-3-2022]]
[[angl_would_21-4-2022]]