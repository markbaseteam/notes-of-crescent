[[inutile]]
____
# Travail d'écriture 
- Oh monsieur vous auriez fait ce dessein si bien réfléchi ? Et avec votre maladie vous voudriez marier votre fille à un médecin ?
- Oui. Je m'intéresse à vos avenirs
- Oh fort bien, j'ai pu sentir de tout mon corps votre dévouance. La raison est claire. 
- Voilà mes raisons et j'ai du plaisir à vous entendre dire ça, et à vous répondre doucement. En tant que malade je dois me faire allié des médecins et être proche de la médecine.
- "
-  "
- [...] il est nécessaire de 
- "