# [[Would]]
## 3 p.45
a. have shown
b. organize
c. have used
d. have spread -> **irréel**