[[Compréhension oral]] #☀️ 
___
## Oral presentation
- Clara : 
	- lastest
	- the best
	- the big
	- good
	- magical
	- beauty
	- incredible
# Compréhension oral
- ==people== lot of black peoples, young people, user of twitter
- ==evolution== organisation with network, more people and young people
- ==objectives== respect, fight the racism
Travyon Martin an unarmed 17 afro-americaan boy *was killed* by the policeman ==who== *was* later acquitted.
[[Black Lives Matter]] *started* with a post on Facebook from Alicia Gurza, ==wich== *was commented* by Patrisse Cullers on Twitter and it *became* viral thanks to young people on social networks. Their objectives *are* to fight for justice, for rights, to make people aware of what is happening in order to stop the problem. 