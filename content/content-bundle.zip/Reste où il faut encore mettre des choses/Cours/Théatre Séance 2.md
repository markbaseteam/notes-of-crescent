#📝/cours  [[Français_théâtre 17°]]
___
5) Quelles sont les deux intrigues principales qui se mettent en place dans l'acte I ?
Le premier acte correspond à l'exposition et à la mise en place des deux intrigues principales qui sont fortement liées : la maladie imaginaire d'Argan et les amours d'Angélique. Angélique confie son amour pour Cléante à Toinette qui promet de l'aider, et Béline manoeuvre aidée de son notaire  afin de capter l'héritage d'Argan.
6) L'acte 2 laisse en arrière plan la médecine pour se concentrer sur les amours d'Angélique. L'amoureux Cléante apparait à la scène 1 déguisé en maître de chant et reste jusqu'à la fin de la scène 5 où il est mis en présence de son rival Thomas Diafoirus. Les Diafoirus père et fils sont présent aux scènes 5 et 6.