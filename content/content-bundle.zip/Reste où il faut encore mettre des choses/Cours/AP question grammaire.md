[[bac_français]] 
# Interrogation
"Blaise, dis, somme-nous bien loin de Montmartre ?"
[[interrogation]]
interrogation direct (inversion + ?) et totale

Ce vers revient dans La prose du Transibérien est posé par Jeanne ou Jehanne. tonalité ascendante crée une sorte de décalage au sein du poème, qui vient s'intercaler dans le déploiement de l'imaginaire du poète. Elle contient 2 verbes ("dis" impératif présent à valeur de demande, et "sommes" au présent de l'indicatif). Donc 2 propositions réliées par une virgule -> juxtaposées. Comprend 2 tonalités différentes. S'il s'agit bien d'une phrase interrogative, on remarque néanmoins la présence de cette première proposition avec un verbe à l'impératif. Elle pourrait exprimer ici une prière un souhait voire un ordre. Elle donne un éventail de possibilités d'interprétations au lecteur.

# Négation
"Il n'y a plus que des cendres continues."
[[négation]]
négation partielle

# Syntaxe
"Le monde s'étire, s'allonge et se retire comme un accordéon qu'une main sadique tourmente"