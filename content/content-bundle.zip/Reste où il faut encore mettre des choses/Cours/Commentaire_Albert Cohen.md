[[fiches-methode-commentaire-Magnard.pdf]] [[cours_Français]]

---
# Albert Cohen
#### 1. Lecture du paratexte 
- roman et recit 
- Albert Cohen, Le livre de ma mère
- 1954 (20°), surréalisme
- L'auteur évoque sa mère défunte 
#### 2. Lecture du passage
- Albert Cohen se culpabilise sur les reproches de sa mère.
- roman autobiographique
- narratif
- monologue
### 3. Relecture + Analyse
##### Méthode 1 :
Procédés d'écriture|citations+lignes|Analyse et interprétation|Idées
-|-|-|-
pronom personnel "je"|début|point de vue interne, l'auteur est centré sur lui-même|nous invite à se pencher sur ça situation
cod me + répétition de chanson|début|on répète tout ce qui est autour de la berceuse, on s'attache à la chanson dont parle l'auteur ; contraste avec la mort|
personnification|a posé..glace|terrifiant
répétition du son "s"|sanglot..sortir|auteur terrifié
hyperbole lyrique, tragique|je me dis..colères|on a l'impression que la mort est passé et elle a pris beaucoup pour l'auteur
### Problématique
### Plan détaillé