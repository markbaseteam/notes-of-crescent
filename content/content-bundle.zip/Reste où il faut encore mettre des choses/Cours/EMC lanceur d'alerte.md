[[Cours_EMC]]
# Définition
Le lanceur d'alerte est un citoyen (physique), agent publique ou salarié. Signalant ou révélant, une grave atteinte à l'intéret général. 
La loi Sapin 2 exclu donc de la définition et par conséquent du régime général de protection les personnes morales (associations, entreprises ...)
### Prise de note vidéo Cyrus North
Cia : espion 
Wiki leaks -> créer débat
récent : personne ou groupe menace pour toute la population -> souvent anonyme 
date de 1990
exemple bombe nucléaire 
vision différente en France
loi sapin 2 : incomplète

## Comment lancer une alerte ?
Dans le cas d'une alerte effectuée dans le cadre du travail, la protection du salarié garantie par la loi dépend du respect d'une procédure de signalement à 3 paliers - sauf en cas de danger grave et imminent. Dans le cas d'une alerte hors du cadre du travail, la lio ne prévoit pas de procédure obligatoire. Toutefois, pour être protégé, le citoyen doit agir de manière responsable. 
[schéma]
[[EMC_prise de note]]