#☀️ 
___
# Spielen
## Présent
Ich spiele
Du spielst
Er, sie, es spielt
Wir spielen
Ihr spielt
Sie spielen
## Prétérit
spielte
spieltest
spielte
spielten
spieltet
spielten
## Passé composé
habe gespielt
hast gespielt
hat gespielt
haben gespielt
habt gespielt
haben gespielt
