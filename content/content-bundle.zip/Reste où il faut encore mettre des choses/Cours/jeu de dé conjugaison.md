[[all conjugaison]]
## Présent
- Er spielt
- Ihr lernt
- Sie suchen
- Wir lernen
- Wir machen
## Prétérit
- Wir brauchten
- Ich spielte
- Ihr arbaitet
- Sie spielten
- Wir arbeiteten
- Wir brachten
## Passé composé
[[Verbes forts]]
- Ich habe gemacht
- Du habst gelernt
- Ich habe gelernt
- Sie haben gearbeitet