5) Quelles sont les deux intrigues principales qui se mettent en place dans l'acte I ?
Le premier acte correspond à l'exposition et à la mise en place des deux intrigues principales qui sont fortement liées : la maladie imaginaire d'Argan et les amours d'Angélique. Angélique confie son amour pour Cléante à Toinette qui promet de l'aider, et Béline manoeuvre aidée de son notaire  afin de capter l'héritage d'Argan.
6) L'acte 2 laisse en arrière plan la médecine pour se concentrer sur les amours d'Angélique. L'amoureux Cléante apparait à la scène 1 déguisé en maître de chant et reste jusqu'à la fin de la scène 5 où il est mis en présence de son rival Thomas Diafoirus. Les Diafoirus père et fils sont présent aux scènes 5 et 6.
7) Angélique se trouve dans une situation critique elle a écondui le fils Diafoirus, mais a été trahi par Belline. La dernière scène fait intervenir heureusement Berald qui lui sera d'une aide précieuse.
8) Toinette est un personnage clé comme tout les personnages de comédie qui va aider Angélique :
	- ***I,4,8*** elle reçoit les confidences d'Angélique et lui promet son aide
	- ***II,1*** elle acceuille Cléante déguisé en maitre de chambre
	- ***III,2*** elle s'assure de l'aide de Berald pour contrer le projet de mariage entre Angélique et Thomas Diaffoirus.
	- C'est Toinette qui assure la transition entre ***l'acte I et II*** *(sérénade chanté par Polichinel)*
	- C'est Bérald (frère du père) qui assure la transition entre ***l'acte II et III*** en offrant à son frère le spectacle des "Egyptiens" *(bonian, gitans, etc...)*
9) ***L'acte III*** poursuit la satyre des médecins avec les entrées successives de *M. Fleurent et M. Purgon*. 
	- Ceci sont définitivement écartés par Toinette déguisée en médecin. 
Les ***intrigues*** s'acheminent vers leurs résolutions grâce au stratagème de Toinette soutenu par Bérald. 
	- L'intrigue amoureuse obtient son heureux dénouement, 
	- l'hypocrite Belline est démasquée et Argan décidémant incurable se trouve délivré des médecins parasites pour en devenir un lui-même au cours de la cérémonie : spectacle finale. 