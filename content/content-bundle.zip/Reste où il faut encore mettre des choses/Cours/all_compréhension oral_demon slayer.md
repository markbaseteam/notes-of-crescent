1. Tanjiro
2. Nezuko, Die Familie, Tomioka (Dämonenjäggen)
3. Tanjiro verkauft Kohle
4. Seine Familie wurde getötet/gefresst
5. Tanjiro möchte seine Schwester retten
	kemfen -> se battre
	Hopvol -> bien que
Den demonenjegger  lesst die beiden leben
8. 
	1. Man muss start sein, um seine Angetörige zu helfen/retten
	2. Bitten funktionniert manchmal nicht
	3. Man muss vertrauen (faire confiance)