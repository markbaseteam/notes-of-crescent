#📝/cours 
___
# Mort de Molière
comédien : excommunié -> pas de mariage...
Molière tombe très malade avec bactérie de la tuberculose
-> 4° payé 
pas mort sur scène -> mort par hémoragie lente ; personne n'est venu, mort avec la troupe
les révolutionnaires 
# La comedia del' arte
humanisme : concentration sur les hommes -> masculinité des comédiens
tragédie avec une fin heureuse
situations stéréotypés, seul personnages amoureux n'avaient pas le visage masqué
- Arlequin et Polichinel
- Roméo et Juliette
- forger caractère des marionnette
- inspire Pierre Cornel ou Molière 
Goldoni oblige à respecter le texte en éliminant les masques et confère une individualité
- influence le cinéma 
# Le classicisme
Après l'exubérence du baroque, on fonde qlq chose sur la raison, mais pas forcément sur le vrai.