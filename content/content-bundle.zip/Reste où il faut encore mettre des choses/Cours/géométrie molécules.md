[[Formation des ions et des molécules]] #☀️ 
___
- tétraédrique
- pyramidale
- condée