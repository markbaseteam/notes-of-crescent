# Compréhension oral Simpson
## Questions
- Wo kann Lisa nach Homer den Unterricht schreiben ?
- Was darf Bart im Unterricht benutzen ?
- Wo müssen Milhouse und Lisa morgen gehen ?
- Will Lisa den Stift (=stylo) von Milhouse ?
- War möchte Homer ?
- Was soll Homer machen, um reich zu werden ?
