
## Text 1
**Michael Brown** *is*  an 18 years old victim, *killed* by a **police officer**. This unarmed innocent man ==who== *surrendered* (*se rendre*), *was murdered* ==because== of his skin color in an aggressive way and left alone in an awful way in the streets for hours. 
## infographic
1. The 13th of july in 2013
2. The 7th of july in 2016 *incidents with police officers*
3. 3.7 million
The document is a **graph** published by Pew Research Center after **May 2018** ==representing== the **use** of the # Black Lives Matter on Twitter. 
[[Black Lives Matter]]
