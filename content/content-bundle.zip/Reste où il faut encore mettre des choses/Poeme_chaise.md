[[poeme]] #📥 
___
# Chaise
Il était une fois une chaise
Qui n'intéresse personne, bien qu'on en ait souvent besoin
Les gens ont oublié à quoi ça sert une chaise
Si ce n'est quelques mots d'opposition

Qui dans un lycée n'inspire rien à personne
Pourtant elle semble nous dire je suis la parce que tu dois rester en cours
Une chaise ça sert pas à rester toute la journée dessus, ça sert à servir une période de réflexion
Toute une journée assis sur une seule chaise, on se bousille la santé. 
Finalement la chaise c'est quelque chose qui pour la plupart des gens, ne doit pas être important parce que si ça l'est ça veut dire qu'il faut passer à autre chose
