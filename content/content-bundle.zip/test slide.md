
<section>	<a href="#/grand-finale">Go to the last slide</a></section>
<section>	<h2>Slide 2</h2></section>
<section id="grand-finale">	<h2>The end</h2>	<a href="#/0">Back to the first</a></section>
