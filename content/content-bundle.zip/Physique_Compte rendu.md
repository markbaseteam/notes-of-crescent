 [leçon] [[Schéma circuit TP physique]]
 ___
I (mA)|I (A)|$U_R(v)$
--|--|--
340|0.34|3
460|0.46|4,5
610|0,61|6
760|0.76|7,5
910|0.91|9
1210|1.21|12
# II
7. L'allure du nuage de point est proportionnelle
9. D'après le document, on sait que $U=R \times I$, et on voit sur le logiciel près de la droite que $U= a \times I$.La résistance du résistor a alors la même valeur que le coefficient directeur de la droite, soit $\Omega = 9,69$.
11. 
I(A)|U(V)
--|--
0,39|3,7
0,59|3,22
0.90|2,7
1.13|2,2
1,3|1,8
1,6|1,2
2,1|0,126
16. C'est une droite décroissante qui ne passe pas par l'origine. On a $a$ (coefficient directeur) et $b$ (ordonné à l'origine), le coefficient directeur est négatif car la droite descend. Par identification on voit que $a$ est toujours équivalent à la résistance et $b$ est donc égal au volt.
18. La force électromotrice du générateur est égale à 4,51V et la résistance interne vaut $-2,08 \Omega$.
# III
19. 