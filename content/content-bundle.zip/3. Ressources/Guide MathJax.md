#⚙️ 
[MathemaTeX - Guide MathJax](https://www.mathematex.fr/guide-mathjax)
https://math.meta.stackexchange.com/questions/5020/mathjax-basic-tutorial-and-quick-reference
- [ ] écrire rho [[Chimie et Physique_ Energie électrique]]
[MathJax - Tex : guide pratique, aide-mémoire](https://www.sqlpac.com/fr/documents/mathjax-tex-guide-pratique-aide-memoire.html)
