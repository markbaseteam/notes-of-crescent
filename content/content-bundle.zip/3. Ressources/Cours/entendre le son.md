#☀️/cours  [[Enseignement Scientifique]] [[svt]]
___
# Entendre le son
L'etre humain perçoit le monde 0 l aide de signaux dont certains sont de nature sonore. De l antiquité jusqu a nos jours, il a combiné les sons de manière harmonieuse pour en faire un art, la musique, qui entretient des liens privilégiés avec les mathématiques. L'informatique permet de numériser le sons et la musique.
## Du son à la  sonore
### L'oreille et la transformation du son
[schéma oreille]
L'oreille externe canalise les sons du milieu extérieur vers le tympan. Cette membrane vibrante transmet ces vibrations jusqu'à l'oreille interne par intermédiaire de l'oreille moyenne. L'etre humain peut percevoir des sons de niveaux de l'intensité approximativement compris entre 0 et 120 dB. Les sons audibles par les humains ont des fréquences comprises entre 20 et 20 000 Hz.
[[schéma 2 du son à la perception sonore.jpg]]
### Les cellules ciliées et l'oreille interne
Dans l'oreille interne, des structures cellulaires (cils vibratiles) entrent en résonnance avec les vibrations reçues et les traduisent en un message nerveu qui se dirige vers le cerveau. Les cils versatiles sont fragiles et facilement endommagés par des sons trop intenses. Les dégâts sont irréversibles.
[[Schéma aires de l'audition.jpg]]