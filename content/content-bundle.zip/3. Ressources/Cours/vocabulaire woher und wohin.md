#☀️ [[vocabulaire allemand]]
___
- die Wurzel ; l'origine
- das Ausland ; pays étrangé
- der Auslander ; personnne étrangère
- zurückkehren ; revenir
- sich heimisch fühlen ; se sentir chez soi
- verlassen ; quitter
- ausreisen ; quitter le territoire
- erzählen ; raconter
- landen ; attérir
- aufnehmen ; héberger
- die Verbindung ; la connexion / le lien
- zügehören ; appartenir à
- immigrieren / einwandern ; immigrer
- der Immigrant(in) / der Einwardeen(in) ; l'immigré