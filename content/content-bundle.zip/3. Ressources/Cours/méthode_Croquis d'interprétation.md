[[Cours_Histoire-Géo]]
___
- commencer par la légende [[items croquis d'interprétation]]
- déqualquer
- colorier