#☀️ [[conjugaison]]
___
# Le passé
## Prétérit
==radical + t + terminaison==
- La première et la troisième personne du singulier ont la même terminaison
## Passe composé
==AUX conjugué ge + radical + t==
[[all conjugaison]]
