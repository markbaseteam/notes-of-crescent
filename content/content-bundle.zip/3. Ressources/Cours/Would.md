[[conjugaison]]
___
# Utilisation dans le [[passé.jpg]]
- habitude dans le passé -> **BV**
	- When I was 9, every day, we would **buy** sweets.
		- ==Sujet + *would* + **BV**== 
- formule de politesse
	- Would you like some tea ?
- irréel *passé ou pas* -> ***present perfect*** -> ==Sujet + *would* + ***present perfect***
	- I think Dr.King would **have** ***been*** appreciative
							- would **be** very appreciative
## Irréel dans le présent
- I would **love** my pupils to do their HW.
	- ==Sujet + *would* + **BV**==