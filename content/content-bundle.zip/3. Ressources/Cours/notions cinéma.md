[[Grille histoire]]
[[notions-cinéma.pdf]]
**Les travelling**

https://transmettrelecinema.com/video/le-travelling/

**Flash-back et flash-forward**

https://www.youtube.com/watch?v=gOlPtxjSizM

**Le son au cinéma**

https://www.youtube.com/watch?v=MrlDeqQDLU4

==Insert==
Truc qu'on voit dans l'extrait qui nous donne des indications sur ce qui va se passer après -> attitude de Octave Mouret + réaction madame Hédoin