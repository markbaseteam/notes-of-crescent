[[cours_Français]]

---

- *partielle* 
- *totalle* : si on supprime la négation la phrase est affirmative ; ==sinon== si on garde une restriction -> **partielle**