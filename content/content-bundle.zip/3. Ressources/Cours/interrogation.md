[[11 étude linéaire molière]] #☀️ 
___
1. - *interrogation direct* : inversion + point d'interrogation
2. - *interrogation totale* : on peut répondre par oui ou oar non ; sinon ***interrogation partielle***
- *question rhétorique* :  réponse évidente 