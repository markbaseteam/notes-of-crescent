[[GTD/Organisation]] #🌲
____
Les liens sur obsidian peuvent se faire de différentes manière :
- [[lien]] -> Sert quand on peut faire une liste d'un sujet [[moc]]
- [[tags]] Sert quand une liste sur le sujet serait infinie
- [[Liens qui mènent vers des notes inexistantes]] 
	On peut faire quelque chose entre lien et tag avec ==quelque chose de large / qui n'a pas de limites== 
- [[Dossier]] Sert quand on veut partager avec la classe
- [[Liens vers fichiers]] avec [[plugin_Annotator]] fichiers utilisé dans une "note spéciale".