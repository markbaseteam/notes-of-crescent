# Was bringen Fiktionen für dein Leben ?
Ich denke, dass wir Fiktionen im Leben können. Ich denke ,dass wir leben manchmal im Fiktionnen konnen. Das Gewissen ist wichtig.

- Forrest Gump bringt mir das. 