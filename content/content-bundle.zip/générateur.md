#☀️ 
___
Produit de l'énergie électrique et thermique, fonction affine et décroissante [[coefficient directeur.jpg]]
$U=E-r \times I$
donc équivalent à en multipliant par $I$ $$U \times I =E \times I - r \times I \times I$$
$$Pélect = E \times I - r \times I^2$$