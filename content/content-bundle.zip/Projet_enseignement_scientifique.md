---
enableLinks: true
---

[[Enseignement Scientifique]]
---
## Comment le bruit impact la fréquence cardiaque et par intermédiaire le stress ?
%%surligner trucs qui se passent%%

---

## Définir
- [le stress](obsidian://open?vault=second_cerveau&file=le%20stress)
- [la fréquence cardiaque](obsidian://open?vault=second_cerveau&file=la%20fréquence%20cardiaque)
---
### Pourquoi ?
[[Pourquoi le bruit cause du stress]]

---
#### Qu' est-ce qu'il se passe quand il y a du stress?
- [[expérience cardiaque]]
- [[l'impact quand il y a du stress sur la fréquence cardiaque]]