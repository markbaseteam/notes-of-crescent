#📝/cours [[11 étude linéaire molière]]
___
1 étape introduire l'oeuvre ([[Le barbier de Séville]])de façon syntétique :  1 minute 30
- Auteur, oeuvre, ça date de parution le genre littéraire et les éventuelles conditions d'utilisation. Résumer la structure de l'oeuvre (lieux important, personnages, évolution de l'intrigue, étapes du réçit ou du raisonnement)
- Synthèse des enjeux esthétiques moraux ou politiques relatifs à l'objet d'étude représenté par l'oeuvre (rapprochement entre l'intitulé de l'objet d'étude et la problématique)

2° étape justifier son choix en laissant s'exprimer votre sensibilité et à l'aide d'arguments.
3° étape dialoguer avec le jury 5 minutes