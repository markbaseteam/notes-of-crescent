---
annotation-target: textes_oral_bac.pdf
---


>%%
>```annotation-json
>{"created":"2022-06-21T12:43:03.411Z","text":"adverbe de temps","updated":"2022-06-21T12:43:03.411Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":5885,"end":5892},{"type":"TextQuoteSelector","exact":"D’abord","prefix":"rs : INDIVIDU, MORALE ET SOCIÉTÉ","suffix":", ce fut comme un étourdissement"}]}]}
>```
>%%
>*%%PREFIX%%rs : INDIVIDU, MORALE ET SOCIÉTÉ%%HIGHLIGHT%% ==D’abord== %%POSTFIX%%, ce fut comme un étourdissement*
>%%LINK%%[[#^s1id1i3gz2|show annotation]]
>%%COMMENT%%
>adverbe de temps
>%%TAGS%%
>
^s1id1i3gz2


>%%
>```annotation-json
>{"created":"2022-06-21T12:43:50.045Z","text":"[[comparaison]]","updated":"2022-06-21T12:43:50.045Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":5901,"end":5906},{"type":"TextQuoteSelector","exact":"comme","prefix":"ORALE ET SOCIÉTÉD’abord, ce fut ","suffix":" un étourdissement ; elle voyait"}]}]}
>```
>%%
>*%%PREFIX%%ORALE ET SOCIÉTÉD’abord, ce fut%%HIGHLIGHT%% ==comme== %%POSTFIX%%un étourdissement ; elle voyait*
>%%LINK%%[[#^84ivcyr51d|show annotation]]
>%%COMMENT%%
>[[comparaison]]
>%%TAGS%%
>
^84ivcyr51d




>%%
>```annotation-json
>{"created":"2022-06-21T12:51:13.063Z","text":"énumération","updated":"2022-06-21T12:51:13.063Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":5938,"end":5987},{"type":"TextQuoteSelector","exact":" les arbres, les chemins, les  fossés,  Rodolphe,","prefix":" un étourdissement ; elle voyait","suffix":"  et  elle  sentait  encore  l’é"}]}]}
>```
>%%
>*%%PREFIX%%un étourdissement ; elle voyait%%HIGHLIGHT%% ==les arbres, les chemins, les  fossés,  Rodolphe,== %%POSTFIX%%et  elle  sentait  encore  l’é*
>%%LINK%%[[#^2aany6yr12q|show annotation]]
>%%COMMENT%%
>énumération
>%%TAGS%%
>
^2aany6yr12q



>%%
>```annotation-json
>{"created":"2022-06-23T00:58:49.181Z","text":"tutoiement","updated":"2022-06-23T00:58:49.181Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":28726,"end":28729},{"type":"TextQuoteSelector","exact":"toi","prefix":"e postambule.  Femme,  réveille-","suffix":" ;  le  tocsin  de  la  raison  "}]}]}
>```
>%%
>*%%PREFIX%%e postambule.  Femme,  réveille-%%HIGHLIGHT%% ==toi== %%POSTFIX%%;  le  tocsin  de  la  raison*
>%%LINK%%[[#^a46cnxro6cc|show annotation]]
>%%COMMENT%%
>tutoiement
>%%TAGS%%
>
^a46cnxro6cc


>%%
>```annotation-json
>{"text":"impératif à valeur de commandement","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":28717,"end":28729},{"type":"TextQuoteSelector","exact":"réveille-toi","prefix":"S.      Le postambule.  Femme,","suffix":";  le  tocsin  de  la  raison"}]}],"created":"2022-06-23T00:59:39.443Z","updated":"2022-06-23T00:59:39.443Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf"}
>```
>%%
>*%%PREFIX%%S.      Le postambule.  Femme,%%HIGHLIGHT%% ==réveille-toi== %%POSTFIX%%;  le  tocsin  de  la  raison*
>%%LINK%%[[#^5uqaw7xn3yo|show annotation]]
>%%COMMENT%%
>impératif à valeur de commandement
>%%TAGS%%
>
^5uqaw7xn3yo


>%%
>```annotation-json
>{"text":"impératif à valeur de commandement","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":28805,"end":28825},{"type":"TextQuoteSelector","exact":"reconnais tes droits","prefix":"tendre  dans  tout  l'univers ;","suffix":". Le puissant empire de la natur"}]}],"created":"2022-06-23T01:00:21.010Z","updated":"2022-06-23T01:00:21.010Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf"}
>```
>%%
>*%%PREFIX%%tendre  dans  tout  l'univers ;%%HIGHLIGHT%% ==reconnais tes droits== %%POSTFIX%%. Le puissant empire de la natur*
>%%LINK%%[[#^cq010ewve8u|show annotation]]
>%%COMMENT%%
>impératif à valeur de commandement
>%%TAGS%%
>
^cq010ewve8u


>%%
>```annotation-json
>{"created":"2022-06-23T01:03:26.682Z","text":"métaphore","updated":"2022-06-23T01:03:26.682Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":28732,"end":28759},{"type":"TextQuoteSelector","exact":" le  tocsin  de  la  raison","prefix":"ambule.  Femme,  réveille-toi ; ","suffix":"  se  fait  entendre  dans  tout"}]}]}
>```
>%%
>*%%PREFIX%%ambule.  Femme,  réveille-toi ;%%HIGHLIGHT%% ==le  tocsin  de  la  raison== %%POSTFIX%%se  fait  entendre  dans  tout*
>%%LINK%%[[#^znbh2nqw4ec|show annotation]]
>%%COMMENT%%
>métaphore
>%%TAGS%%
>
^znbh2nqw4ec


>%%
>```annotation-json
>{"created":"2022-06-23T01:03:52.160Z","text":"métaphore","updated":"2022-06-23T01:03:52.160Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":28943,"end":28964},{"type":"TextQuoteSelector","exact":"flambeau de la vérité","prefix":"uperstition et de mensonges. Le ","suffix":" a dissipé tous les nuages de la"}]}]}
>```
>%%
>*%%PREFIX%%uperstition et de mensonges. Le%%HIGHLIGHT%% ==flambeau de la vérité== %%POSTFIX%%a dissipé tous les nuages de la*
>%%LINK%%[[#^t71oq78de2q|show annotation]]
>%%COMMENT%%
>métaphore
>%%TAGS%%
>
^t71oq78de2q


>%%
>```annotation-json
>{"created":"2022-06-23T01:04:48.766Z","text":"symbole des lumières","updated":"2022-06-23T01:04:48.766Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":28943,"end":28951},{"type":"TextQuoteSelector","exact":"flambeau","prefix":"uperstition et de mensonges. Le ","suffix":" de la vérité a dissipé tous les"}]}]}
>```
>%%
>*%%PREFIX%%uperstition et de mensonges. Le%%HIGHLIGHT%% ==flambeau== %%POSTFIX%%de la vérité a dissipé tous les*
>%%LINK%%[[#^j3fqdb0j7g|show annotation]]
>%%COMMENT%%
>symbole des lumières
>%%TAGS%%
>
^j3fqdb0j7g


>%%
>```annotation-json
>{"text":"apostrophe (interpellation) directe","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":28709,"end":28714},{"type":"TextQuoteSelector","exact":"Femme","prefix":"DE GOUGES.      Le postambule.","suffix":",  réveille-toi ;  le  tocsin  d"}]}],"created":"2022-06-23T01:05:18.131Z","updated":"2022-06-23T01:05:18.131Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf"}
>```
>%%
>*%%PREFIX%%DE GOUGES.      Le postambule.%%HIGHLIGHT%% ==Femme== %%POSTFIX%%,  réveille-toi ;  le  tocsin  d*
>%%LINK%%[[#^n49ycoghvf|show annotation]]
>%%COMMENT%%
>apostrophe (interpellation) directe
>%%TAGS%%
>
^n49ycoghvf



>%%
>```annotation-json
>{"created":"2022-06-23T08:57:19.557Z","text":"représentation d'une idée","updated":"2022-06-23T08:57:19.557Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":28737,"end":28743},{"type":"TextQuoteSelector","exact":"tocsin","prefix":"e.  Femme,  réveille-toi ;  le  ","suffix":"  de  la  raison  se  fait  ente"}]}]}
>```
>%%
>*%%PREFIX%%e.  Femme,  réveille-toi ;  le%%HIGHLIGHT%% ==tocsin== %%POSTFIX%%de  la  raison  se  fait  ente*
>%%LINK%%[[#^fp5lv9acpc|show annotation]]
>%%COMMENT%%
>représentation d'une idée
>%%TAGS%%
>
^fp5lv9acpc


>%%
>```annotation-json
>{"created":"2022-06-23T08:58:37.560Z","text":"métaphore de l'obscurantisme","updated":"2022-06-23T08:58:37.560Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":28980,"end":29023},{"type":"TextQuoteSelector","exact":"les nuages de la sottise et de l'usurpation","prefix":"eau de la vérité a dissipé tous ","suffix":".  L'homme esclave a multiplié s"}]}]}
>```
>%%
>*%%PREFIX%%eau de la vérité a dissipé tous%%HIGHLIGHT%% ==les nuages de la sottise et de l'usurpation== %%POSTFIX%%.  L'homme esclave a multiplié s*
>%%LINK%%[[#^paqpexq62gg|show annotation]]
>%%COMMENT%%
>métaphore de l'obscurantisme
>%%TAGS%%
>
^paqpexq62gg


>%%
>```annotation-json
>{"created":"2022-06-23T09:02:28.628Z","text":"négation temporelle","updated":"2022-06-23T09:02:28.628Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":28870,"end":28891},{"type":"TextQuoteSelector","exact":"environné de préjugés","prefix":" empire de la nature n'est plus ","suffix":", de fanatisme, de superstition "}]}]}
>```
>%%
>*%%PREFIX%%empire de la nature n'est plus%%HIGHLIGHT%% ==environné de préjugés== %%POSTFIX%%, de fanatisme, de superstition*
>%%LINK%%[[#^ypidh2im4um|show annotation]]
>%%COMMENT%%
>négation temporelle
>%%TAGS%%
>
^ypidh2im4um


>%%
>```annotation-json
>{"created":"2022-06-23T09:03:55.675Z","text":"passé composé marque une action terminée, achevée","updated":"2022-06-23T09:03:55.675Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":28965,"end":28974},{"type":"TextQuoteSelector","exact":"a dissipé","prefix":"onges. Le flambeau de la vérité ","suffix":" tous les nuages de la sottise e"}]}]}
>```
>%%
>*%%PREFIX%%onges. Le flambeau de la vérité%%HIGHLIGHT%% ==a dissipé== %%POSTFIX%%tous les nuages de la sottise e*
>%%LINK%%[[#^nnpgg8ggp29|show annotation]]
>%%COMMENT%%
>passé composé marque une action terminée, achevée
>%%TAGS%%
>
^nnpgg8ggp29


>%%
>```annotation-json
>{"created":"2022-06-23T09:06:47.382Z","text":"lexique affranchissement","updated":"2022-06-23T09:06:47.382Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":29027,"end":29041},{"type":"TextQuoteSelector","exact":"'homme esclave","prefix":"a sottise et de l'usurpation.  L","suffix":" a multiplié ses forces, a eu  b"}]}]}
>```
>%%
>*%%PREFIX%%a sottise et de l'usurpation.  L%%HIGHLIGHT%% =='homme esclave== %%POSTFIX%%a multiplié ses forces, a eu  b*
>%%LINK%%[[#^g8slp6wdb7m|show annotation]]
>%%COMMENT%%
>lexique affranchissement
>%%TAGS%%
>
^g8slp6wdb7m


>%%
>```annotation-json
>{"created":"2022-06-23T09:07:29.009Z","text":"allégorie avec lexique affranchissement","updated":"2022-06-23T09:07:29.009Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":29114,"end":29131},{"type":"TextQuoteSelector","exact":"briser  ses  fers","prefix":"  recourir  aux  tiennes  pour  ","suffix":".  Devenu  libre,  il  est  deve"}]}]}
>```
>%%
>*%%PREFIX%%recourir  aux  tiennes  pour%%HIGHLIGHT%% ==briser  ses  fers== %%POSTFIX%%.  Devenu  libre,  il  est  deve*
>%%LINK%%[[#^a3b33e8g0mt|show annotation]]
>%%COMMENT%%
>allégorie avec lexique affranchissement
>%%TAGS%%
>
^a3b33e8g0mt


>%%
>```annotation-json
>{"created":"2022-06-23T09:07:53.549Z","text":"lexique affranchissement","updated":"2022-06-23T09:07:53.549Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":29134,"end":29147},{"type":"TextQuoteSelector","exact":"Devenu  libre","prefix":"nnes  pour  briser  ses  fers.  ","suffix":",  il  est  devenu 5 injuste  en"}]}]}
>```
>%%
>*%%PREFIX%%nnes  pour  briser  ses  fers.%%HIGHLIGHT%% ==Devenu  libre== %%POSTFIX%%,  il  est  devenu 5 injuste  en*
>%%LINK%%[[#^rcuzk34g7td|show annotation]]
>%%COMMENT%%
>lexique affranchissement
>%%TAGS%%
>
^rcuzk34g7td


>%%
>```annotation-json
>{"created":"2022-06-23T09:08:55.767Z","text":"parallélisme mettant en évidence l'injustice de l'homme","updated":"2022-06-23T09:08:55.767Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":29134,"end":29175},{"type":"TextQuoteSelector","exact":"Devenu  libre,  il  est  devenu 5 injuste","prefix":"nnes  pour  briser  ses  fers.  ","suffix":"  envers  sa  compagne.  O  femm"}]}]}
>```
>%%
>*%%PREFIX%%nnes  pour  briser  ses  fers.%%HIGHLIGHT%% ==Devenu  libre,  il  est  devenu 5 injuste== %%POSTFIX%%envers  sa  compagne.  O  femm*
>%%LINK%%[[#^trjyen5ss3|show annotation]]
>%%COMMENT%%
>parallélisme mettant en évidence l'injustice de l'homme
>%%TAGS%%
>
^trjyen5ss3


>%%
>```annotation-json
>{"created":"2022-06-23T09:11:45.986Z","text":"Comment Olympe de Gouges parvient - elle à retenir l'attention de ses lecteurs ?","updated":"2022-06-23T09:11:45.986Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":30651,"end":30739},{"type":"TextQuoteSelector","exact":"Olympe de Gouges, Déclaration des droits de la femme et de la citoyenne, 1791 (extrait).","prefix":" vous n'avez qu’à le vouloir.   ","suffix":"   19   Plus d’informations Moin"}]}]}
>```
>%%
>*%%PREFIX%%vous n'avez qu’à le vouloir.%%HIGHLIGHT%% ==Olympe de Gouges, Déclaration des droits de la femme et de la citoyenne, 1791 (extrait).== %%POSTFIX%%19   Plus d’informations Moin*
>%%LINK%%[[#^k3xwlwke7|show annotation]]
>%%COMMENT%%
>Comment Olympe de Gouges parvient - elle à retenir l'attention de ses lecteurs ?
>%%TAGS%%
>
^k3xwlwke7


>%%
>```annotation-json
>{"created":"2022-06-23T09:14:12.662Z","text":"Interjection","updated":"2022-06-23T09:14:12.662Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":29200,"end":29202},{"type":"TextQuoteSelector","exact":"O ","prefix":"injuste  envers  sa  compagne.  ","suffix":" femmes  !  femmes,  quand  cess"}]}]}
>```
>%%
>*%%PREFIX%%injuste  envers  sa  compagne.%%HIGHLIGHT%% ==O== %%POSTFIX%%femmes  !  femmes,  quand  cess*
>%%LINK%%[[#^a0cexakpsov|show annotation]]
>%%COMMENT%%
>Interjection
>%%TAGS%%
>
^a0cexakpsov


>%%
>```annotation-json
>{"created":"2022-06-23T09:14:51.657Z","text":"question rhétorique","updated":"2022-06-23T09:14:51.657Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":29261,"end":29263},{"type":"TextQuoteSelector","exact":"? ","prefix":" cesserez-vous  d'être aveugles ","suffix":"Quels sont les avantages que vou"}]}]}
>```
>%%
>*%%PREFIX%%cesserez-vous  d'être aveugles%%HIGHLIGHT%% ==?== %%POSTFIX%%Quels sont les avantages que vou*
>%%LINK%%[[#^6wsp30p3rom|show annotation]]
>%%COMMENT%%
>question rhétorique
>%%TAGS%%
>
^6wsp30p3rom


>%%
>```annotation-json
>{"created":"2022-06-23T09:15:11.339Z","text":"question rhétorique","updated":"2022-06-23T09:15:11.339Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":29332,"end":29333},{"type":"TextQuoteSelector","exact":"?","prefix":"z recueillis dans la Révolution ","suffix":" Un mépris  plus  marqué,  un  d"}]}]}
>```
>%%
>*%%PREFIX%%z recueillis dans la Révolution%%HIGHLIGHT%% ==?== %%POSTFIX%%Un mépris  plus  marqué,  un  d*
>%%LINK%%[[#^k8xtyy4memi|show annotation]]
>%%COMMENT%%
>question rhétorique
>%%TAGS%%
>
^k8xtyy4memi


>%%
>```annotation-json
>{"created":"2022-06-23T09:16:49.867Z","text":"accumulation hyperbolique ironique","updated":"2022-06-23T09:16:49.867Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":29334,"end":29385},{"type":"TextQuoteSelector","exact":"Un mépris  plus  marqué,  un  dédain  plus  signalé","prefix":"recueillis dans la Révolution ? ","suffix":".  Dans  les  siècles  de  corru"}]}]}
>```
>%%
>*%%PREFIX%%recueillis dans la Révolution ?%%HIGHLIGHT%% ==Un mépris  plus  marqué,  un  dédain  plus  signalé== %%POSTFIX%%.  Dans  les  siècles  de  corru*
>%%LINK%%[[#^w5b6ww6spb|show annotation]]
>%%COMMENT%%
>accumulation hyperbolique ironique
>%%TAGS%%
>
^w5b6ww6spb


>%%
>```annotation-json
>{"created":"2022-06-23T09:19:16.080Z","text":"périphrase péjorative","updated":"2022-06-23T09:19:16.080Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":29394,"end":29422},{"type":"TextQuoteSelector","exact":"les  siècles  de  corruption","prefix":"  dédain  plus  signalé.  Dans  ","suffix":"  vous n'avez  régné  que  sur  "}]}]}
>```
>%%
>*%%PREFIX%%dédain  plus  signalé.  Dans%%HIGHLIGHT%% ==les  siècles  de  corruption== %%POSTFIX%%vous n'avez  régné  que  sur*
>%%LINK%%[[#^05uos7nuawrx|show annotation]]
>%%COMMENT%%
>périphrase péjorative
>%%TAGS%%
>
^05uos7nuawrx


>%%
>```annotation-json
>{"created":"2022-06-23T09:26:41.357Z","text":"s'oppose à l'homme pour appuyer ça \"puissance\"","updated":"2022-06-23T09:26:41.357Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":29648,"end":29674},{"type":"TextQuoteSelector","exact":"sages décrets de la nature","prefix":"e 10 patrimoine, fondée sur les ","suffix":" ; qu’auriez-vous à redouter pou"}]}]}
>```
>%%
>*%%PREFIX%%e 10 patrimoine, fondée sur les%%HIGHLIGHT%% ==sages décrets de la nature== %%POSTFIX%%; qu’auriez-vous à redouter pou*
>%%LINK%%[[#^o6ztqbr2xl|show annotation]]
>%%COMMENT%%
>s'oppose à l'homme pour appuyer ça "puissance"
>%%TAGS%%
>
^o6ztqbr2xl


>%%
>```annotation-json
>{"created":"2022-06-23T09:28:36.970Z","text":"référence à la bible","updated":"2022-06-23T09:28:36.970Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":29748,"end":29777},{"type":"TextQuoteSelector","exact":"législateur des noces de Cana","prefix":"elle entreprise ? le bon mot du ","suffix":" ? Craignez-vous que nos législa"}]}]}
>```
>%%
>*%%PREFIX%%elle entreprise ? le bon mot du%%HIGHLIGHT%% ==législateur des noces de Cana== %%POSTFIX%%? Craignez-vous que nos législa*
>%%LINK%%[[#^7gyyho1xku7|show annotation]]
>%%COMMENT%%
>référence à la bible
>%%TAGS%%
>
^7gyyho1xku7


>%%
>```annotation-json
>{"created":"2022-06-23T09:29:57.459Z","text":"métaphore en animal","updated":"2022-06-23T09:29:57.459Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":30413,"end":30452},{"type":"TextQuoteSelector","exact":"serviles adorateurs rampant à vos pieds","prefix":"ientôt  ces  orgueilleux,  non  ","suffix":", mais fiers de partager avec vo"}]}]}
>```
>%%
>*%%PREFIX%%ientôt  ces  orgueilleux,  non%%HIGHLIGHT%% ==serviles adorateurs rampant à vos pieds== %%POSTFIX%%, mais fiers de partager avec vo*
>%%LINK%%[[#^oy5czv2isn|show annotation]]
>%%COMMENT%%
>métaphore en animal
>%%TAGS%%
>
^oy5czv2isn


>%%
>```annotation-json
>{"created":"2022-06-23T09:31:21.796Z","text":"impératif","updated":"2022-06-23T09:31:21.796Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":30175,"end":30182},{"type":"TextQuoteSelector","exact":"opposez","prefix":"adiction avec leurs principes ; ","suffix":" courageusement la force de la r"}]}]}
>```
>%%
>*%%PREFIX%%adiction avec leurs principes ;%%HIGHLIGHT%% ==opposez== %%POSTFIX%%courageusement la force de la r*
>%%LINK%%[[#^74scn67clrq|show annotation]]
>%%COMMENT%%
>impératif
>%%TAGS%%
>
^74scn67clrq


>%%
>```annotation-json
>{"created":"2022-06-23T09:31:32.868Z","text":"adverbe renforce l'appuie de la raison","updated":"2022-06-23T09:31:32.868Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":30183,"end":30198},{"type":"TextQuoteSelector","exact":"courageusement ","prefix":" avec leurs principes ; opposez ","suffix":"la force de la raison aux vaines"}]}]}
>```
>%%
>*%%PREFIX%%avec leurs principes ; opposez%%HIGHLIGHT%% ==courageusement== %%POSTFIX%%la force de la raison aux vaines*
>%%LINK%%[[#^gvzl8m5ygm7|show annotation]]
>%%COMMENT%%
>adverbe renforce l'appuie de la raison
>%%TAGS%%
>
^gvzl8m5ygm7


>%%
>```annotation-json
>{"created":"2022-06-23T09:33:53.524Z","text":"métaphore","updated":"2022-06-23T09:33:53.524Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":30275,"end":30311},{"type":"TextQuoteSelector","exact":"sous les étendards de la philosophie","prefix":"de supériorité ; réunissez-vous ","suffix":" ; déployez toute l'énergie  de "}]}]}
>```
>%%
>*%%PREFIX%%de supériorité ; réunissez-vous%%HIGHLIGHT%% ==sous les étendards de la philosophie== %%POSTFIX%%; déployez toute l'énergie  de*
>%%LINK%%[[#^hrrts851925|show annotation]]
>%%COMMENT%%
>métaphore
>%%TAGS%%
>
^hrrts851925


>%%
>```annotation-json
>{"created":"2022-06-23T09:38:46.858Z","text":"double négation","updated":"2022-06-23T09:38:46.858Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":27289,"end":27315},{"type":"TextQuoteSelector","exact":"Nulle femme n’est exceptée","prefix":"Olympe DE GOUGES.    Article 7- ","suffix":" ; elle est accusée, arrêtée, et"}]}]}
>```
>%%
>*%%PREFIX%%Olympe DE GOUGES.    Article 7-%%HIGHLIGHT%% ==Nulle femme n’est exceptée== %%POSTFIX%%; elle est accusée, arrêtée, et*
>%%LINK%%[[#^g0w61t44g1|show annotation]]
>%%COMMENT%%
>double négation
>%%TAGS%%
>
^g0w61t44g1


>%%
>```annotation-json
>{"created":"2022-06-23T09:42:08.539Z","text":"rythme ternaire","updated":"2022-06-23T09:42:08.539Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":27327,"end":27355},{"type":"TextQuoteSelector","exact":"accusée, arrêtée, et détenue","prefix":"femme n’est exceptée ; elle est ","suffix":" dans les cas  déterminés  par  "}]}]}
>```
>%%
>*%%PREFIX%%femme n’est exceptée ; elle est%%HIGHLIGHT%% ==accusée, arrêtée, et détenue== %%POSTFIX%%dans les cas  déterminés  par*
>%%LINK%%[[#^00sfrngakbasi|show annotation]]
>%%COMMENT%%
>rythme ternaire
>%%TAGS%%
>
^00sfrngakbasi


>%%
>```annotation-json
>{"created":"2022-06-23T09:42:42.917Z","text":"comparaison","updated":"2022-06-23T09:42:42.917Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":27422,"end":27440},{"type":"TextQuoteSelector","exact":"comme  les  hommes","prefix":" loi :  les  femmes  obéissent  ","suffix":"  à  cette  loi rigoureuse.  Art"}]}]}
>```
>%%
>*%%PREFIX%%loi :  les  femmes  obéissent%%HIGHLIGHT%% ==comme  les  hommes== %%POSTFIX%%à  cette  loi rigoureuse.  Art*
>%%LINK%%[[#^rwhfr797se|show annotation]]
>%%COMMENT%%
>comparaison
>%%TAGS%%
>
^rwhfr797se


>%%
>```annotation-json
>{"created":"2022-06-23T09:43:48.204Z","text":"intérêt juridique","updated":"2022-06-23T09:43:48.204Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":27503,"end":27517},{"type":"TextQuoteSelector","exact":"que des peines","prefix":"ticle 8- La loi ne doit établir ","suffix":" strictement et évidemment néces"}]}]}
>```
>%%
>*%%PREFIX%%ticle 8- La loi ne doit établir%%HIGHLIGHT%% ==que des peines== %%POSTFIX%%strictement et évidemment néces*
>%%LINK%%[[#^6cfo25h38of|show annotation]]
>%%COMMENT%%
>intérêt juridique
>%%TAGS%%
>
^6cfo25h38of


>%%
>```annotation-json
>{"created":"2022-06-23T09:44:23.403Z","text":"présent vérité général","updated":"2022-06-23T09:44:23.403Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":27480,"end":27494},{"type":"TextQuoteSelector","exact":"La loi ne doit","prefix":"te  loi rigoureuse.  Article 8- ","suffix":" établir que des peines strictem"}]}]}
>```
>%%
>*%%PREFIX%%te  loi rigoureuse.  Article 8-%%HIGHLIGHT%% ==La loi ne doit== %%POSTFIX%%établir que des peines strictem*
>%%LINK%%[[#^qa3aqtxf9ab|show annotation]]
>%%COMMENT%%
>présent vérité général
>%%TAGS%%
>
^qa3aqtxf9ab


>%%
>```annotation-json
>{"created":"2022-06-23T09:45:13.735Z","text":"adverbe pour le désigner le cadre de loi","updated":"2022-06-23T09:45:13.735Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":27518,"end":27529},{"type":"TextQuoteSelector","exact":"strictement","prefix":" ne doit établir que des peines ","suffix":" et évidemment nécessaires, et n"}]}]}
>```
>%%
>*%%PREFIX%%ne doit établir que des peines%%HIGHLIGHT%% ==strictement== %%POSTFIX%%et évidemment nécessaires, et n*
>%%LINK%%[[#^otatgwitfk|show annotation]]
>%%COMMENT%%
>adverbe pour le désigner le cadre de loi
>%%TAGS%%
>
^otatgwitfk


>%%
>```annotation-json
>{"created":"2022-06-23T09:45:52.671Z","text":"adverbe pour le désigner le cadre de loi","updated":"2022-06-23T09:45:52.671Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":27533,"end":27544},{"type":"TextQuoteSelector","exact":"évidemment ","prefix":"r que des peines strictement et ","suffix":"nécessaires, et nul ne peut être"}]}]}
>```
>%%
>*%%PREFIX%%r que des peines strictement et%%HIGHLIGHT%% ==évidemment== %%POSTFIX%%nécessaires, et nul ne peut être*
>%%LINK%%[[#^r1sbu3kpf7a|show annotation]]
>%%COMMENT%%
>adverbe pour le désigner le cadre de loi
>%%TAGS%%
>
^r1sbu3kpf7a


>%%
>```annotation-json
>{"created":"2022-06-23T09:46:01.018Z","text":"adverbe pour le désigner le cadre de loi","updated":"2022-06-23T09:46:01.018Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":27626,"end":27640},{"type":"TextQuoteSelector","exact":"antérieurement","prefix":"d’une loi établie et promulguée ","suffix":" au 5 délit, et légalement appli"}]}]}
>```
>%%
>*%%PREFIX%%d’une loi établie et promulguée%%HIGHLIGHT%% ==antérieurement== %%POSTFIX%%au 5 délit, et légalement appli*
>%%LINK%%[[#^8oo6p3zpo3r|show annotation]]
>%%COMMENT%%
>adverbe pour le désigner le cadre de loi
>%%TAGS%%
>
^8oo6p3zpo3r


>%%
>```annotation-json
>{"created":"2022-06-23T09:46:11.480Z","text":"adverbe pour le désigner le cadre de loi","updated":"2022-06-23T09:46:11.480Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":27656,"end":27666},{"type":"TextQuoteSelector","exact":"légalement","prefix":"e antérieurement au 5 délit, et ","suffix":" appliquée aux femmes.  Article "}]}]}
>```
>%%
>*%%PREFIX%%e antérieurement au 5 délit, et%%HIGHLIGHT%% ==légalement== %%POSTFIX%%appliquée aux femmes.  Article*
>%%LINK%%[[#^ydnjg6snjcf|show annotation]]
>%%COMMENT%%
>adverbe pour le désigner le cadre de loi
>%%TAGS%%
>
^ydnjg6snjcf


>%%
>```annotation-json
>{"created":"2022-06-23T09:46:48.752Z","text":"ironie","updated":"2022-06-23T09:46:48.752Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":27667,"end":27687},{"type":"TextQuoteSelector","exact":"appliquée aux femmes","prefix":"ement au 5 délit, et légalement ","suffix":".  Article 9- Toute femme étant "}]}]}
>```
>%%
>*%%PREFIX%%ement au 5 délit, et légalement%%HIGHLIGHT%% ==appliquée aux femmes== %%POSTFIX%%.  Article 9- Toute femme étant*
>%%LINK%%[[#^nd6jj5m9348|show annotation]]
>%%COMMENT%%
>ironie
>%%TAGS%%
>
^nd6jj5m9348


>%%
>```annotation-json
>{"created":"2022-06-23T09:48:13.951Z","text":"dénonce ironiquement l'inégalité morale","updated":"2022-06-23T09:48:13.951Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":27690,"end":27700},{"type":"TextQuoteSelector","exact":"Article 9-","prefix":"galement appliquée aux femmes.  ","suffix":" Toute femme étant déclarée coup"}]}]}
>```
>%%
>*%%PREFIX%%galement appliquée aux femmes.%%HIGHLIGHT%% ==Article 9-== %%POSTFIX%%Toute femme étant déclarée coup*
>%%LINK%%[[#^scbogp5e29s|show annotation]]
>%%COMMENT%%
>dénonce ironiquement l'inégalité morale
>%%TAGS%%
>
^scbogp5e29s


>%%
>```annotation-json
>{"created":"2022-06-23T09:50:11.080Z","text":"parallelisme","updated":"2022-06-23T09:50:11.080Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":27948,"end":27969},{"type":"TextQuoteSelector","exact":"monter  à  la tribune","prefix":"t  également  avoir  celui  de  ","suffix":", pourvu que ses manifestations "}]}]}
>```
>%%
>*%%PREFIX%%t  également  avoir  celui  de%%HIGHLIGHT%% ==monter  à  la tribune== %%POSTFIX%%, pourvu que ses manifestations*
>%%LINK%%[[#^2baefcu3115|show annotation]]
>%%COMMENT%%
>parallelisme
>%%TAGS%%
>
^2baefcu3115


>%%
>```annotation-json
>{"created":"2022-06-23T09:50:33.203Z","text":"répétition","updated":"2022-06-23T09:50:33.203Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":27880,"end":27887},{"type":"TextQuoteSelector","exact":" monter","prefix":"les ; la femme a  le  droit  de ","suffix":"  sur  l’échafaud,  elle  doit  "}]}]}
>```
>%%
>*%%PREFIX%%les ; la femme a  le  droit  de%%HIGHLIGHT%% ==monter== %%POSTFIX%%sur  l’échafaud,  elle  doit*
>%%LINK%%[[#^b6fc2281rmk|show annotation]]
>%%COMMENT%%
>répétition
>%%TAGS%%
>
^b6fc2281rmk


>%%
>```annotation-json
>{"created":"2022-06-23T09:52:25.693Z","text":"comparaison / parallèle","updated":"2022-06-23T09:52:25.693Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":28168,"end":28241},{"type":"TextQuoteSelector","exact":"puisque cette liberté assure la légitimité des pères envers leurs enfants","prefix":" les plus précieux de la femme, ","suffix":". Toute citoyenne peut donc dire"}]}]}
>```
>%%
>*%%PREFIX%%les plus précieux de la femme,%%HIGHLIGHT%% ==puisque cette liberté assure la légitimité des pères envers leurs enfants== %%POSTFIX%%. Toute citoyenne peut donc dire*
>%%LINK%%[[#^ppvod48shsm|show annotation]]
>%%COMMENT%%
>comparaison / parallèle
>%%TAGS%%
>
^ppvod48shsm


>%%
>```annotation-json
>{"created":"2022-06-23T12:41:48.623Z","text":"Apostrophe","updated":"2022-06-23T12:41:48.623Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":25859,"end":25864},{"type":"TextQuoteSelector","exact":"Homme","prefix":"       Les Droits de la Femme.  ","suffix":", es-tu capable d’être juste ? C"}]}]}
>```
>%%
>*%%PREFIX%%Les Droits de la Femme.%%HIGHLIGHT%% ==Homme== %%POSTFIX%%, es-tu capable d’être juste ? C*
>%%LINK%%[[#^dfe0hgqtlg|show annotation]]
>%%COMMENT%%
>Apostrophe
>%%TAGS%%
>
^dfe0hgqtlg


>%%
>```annotation-json
>{"created":"2022-06-23T13:03:36.370Z","text":"question rhétorique","updated":"2022-06-23T13:03:36.370Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":25893,"end":25894},{"type":"TextQuoteSelector","exact":"?","prefix":"mme, es-tu capable d’être juste ","suffix":" C’est une femme qui t’en fait l"}]}]}
>```
>%%
>*%%PREFIX%%mme, es-tu capable d’être juste%%HIGHLIGHT%% ==?== %%POSTFIX%%C’est une femme qui t’en fait l*
>%%LINK%%[[#^rqf3m2x0dws|show annotation]]
>%%COMMENT%%
>question rhétorique
>%%TAGS%%
>
^rqf3m2x0dws


>%%
>```annotation-json
>{"created":"2022-06-23T13:04:04.548Z","text":"tutoiement marquant l'égalité","updated":"2022-06-23T13:04:04.548Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":25869,"end":25871},{"type":"TextQuoteSelector","exact":"tu","prefix":" Droits de la Femme.  Homme, es-","suffix":" capable d’être juste ? C’est un"}]}]}
>```
>%%
>*%%PREFIX%%Droits de la Femme.  Homme, es-%%HIGHLIGHT%% ==tu== %%POSTFIX%%capable d’être juste ? C’est un*
>%%LINK%%[[#^5wj9m0sf993|show annotation]]
>%%COMMENT%%
>tutoiement marquant l'égalité
>%%TAGS%%
>
^5wj9m0sf993


>%%
>```annotation-json
>{"created":"2022-06-23T13:06:42.309Z","text":"elle se désigne à travers un article indéfini","updated":"2022-06-23T13:06:42.309Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":25901,"end":25904},{"type":"TextQuoteSelector","exact":"une","prefix":"tu capable d’être juste ? C’est ","suffix":" femme qui t’en fait la question"}]}]}
>```
>%%
>*%%PREFIX%%tu capable d’être juste ? C’est%%HIGHLIGHT%% ==une== %%POSTFIX%%femme qui t’en fait la question*
>%%LINK%%[[#^xuzzs9emmo|show annotation]]
>%%COMMENT%%
>elle se désigne à travers un article indéfini
>%%TAGS%%
>
^xuzzs9emmo


>%%
>```annotation-json
>{"created":"2022-06-23T13:08:24.627Z","text":"négation totale","updated":"2022-06-23T13:08:24.627Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":25958,"end":25961},{"type":"TextQuoteSelector","exact":"pas","prefix":"a question ; tu ne lui  ôteras  ","suffix":"  du  moins  ce  droit.  Dis-moi"}]}]}
>```
>%%
>*%%PREFIX%%a question ; tu ne lui  ôteras%%HIGHLIGHT%% ==pas== %%POSTFIX%%du  moins  ce  droit.  Dis-moi*
>%%LINK%%[[#^idcyg80irm|show annotation]]
>%%COMMENT%%
>négation totale
>%%TAGS%%
>
^idcyg80irm


>%%
>```annotation-json
>{"created":"2022-06-23T13:09:20.982Z","text":"impératif injonction","updated":"2022-06-23T13:09:20.982Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":25986,"end":25995},{"type":"TextQuoteSelector","exact":"Dis-moi ?","prefix":"as  pas  du  moins  ce  droit.  ","suffix":"  Qui  t’a  donné  le  souverain"}]}]}
>```
>%%
>*%%PREFIX%%as  pas  du  moins  ce  droit.%%HIGHLIGHT%% ==Dis-moi ?== %%POSTFIX%%Qui  t’a  donné  le  souverain*
>%%LINK%%[[#^iwx7ovpmdpn|show annotation]]
>%%COMMENT%%
>impératif injonction
>%%TAGS%%
>
^iwx7ovpmdpn


>%%
>```annotation-json
>{"created":"2022-06-23T13:10:08.460Z","text":"Ironie ","updated":"2022-06-23T13:10:08.460Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":26058,"end":26083},{"type":"TextQuoteSelector","exact":"Ta force ? Tes talents ? ","prefix":"n  empire d’opprimer mon sexe ? ","suffix":"Observe le créateur dans sa sage"}]}]}
>```
>%%
>*%%PREFIX%%n  empire d’opprimer mon sexe ?%%HIGHLIGHT%% ==Ta force ? Tes talents ?== %%POSTFIX%%Observe le créateur dans sa sage*
>%%LINK%%[[#^m0694udyyl|show annotation]]
>%%COMMENT%%
>Ironie 
>%%TAGS%%
>
^m0694udyyl


>%%
>```annotation-json
>{"created":"2022-06-23T13:10:38.070Z","text":"hyperbole, désigne ce que combat les lumières","updated":"2022-06-23T13:10:38.070Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":26248,"end":26265},{"type":"TextQuoteSelector","exact":"empire tyrannique","prefix":" si tu l’oses, l’exemple de cet ","suffix":". 5 Remonte aux animaux, consult"}]}]}
>```
>%%
>*%%PREFIX%%si tu l’oses, l’exemple de cet%%HIGHLIGHT%% ==empire tyrannique== %%POSTFIX%%. 5 Remonte aux animaux, consult*
>%%LINK%%[[#^xsd7msyjb18|show annotation]]
>%%COMMENT%%
>hyperbole, désigne ce que combat les lumières
>%%TAGS%%
>
^xsd7msyjb18


>%%
>```annotation-json
>{"created":"2022-06-23T13:11:51.545Z","text":"impératif plaçant Olympes dans une position supérieure à l'être humain","updated":"2022-06-23T13:11:51.545Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":26206,"end":26215},{"type":"TextQuoteSelector","exact":"donne-moi","prefix":"mbles vouloir te rapprocher, et ","suffix":", si tu l’oses, l’exemple de cet"}]}]}
>```
>%%
>*%%PREFIX%%mbles vouloir te rapprocher, et%%HIGHLIGHT%% ==donne-moi== %%POSTFIX%%, si tu l’oses, l’exemple de cet*
>%%LINK%%[[#^j7aiar7v39e|show annotation]]
>%%COMMENT%%
>impératif plaçant Olympes dans une position supérieure à l'être humain
>%%TAGS%%
>
^j7aiar7v39e


>%%
>```annotation-json
>{"created":"2022-06-23T13:12:40.061Z","text":"énumération de verbes à l'impératif","updated":"2022-06-23T13:12:40.061Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":26269,"end":26276},{"type":"TextQuoteSelector","exact":"Remonte","prefix":"ple de cet empire tyrannique. 5 ","suffix":" aux animaux, consulte les éléme"}]}]}
>```
>%%
>*%%PREFIX%%ple de cet empire tyrannique. 5%%HIGHLIGHT%% ==Remonte== %%POSTFIX%%aux animaux, consulte les éléme*
>%%LINK%%[[#^o7c3stjuu99|show annotation]]
>%%COMMENT%%
>énumération de verbes à l'impératif
>%%TAGS%%
>
^o7c3stjuu99


>%%
>```annotation-json
>{"created":"2022-06-23T13:13:11.204Z","text":"champs lexical de la nature pour se rendre de ce que veut la nature","updated":"2022-06-23T13:13:11.204Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":26281,"end":26288},{"type":"TextQuoteSelector","exact":"animaux","prefix":"mpire tyrannique. 5 Remonte aux ","suffix":", consulte les éléments, étudie "}]}]}
>```
>%%
>*%%PREFIX%%mpire tyrannique. 5 Remonte aux%%HIGHLIGHT%% ==animaux== %%POSTFIX%%, consulte les éléments, étudie*
>%%LINK%%[[#^vr6v0k1ofr|show annotation]]
>%%COMMENT%%
>champs lexical de la nature pour se rendre de ce que veut la nature
>%%TAGS%%
>
^vr6v0k1ofr


>%%
>```annotation-json
>{"created":"2022-06-23T13:14:24.763Z","text":"champs lexical de l'union","updated":"2022-06-23T13:14:24.763Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":26600,"end":26609},{"type":"TextQuoteSelector","exact":"confondus","prefix":"ature. Partout tu les trouveras ","suffix":", partout ils coopèrent avec un "}]}]}
>```
>%%
>*%%PREFIX%%ature. Partout tu les trouveras%%HIGHLIGHT%% ==confondus== %%POSTFIX%%, partout ils coopèrent avec un*
>%%LINK%%[[#^6efdd8xkgtf|show annotation]]
>%%COMMENT%%
>champs lexical de l'union
>%%TAGS%%
>
^6efdd8xkgtf


>%%
>```annotation-json
>{"created":"2022-06-23T13:15:14.499Z","text":"anaphore","updated":"2022-06-23T13:15:14.499Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":26575,"end":26582},{"type":"TextQuoteSelector","exact":"Partout","prefix":" l’administration de la nature. ","suffix":" tu les trouveras confondus, par"}]}]}
>```
>%%
>*%%PREFIX%%l’administration de la nature.%%HIGHLIGHT%% ==Partout== %%POSTFIX%%tu les trouveras confondus, par*
>%%LINK%%[[#^564d0n7wqu|show annotation]]
>%%COMMENT%%
>anaphore
>%%TAGS%%
>
^564d0n7wqu


>%%
>```annotation-json
>{"created":"2022-06-23T13:20:10.580Z","text":"changement d'énonciation 3°pers","updated":"2022-06-23T13:20:10.580Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":26692,"end":26705},{"type":"TextQuoteSelector","exact":"L’homme seul ","prefix":" à ce chef-d’œuvre immortel. 10 ","suffix":"s’est fagoté un principe de cett"}]}]}
>```
>%%
>*%%PREFIX%%à ce chef-d’œuvre immortel. 10%%HIGHLIGHT%% ==L’homme seul== %%POSTFIX%%s’est fagoté un principe de cett*
>%%LINK%%[[#^1lsgodfnztk|show annotation]]
>%%COMMENT%%
>changement d'énonciation 3°pers
>%%TAGS%%
>
^1lsgodfnztk


>%%
>```annotation-json
>{"created":"2022-06-23T13:20:58.877Z","text":"gradation","updated":"2022-06-23T13:20:58.877Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":26750,"end":26802},{"type":"TextQuoteSelector","exact":"Bizarre, aveugle, boursouflé de sciences et dégénéré","prefix":"un principe de cette exception. ","suffix":", dans ce siècle de lumières et "}]}]}
>```
>%%
>*%%PREFIX%%un principe de cette exception.%%HIGHLIGHT%% ==Bizarre, aveugle, boursouflé de sciences et dégénéré== %%POSTFIX%%, dans ce siècle de lumières et*
>%%LINK%%[[#^ir1yeo46wgj|show annotation]]
>%%COMMENT%%
>gradation
>%%TAGS%%
>
^ir1yeo46wgj


>%%
>```annotation-json
>{"created":"2022-06-23T13:21:41.541Z","text":"antithèse","updated":"2022-06-23T13:21:41.541Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":26821,"end":26878},{"type":"TextQuoteSelector","exact":" lumières et de sagacité, dans l’ignorance la plus crasse","prefix":"s et dégénéré, dans ce siècle de","suffix":", il veut commander en despote s"}]}]}
>```
>%%
>*%%PREFIX%%s et dégénéré, dans ce siècle de%%HIGHLIGHT%% ==lumières et de sagacité, dans l’ignorance la plus crasse== %%POSTFIX%%, il veut commander en despote s*
>%%LINK%%[[#^jczcffm8g1b|show annotation]]
>%%COMMENT%%
>antithèse
>%%TAGS%%
>
^jczcffm8g1b


>%%
>```annotation-json
>{"created":"2022-06-23T13:22:02.452Z","text":"hyperbole pour le tourner en ridicule","updated":"2022-06-23T13:22:02.452Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":26932,"end":26967},{"type":"TextQuoteSelector","exact":"toutes les facultés intellectuelles","prefix":" despote sur un sexe qui a reçu ","suffix":" ; il prétend jouir de la Révolu"}]}]}
>```
>%%
>*%%PREFIX%%despote sur un sexe qui a reçu%%HIGHLIGHT%% ==toutes les facultés intellectuelles== %%POSTFIX%%; il prétend jouir de la Révolu*
>%%LINK%%[[#^ri4lc8kut0m|show annotation]]
>%%COMMENT%%
>hyperbole pour le tourner en ridicule
>%%TAGS%%
>
^ri4lc8kut0m


>%%
>```annotation-json
>{"created":"2022-06-23T13:23:05.815Z","text":"registre polémique","updated":"2022-06-23T13:23:05.815Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":26880,"end":26908},{"type":"TextQuoteSelector","exact":"il veut commander en despote","prefix":"ans l’ignorance la plus crasse, ","suffix":" sur un sexe qui a reçu toutes l"}]}]}
>```
>%%
>*%%PREFIX%%ans l’ignorance la plus crasse,%%HIGHLIGHT%% ==il veut commander en despote== %%POSTFIX%%sur un sexe qui a reçu toutes l*
>%%LINK%%[[#^s5vkw3kr1sh|show annotation]]
>%%COMMENT%%
>registre polémique
>%%TAGS%%
>
^s5vkw3kr1sh


>%%
>```annotation-json
>{"created":"2022-06-23T16:36:00.568Z","text":"référence à la médecine de l'époque selon laquelle il faut rééquilibrer les humeurs","updated":"2022-06-23T16:36:00.568Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":24725,"end":24746},{"type":"TextQuoteSelector","exact":"pour votre nourriture","prefix":" Que vous ordonne votre médecin ","suffix":" ? ARGAN. – Il m’ordonne du pota"}]}]}
>```
>%%
>*%%PREFIX%%Que vous ordonne votre médecin%%HIGHLIGHT%% ==pour votre nourriture== %%POSTFIX%%? ARGAN. – Il m’ordonne du pota*
>%%LINK%%[[#^zlcpfx1m4vn|show annotation]]
>%%COMMENT%%
>référence à la médecine de l'époque selon laquelle il faut rééquilibrer les humeurs
>%%TAGS%%
>
^zlcpfx1m4vn


>%%
>```annotation-json
>{"created":"2022-06-23T16:37:23.205Z","text":"caractère autoritaire et tyrannique","updated":"2022-06-23T16:37:23.205Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":24703,"end":24711},{"type":"TextQuoteSelector","exact":"ordonne ","prefix":"ère  TOINETTE. – (...) Que vous ","suffix":"votre médecin pour votre nourrit"}]}]}
>```
>%%
>*%%PREFIX%%ère  TOINETTE. – (...) Que vous%%HIGHLIGHT%% ==ordonne== %%POSTFIX%%votre médecin pour votre nourrit*
>%%LINK%%[[#^6yfqdp03l7d|show annotation]]
>%%COMMENT%%
>caractère autoritaire et tyrannique
>%%TAGS%%
>
^6yfqdp03l7d


>%%
>```annotation-json
>{"created":"2022-06-23T16:38:24.025Z","text":"valide l'ordre","updated":"2022-06-23T16:38:24.025Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":24758,"end":24770},{"type":"TextQuoteSelector","exact":"Il m’ordonne","prefix":"our votre nourriture ? ARGAN. – ","suffix":" du potage. TOINETTE. – Ignorant"}]}]}
>```
>%%
>*%%PREFIX%%our votre nourriture ? ARGAN. –%%HIGHLIGHT%% ==Il m’ordonne== %%POSTFIX%%du potage. TOINETTE. – Ignorant*
>%%LINK%%[[#^3tjc3ozpvfe|show annotation]]
>%%COMMENT%%
>valide l'ordre
>%%TAGS%%
>
^3tjc3ozpvfe


>%%
>```annotation-json
>{"created":"2022-06-23T16:49:17.661Z","text":"répétition du terme ignorant ; comique de répétition","updated":"2022-06-23T16:49:17.661Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":24794,"end":24802},{"type":"TextQuoteSelector","exact":"Ignorant","prefix":"’ordonne du potage. TOINETTE. – ","suffix":". ARGAN. – De la volaille. 5 TOI"}]}]}
>```
>%%
>*%%PREFIX%%’ordonne du potage. TOINETTE. –%%HIGHLIGHT%% ==Ignorant== %%POSTFIX%%. ARGAN. – De la volaille. 5 TOI*
>%%LINK%%[[#^k5s7lc3l5u|show annotation]]
>%%COMMENT%%
>répétition du terme ignorant ; comique de répétition
>%%TAGS%%
>
^k5s7lc3l5u


>%%
>```annotation-json
>{"created":"2022-06-23T16:51:20.515Z","text":"référence scatologique et point culminant de la liste des aliments","updated":"2022-06-23T16:51:20.515Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":25010,"end":25050},{"type":"TextQuoteSelector","exact":"de petits pruneaux pour lâcher le ventre","prefix":" Ignorant. ARGAN. – Et le soir, ","suffix":". TOINETTE. – Ignorant. ARGAN. –"}]}]}
>```
>%%
>*%%PREFIX%%Ignorant. ARGAN. – Et le soir,%%HIGHLIGHT%% ==de petits pruneaux pour lâcher le ventre== %%POSTFIX%%. TOINETTE. – Ignorant. ARGAN. –*
>%%LINK%%[[#^9z5p75h8gq|show annotation]]
>%%COMMENT%%
>référence scatologique et point culminant de la liste des aliments
>%%TAGS%%
>
^9z5p75h8gq



>%%
>```annotation-json
>{"created":"2022-06-23T16:56:56.469Z","text":"jargon médical qui est issue de la théorie des humeurs","updated":"2022-06-23T16:56:56.469Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":25137,"end":25138},{"type":"TextQuoteSelector","exact":"–","prefix":"n vin fort trempé. 15 TOINETTE. ","suffix":" Ignorantus, ignoranta, Ignorant"}]}]}
>```
>%%
>*%%PREFIX%%n vin fort trempé. 15 TOINETTE.%%HIGHLIGHT%% ==–== %%POSTFIX%%Ignorantus, ignoranta, Ignorant*
>%%LINK%%[[#^5i5rsezw9rq|show annotation]]
>%%COMMENT%%
>jargon médical qui est issue de la théorie des humeurs
>%%TAGS%%
>
^5i5rsezw9rq


>%%
>```annotation-json
>{"created":"2022-06-23T16:57:27.118Z","text":"anaphore renforçant l'effet comique de l'inversion des rôles","updated":"2022-06-23T16:57:27.118Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":25174,"end":25181},{"type":"TextQuoteSelector","exact":"Il faut","prefix":"orantus, ignoranta, Ignorantum. ","suffix":" boire votre vin pur ; et, pour "}]}]}
>```
>%%
>*%%PREFIX%%orantus, ignoranta, Ignorantum.%%HIGHLIGHT%% ==Il faut== %%POSTFIX%%boire votre vin pur ; et, pour*
>%%LINK%%[[#^wiodwuk8xxj|show annotation]]
>%%COMMENT%%
>anaphore renforçant l'effet comique de l'inversion des rôles
>%%TAGS%%
>
^wiodwuk8xxj


>%%
>```annotation-json
>{"created":"2022-06-23T16:59:16.225Z","text":"signe d'une totale inversion des rôles","updated":"2022-06-23T16:59:16.225Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":25625,"end":25649},{"type":"TextQuoteSelector","exact":" Vous m’obligez beaucoup","prefix":"erai en cette ville. 20 ARGAN. –","suffix":".  Molière, Le Malade imaginaire"}]}]}
>```
>%%
>*%%PREFIX%%erai en cette ville. 20 ARGAN. –%%HIGHLIGHT%% ==Vous m’obligez beaucoup== %%POSTFIX%%.  Molière, Le Malade imaginaire*
>%%LINK%%[[#^78mvhsql6jg|show annotation]]
>%%COMMENT%%
>signe d'une totale inversion des rôles
>%%TAGS%%
>
^78mvhsql6jg


>%%
>```annotation-json
>{"created":"2022-06-23T17:06:01.939Z","text":"impératif montrant son autorité paternelle","updated":"2022-06-23T17:06:01.939Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":23144,"end":23150},{"type":"TextQuoteSelector","exact":"Allons","prefix":" de Molière ARGAN, à Angélique. ","suffix":", saluez Monsieur. THOMAS DIAFOI"}]}]}
>```
>%%
>*%%PREFIX%%de Molière ARGAN, à Angélique.%%HIGHLIGHT%% ==Allons== %%POSTFIX%%, saluez Monsieur. THOMAS DIAFOI*
>%%LINK%%[[#^gni7si5ecmw|show annotation]]
>%%COMMENT%%
>impératif montrant son autorité paternelle
>%%TAGS%%
>
^gni7si5ecmw


>%%
>```annotation-json
>{"created":"2022-06-23T17:07:53.372Z","text":"L'approbation double montre que le défaut de pratiques social provoque de l'agacement, et aussi chez Angélique","updated":"2022-06-23T17:07:53.372Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":23245,"end":23254},{"type":"TextQuoteSelector","exact":"Oui, oui.","prefix":"erai-je ? MONSIEUR DIAFOIRUS. 5 ","suffix":" THOMAS DIAFOIRUS, à Angélique. "}]}]}
>```
>%%
>*%%PREFIX%%erai-je ? MONSIEUR DIAFOIRUS. 5%%HIGHLIGHT%% ==Oui, oui.== %%POSTFIX%%THOMAS DIAFOIRUS, à Angélique.*
>%%LINK%%[[#^m6waiuc1xb|show annotation]]
>%%COMMENT%%
>L'approbation double montre que le défaut de pratiques social provoque de l'agacement, et aussi chez Angélique
>%%TAGS%%
>
^m6waiuc1xb


>%%
>```annotation-json
>{"created":"2022-06-23T17:10:49.356Z","text":"Elle ne répond pas montrant une opposition absolue","updated":"2022-06-23T17:10:49.356Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":23133,"end":23142},{"type":"TextQuoteSelector","exact":"Angélique","prefix":" imaginaire de Molière ARGAN, à ","suffix":". Allons, saluez Monsieur. THOMA"}]}]}
>```
>%%
>*%%PREFIX%%imaginaire de Molière ARGAN, à%%HIGHLIGHT%% ==Angélique== %%POSTFIX%%. Allons, saluez Monsieur. THOMA*
>%%LINK%%[[#^6y3q2c88sig|show annotation]]
>%%COMMENT%%
>Elle ne répond pas montrant une opposition absolue
>%%TAGS%%
>
^6y3q2c88sig


>%%
>```annotation-json
>{"created":"2022-06-23T17:15:11.808Z","text":"comique de situation","updated":"2022-06-23T17:15:11.808Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":23405,"end":23461},{"type":"TextQuoteSelector","exact":"Ce n’est pas ma femme, c’est ma fille à qui vous parlez.","prefix":"n... ARGAN, à Thomas Diafoirus. ","suffix":" 10 THOMAS DIAFOIRUS. Où donc es"}]}]}
>```
>%%
>*%%PREFIX%%n... ARGAN, à Thomas Diafoirus.%%HIGHLIGHT%% ==Ce n’est pas ma femme, c’est ma fille à qui vous parlez.== %%POSTFIX%%10 THOMAS DIAFOIRUS. Où donc es*
>%%LINK%%[[#^nbp8bgte8je|show annotation]]
>%%COMMENT%%
>comique de situation
>%%TAGS%%
>
^nbp8bgte8je


>%%
>```annotation-json
>{"created":"2022-06-23T17:16:40.784Z","text":"jeu questions réponses accentuant la stupidité du personnage","updated":"2022-06-23T17:16:40.784Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":23465,"end":23482},{"type":"TextQuoteSelector","exact":"THOMAS DIAFOIRUS.","prefix":" ma fille à qui vous parlez. 10 ","suffix":" Où donc est-elle ? ARGAN. Elle "}]}]}
>```
>%%
>*%%PREFIX%%ma fille à qui vous parlez. 10%%HIGHLIGHT%% ==THOMAS DIAFOIRUS.== %%POSTFIX%%Où donc est-elle ? ARGAN. Elle*
>%%LINK%%[[#^toc024gz8zo|show annotation]]
>%%COMMENT%%
>jeu questions réponses accentuant la stupidité du personnage
>%%TAGS%%
>
^toc024gz8zo


>%%
>```annotation-json
>{"created":"2022-06-23T17:19:05.229Z","text":"maladroit, bien qu'imitant le style des salons précieux ","updated":"2022-06-23T17:19:05.229Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":24188,"end":24200},{"type":"TextQuoteSelector","exact":"mademoiselle","prefix":"son pôle unique. Souffrez donc, ","suffix":", que j’appende aujourd’hui à l’"}]}]}
>```
>%%
>*%%PREFIX%%son pôle unique. Souffrez donc,%%HIGHLIGHT%% ==mademoiselle== %%POSTFIX%%, que j’appende aujourd’hui à l’*
>%%LINK%%[[#^yo2cc1p5gv|show annotation]]
>%%COMMENT%%
>maladroit, bien qu'imitant le style des salons précieux 
>%%TAGS%%
>
^yo2cc1p5gv


>%%
>```annotation-json
>{"text":"rythme ternaire qui alourdit le compliment\nhyperbole","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":24346,"end":24444},{"type":"TextQuoteSelector","exact":"toute  sa  vie, mademoiselle, votre très humble, très obéissant, et très fidèle serviteur et mari.","prefix":"ne  autre  gloire  que  d’être","suffix":"TOINETTE, en le raillant.  Voil"}]}],"created":"2022-06-23T17:20:41.626Z","updated":"2022-06-23T17:20:41.626Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf"}
>```
>%%
>*%%PREFIX%%ne  autre  gloire  que  d’être%%HIGHLIGHT%% ==toute  sa  vie, mademoiselle, votre très humble, très obéissant, et très fidèle serviteur et mari.== %%POSTFIX%%TOINETTE, en le raillant.  Voil*
>%%LINK%%[[#^5v83umhh5eb|show annotation]]
>%%COMMENT%%
>rythme ternaire qui alourdit le compliment
>hyperbole
>%%TAGS%%
>
^5v83umhh5eb


>%%
>```annotation-json
>{"created":"2022-06-24T08:57:45.626Z","text":"superlatif menant à une hyperbole","updated":"2022-06-24T08:57:45.626Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":24382,"end":24386},{"type":"TextQuoteSelector","exact":"très","prefix":"e  sa  vie, mademoiselle, votre ","suffix":" humble, très obéissant, et très"}]}]}
>```
>%%
>*%%PREFIX%%e  sa  vie, mademoiselle, votre%%HIGHLIGHT%% ==très== %%POSTFIX%%humble, très obéissant, et très*
>%%LINK%%[[#^1x26v5yuke7|show annotation]]
>%%COMMENT%%
>superlatif menant à une hyperbole
>%%TAGS%%
>
^1x26v5yuke7


>%%
>```annotation-json
>{"created":"2022-06-24T08:59:07.147Z","text":"lexique précieux","updated":"2022-06-24T08:59:07.147Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":24173,"end":24181},{"type":"TextQuoteSelector","exact":"Souffrez","prefix":"ainsi que vers son pôle unique. ","suffix":" donc, mademoiselle, que j’appen"}]}]}
>```
>%%
>*%%PREFIX%%ainsi que vers son pôle unique.%%HIGHLIGHT%% ==Souffrez== %%POSTFIX%%donc, mademoiselle, que j’appen*
>%%LINK%%[[#^gsqz1b0xkv|show annotation]]
>%%COMMENT%%
>lexique précieux
>%%TAGS%%
>
^gsqz1b0xkv


>%%
>```annotation-json
>{"created":"2022-06-24T08:59:45.452Z","text":"périphrase pour désigner le soleil","updated":"2022-06-24T08:59:45.452Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":24013,"end":24031},{"type":"TextQuoteSelector","exact":" cet astre du jour","prefix":"éliotrope tourne sans cesse vers","suffix":", aussi mon cœur dores-en-avant "}]}]}
>```
>%%
>*%%PREFIX%%éliotrope tourne sans cesse vers%%HIGHLIGHT%% ==cet astre du jour== %%POSTFIX%%, aussi mon cœur dores-en-avant*
>%%LINK%%[[#^p5k69wu9xta|show annotation]]
>%%COMMENT%%
>périphrase pour désigner le soleil
>%%TAGS%%
>
^p5k69wu9xta


>%%
>```annotation-json
>{"created":"2022-06-24T09:01:06.200Z","text":"métaphore des yeux","updated":"2022-06-24T09:01:06.200Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":24095,"end":24117},{"type":"TextQuoteSelector","exact":"astres resplendissants","prefix":"tournera-t-il toujours vers les ","suffix":" de vos yeux adorables, ainsi qu"}]}]}
>```
>%%
>*%%PREFIX%%tournera-t-il toujours vers les%%HIGHLIGHT%% ==astres resplendissants== %%POSTFIX%%de vos yeux adorables, ainsi qu*
>%%LINK%%[[#^w8jkb54jomo|show annotation]]
>%%COMMENT%%
>métaphore des yeux
>%%TAGS%%
>
^w8jkb54jomo


>%%
>```annotation-json
>{"created":"2022-06-24T09:01:33.022Z","text":"métaphore de la femme","updated":"2022-06-24T09:01:33.022Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":23887,"end":23893},{"type":"TextQuoteSelector","exact":"soleil","prefix":" transport à  l’apparition  du  ","suffix":"  de  vos  beautés ;  et,  comme"}]}]}
>```
>%%
>*%%PREFIX%%transport à  l’apparition  du%%HIGHLIGHT%% ==soleil== %%POSTFIX%%de  vos  beautés ;  et,  comme*
>%%LINK%%[[#^2sf7errp5v6|show annotation]]
>%%COMMENT%%
>métaphore de la femme
>%%TAGS%%
>
^2sf7errp5v6


>%%
>```annotation-json
>{"created":"2022-06-24T09:02:09.335Z","text":"langage profane mélé au language religieux","updated":"2022-06-24T09:02:09.335Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":24230,"end":24252},{"type":"TextQuoteSelector","exact":"l’autel de vos charmes","prefix":"le, que j’appende aujourd’hui à ","suffix":" 25 l’offrande  de  ce  cœur  qu"}]}]}
>```
>%%
>*%%PREFIX%%le, que j’appende aujourd’hui à%%HIGHLIGHT%% ==l’autel de vos charmes== %%POSTFIX%%25 l’offrande  de  ce  cœur  qu*
>%%LINK%%[[#^ti4hbwxcvh|show annotation]]
>%%COMMENT%%
>langage profane mélé au language religieux
>%%TAGS%%
>
^ti4hbwxcvh


>%%
>```annotation-json
>{"created":"2022-06-24T09:03:08.663Z","text":"la femme semble sacré","updated":"2022-06-24T09:03:08.663Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":24256,"end":24266},{"type":"TextQuoteSelector","exact":"l’offrande","prefix":"hui à l’autel de vos charmes 25 ","suffix":"  de  ce  cœur  qui  ne  respire"}]}]}
>```
>%%
>*%%PREFIX%%hui à l’autel de vos charmes 25%%HIGHLIGHT%% ==l’offrande== %%POSTFIX%%de  ce  cœur  qui  ne  respire*
>%%LINK%%[[#^3r456mfoox2|show annotation]]
>%%COMMENT%%
>la femme semble sacré
>%%TAGS%%
>
^3r456mfoox2


>%%
>```annotation-json
>{"created":"2022-06-24T13:50:01.837Z","text":"marque d'une réplique interrogative","updated":"2022-06-24T13:50:01.837Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21479,"end":21485},{"type":"TextQuoteSelector","exact":"Quoi ?","prefix":"aginaire de Molière TOINETTE. – ","suffix":" Monsieur, vous auriez fait ce d"}]}]}
>```
>%%
>*%%PREFIX%%aginaire de Molière TOINETTE. –%%HIGHLIGHT%% ==Quoi ?== %%POSTFIX%%Monsieur, vous auriez fait ce d*
>%%LINK%%[[#^zd9snnfcmjp|show annotation]]
>%%COMMENT%%
>marque d'une réplique interrogative
>%%TAGS%%
>
^zd9snnfcmjp


>%%
>```annotation-json
>{"created":"2022-06-24T13:56:58.477Z","text":"thème de l'échange et de l'obstacle ","updated":"2022-06-24T13:56:58.477Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21586,"end":21620},{"type":"TextQuoteSelector","exact":"marier votre fille avec un médecin","prefix":"en que vous avez, vous voudriez ","suffix":" ? ARGAN. – Oui. De quoi te mêle"}]}]}
>```
>%%
>*%%PREFIX%%en que vous avez, vous voudriez%%HIGHLIGHT%% ==marier votre fille avec un médecin== %%POSTFIX%%? ARGAN. – Oui. De quoi te mêle*
>%%LINK%%[[#^mppnlsfltbn|show annotation]]
>%%COMMENT%%
>thème de l'échange et de l'obstacle 
>%%TAGS%%
>
^mppnlsfltbn


>%%
>```annotation-json
>{"created":"2022-06-24T13:59:04.778Z","text":"montre qu'elle n'a pas peur","updated":"2022-06-24T13:59:04.778Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21536,"end":21570},{"type":"TextQuoteSelector","exact":"Et avec tout le bien que vous avez","prefix":"iez fait ce dessein burlesque ? ","suffix":", vous voudriez marier votre fil"}]}]}
>```
>%%
>*%%PREFIX%%iez fait ce dessein burlesque ?%%HIGHLIGHT%% ==Et avec tout le bien que vous avez== %%POSTFIX%%, vous voudriez marier votre fil*
>%%LINK%%[[#^svlyp4p1a3|show annotation]]
>%%COMMENT%%
>montre qu'elle n'a pas peur
>%%TAGS%%
>
^svlyp4p1a3


>%%
>```annotation-json
>{"created":"2022-06-24T13:59:40.539Z","text":"effrontée","updated":"2022-06-24T13:59:40.539Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21658,"end":21676},{"type":"TextQuoteSelector","exact":"coquine, impudente","prefix":"AN. – Oui. De quoi te mêles-tu, ","suffix":" que tu es ? TOINETTE. – Mon Die"}]}]}
>```
>%%
>*%%PREFIX%%AN. – Oui. De quoi te mêles-tu,%%HIGHLIGHT%% ==coquine, impudente== %%POSTFIX%%que tu es ? TOINETTE. – Mon Die*
>%%LINK%%[[#^lo634lv8lcl|show annotation]]
>%%COMMENT%%
>effrontée
>%%TAGS%%
>
^lo634lv8lcl


>%%
>```annotation-json
>{"created":"2022-06-24T14:00:24.018Z","text":"franc parler de Toinette","updated":"2022-06-24T14:00:24.018Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21486,"end":21495},{"type":"TextQuoteSelector","exact":"Monsieur,","prefix":"e de Molière TOINETTE. – Quoi ? ","suffix":" vous auriez fait ce dessein bur"}]}]}
>```
>%%
>*%%PREFIX%%e de Molière TOINETTE. – Quoi ?%%HIGHLIGHT%% ==Monsieur,== %%POSTFIX%%vous auriez fait ce dessein bur*
>%%LINK%%[[#^eqwedd236g|show annotation]]
>%%COMMENT%%
>franc parler de Toinette
>%%TAGS%%
>
^eqwedd236g


>%%
>```annotation-json
>{"created":"2022-06-24T14:01:53.150Z","text":"ne trouve pas normal d'être traitée de la sorte","updated":"2022-06-24T14:01:53.150Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21747,"end":21757},{"type":"TextQuoteSelector","exact":"invectives","prefix":"t doux : vous allez d'abord aux ","suffix":". Est-ce que nous ne pouvons pas"}]}]}
>```
>%%
>*%%PREFIX%%t doux : vous allez d'abord aux%%HIGHLIGHT%% ==invectives== %%POSTFIX%%. Est-ce que nous ne pouvons pas*
>%%LINK%%[[#^wwncxsbyizs|show annotation]]
>%%COMMENT%%
>ne trouve pas normal d'être traitée de la sorte
>%%TAGS%%
>
^wwncxsbyizs


>%%
>```annotation-json
>{"created":"2022-06-24T14:06:08.281Z","text":"inversion de la situation","updated":"2022-06-24T14:06:08.281Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21711,"end":21721},{"type":"TextQuoteSelector","exact":" tout doux","prefix":"e tu es ? TOINETTE. – Mon Dieu !","suffix":" : vous allez d'abord aux invect"}]}]}
>```
>%%
>*%%PREFIX%%e tu es ? TOINETTE. – Mon Dieu !%%HIGHLIGHT%% ==tout doux== %%POSTFIX%%: vous allez d'abord aux invect*
>%%LINK%%[[#^aa6widwmej9|show annotation]]
>%%COMMENT%%
>inversion de la situation
>%%TAGS%%
>
^aa6widwmej9


>%%
>```annotation-json
>{"created":"2022-06-24T14:06:46.033Z","text":"lexique de la raison","updated":"2022-06-24T14:06:46.033Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21790,"end":21799},{"type":"TextQuoteSelector","exact":"raisonner","prefix":" Est-ce que nous ne pouvons pas ","suffix":" ensemble sans nous emporter ? L"}]}]}
>```
>%%
>*%%PREFIX%%Est-ce que nous ne pouvons pas%%HIGHLIGHT%% ==raisonner== %%POSTFIX%%ensemble sans nous emporter ? L*
>%%LINK%%[[#^p9gghvdsz3i|show annotation]]
>%%COMMENT%%
>lexique de la raison
>%%TAGS%%
>
^p9gghvdsz3i


>%%
>```annotation-json
>{"created":"2022-06-24T14:07:10.841Z","text":"lexique de la maitrise","updated":"2022-06-24T14:07:10.841Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21809,"end":21827},{"type":"TextQuoteSelector","exact":"sans nous emporter","prefix":" pouvons pas raisonner ensemble ","suffix":" ? Là, parlons de sang-froid. Qu"}]}]}
>```
>%%
>*%%PREFIX%%pouvons pas raisonner ensemble%%HIGHLIGHT%% ==sans nous emporter== %%POSTFIX%%? Là, parlons de sang-froid. Qu*
>%%LINK%%[[#^x41uz7p78z|show annotation]]
>%%COMMENT%%
>lexique de la maitrise
>%%TAGS%%
>
^x41uz7p78z


>%%
>```annotation-json
>{"created":"2022-06-24T14:08:01.496Z","text":"elle montre qu'il n'a pas les valeurs et qualités classiques (de l'époque)","updated":"2022-06-24T14:08:01.496Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21857,"end":21882},{"type":"TextQuoteSelector","exact":"Quelle est 5 votre raison","prefix":"er ? Là, parlons de sang-froid. ","suffix":", s'il vous plaît, pour un tel m"}]}]}
>```
>%%
>*%%PREFIX%%er ? Là, parlons de sang-froid.%%HIGHLIGHT%% ==Quelle est 5 votre raison== %%POSTFIX%%, s'il vous plaît, pour un tel m*
>%%LINK%%[[#^b3h7nw5tcji|show annotation]]
>%%COMMENT%%
>elle montre qu'il n'a pas les valeurs et qualités classiques (de l'époque)
>%%TAGS%%
>
^b3h7nw5tcji


>%%
>```annotation-json
>{"created":"2022-06-24T14:09:38.112Z","text":"on le voit comme quelqu'un de malade psychologiquement","updated":"2022-06-24T14:09:38.112Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21930,"end":21932},{"type":"TextQuoteSelector","exact":"– ","prefix":"t, pour un tel mariage ? ARGAN. ","suffix":"Ma raison est que, me voyant inf"}]}]}
>```
>%%
>*%%PREFIX%%t, pour un tel mariage ? ARGAN.%%HIGHLIGHT%% ==–== %%POSTFIX%%Ma raison est que, me voyant inf*
>%%LINK%%[[#^ls2uphn28d|show annotation]]
>%%COMMENT%%
>on le voit comme quelqu'un de malade psychologiquement
>%%TAGS%%
>
^ls2uphn28d


>%%
>```annotation-json
>{"created":"2022-06-24T14:10:36.763Z","text":"elle lui montre qu'il déraisonne","updated":"2022-06-24T14:10:36.763Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21906,"end":21912},{"type":"TextQuoteSelector","exact":"un tel","prefix":"e raison, s'il vous plaît, pour ","suffix":" mariage ? ARGAN. – Ma raison es"}]}]}
>```
>%%
>*%%PREFIX%%e raison, s'il vous plaît, pour%%HIGHLIGHT%% ==un tel== %%POSTFIX%%mariage ? ARGAN. – Ma raison es*
>%%LINK%%[[#^42ky0yl3cqb|show annotation]]
>%%COMMENT%%
>elle lui montre qu'il déraisonne
>%%TAGS%%
>
^42ky0yl3cqb


>%%
>```annotation-json
>{"created":"2022-06-24T14:18:19.837Z","text":"Elle défend Angélique (elle est sa confidente)","updated":"2022-06-24T14:18:19.837Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":22349,"end":22366},{"type":"TextQuoteSelector","exact":" Mais, Monsieur, ","prefix":"re doucement les uns aux autres.","suffix":"mettez la main à la conscience :"}]}]}
>```
>%%
>*%%PREFIX%%re doucement les uns aux autres.%%HIGHLIGHT%% ==Mais, Monsieur,== %%POSTFIX%%mettez la main à la conscience :*
>%%LINK%%[[#^4747vsgfuux|show annotation]]
>%%COMMENT%%
>Elle défend Angélique (elle est sa confidente)
>%%TAGS%%
>
^4747vsgfuux


>%%
>```annotation-json
>{"created":"2022-06-24T14:22:16.221Z","text":"expose clairement","updated":"2022-06-24T14:22:16.221Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21995,"end":22048},{"type":"TextQuoteSelector","exact":"e veux me faire un  gendre  et  des  alliés  médecins","prefix":"firme et malade comme je suis, j","suffix":",  afin  de  m'appuyer  de  bons"}]}]}
>```
>%%
>*%%PREFIX%%firme et malade comme je suis, j%%HIGHLIGHT%% ==e veux me faire un  gendre  et  des  alliés  médecins== %%POSTFIX%%,  afin  de  m'appuyer  de  bons*
>%%LINK%%[[#^epfaqce36qa|show annotation]]
>%%COMMENT%%
>expose clairement
>%%TAGS%%
>
^epfaqce36qa


>%%
>```annotation-json
>{"created":"2022-06-24T14:22:43.642Z","text":"hyperbolique (faire sourire le spectateur)","updated":"2022-06-24T14:22:43.642Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21961,"end":21968},{"type":"TextQuoteSelector","exact":"infirme","prefix":" – Ma raison est que, me voyant ","suffix":" et malade comme je suis, je veu"}]}]}
>```
>%%
>*%%PREFIX%%– Ma raison est que, me voyant%%HIGHLIGHT%% ==infirme== %%POSTFIX%%et malade comme je suis, je veu*
>%%LINK%%[[#^tw2s5n89t4|show annotation]]
>%%COMMENT%%
>hyperbolique (faire sourire le spectateur)
>%%TAGS%%
>
^tw2s5n89t4


>%%
>```annotation-json
>{"created":"2022-06-24T14:23:31.922Z","text":"lexique de la médecine pour appuyer son argumentation","updated":"2022-06-24T14:23:31.922Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":22202,"end":22238},{"type":"TextQuoteSelector","exact":"des consultations et des ordonnances","prefix":"t nécessaires, et d'être à même ","suffix":". 10 TOINETTE. – Hé bien ! voilà"}]}]}
>```
>%%
>*%%PREFIX%%t nécessaires, et d'être à même%%HIGHLIGHT%% ==des consultations et des ordonnances== %%POSTFIX%%. 10 TOINETTE. – Hé bien ! voilà*
>%%LINK%%[[#^r3bkb71uzc|show annotation]]
>%%COMMENT%%
>lexique de la médecine pour appuyer son argumentation
>%%TAGS%%
>
^r3bkb71uzc


>%%
>```annotation-json
>{"created":"2022-06-24T14:24:51.910Z","text":"Hypertrophie du moi ; montre égoïsme","updated":"2022-06-24T14:24:51.910Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21932,"end":21934},{"type":"TextQuoteSelector","exact":"Ma","prefix":" pour un tel mariage ? ARGAN. – ","suffix":" raison est que, me voyant infir"}]}]}
>```
>%%
>*%%PREFIX%%pour un tel mariage ? ARGAN. –%%HIGHLIGHT%% ==Ma== %%POSTFIX%%raison est que, me voyant infir*
>%%LINK%%[[#^uq771fnt2d|show annotation]]
>%%COMMENT%%
>Hypertrophie du moi ; montre égoïsme
>%%TAGS%%
>
^uq771fnt2d


>%%
>```annotation-json
>{"created":"2022-06-24T14:25:48.463Z","text":"ironie ","updated":"2022-06-24T14:25:48.463Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":22255,"end":22286},{"type":"TextQuoteSelector","exact":"Hé bien ! voilà dire une raison","prefix":"des ordonnances. 10 TOINETTE. – ","suffix":", et il y a plaisir à se répondr"}]}]}
>```
>%%
>*%%PREFIX%%des ordonnances. 10 TOINETTE. –%%HIGHLIGHT%% ==Hé bien ! voilà dire une raison== %%POSTFIX%%, et il y a plaisir à se répondr*
>%%LINK%%[[#^pel8k8gg8o|show annotation]]
>%%COMMENT%%
>ironie 
>%%TAGS%%
>
^pel8k8gg8o


>%%
>```annotation-json
>{"created":"2022-06-24T14:26:29.246Z","text":"maladie mentale","updated":"2022-06-24T14:26:29.246Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":22651,"end":22684},{"type":"TextQuoteSelector","exact":"et plus malade que vous ne pensez","prefix":" malade, j'en demeure d'accord, ","suffix":" : voilà 15 qui est fait. Mais v"}]}]}
>```
>%%
>*%%PREFIX%%malade, j'en demeure d'accord,%%HIGHLIGHT%% ==et plus malade que vous ne pensez== %%POSTFIX%%: voilà 15 qui est fait. Mais v*
>%%LINK%%[[#^key113zpgy|show annotation]]
>%%COMMENT%%
>maladie mentale
>%%TAGS%%
>
^key113zpgy


>%%
>```annotation-json
>{"created":"2022-06-24T14:26:54.365Z","text":"amplifie le mot malade","updated":"2022-06-24T14:26:54.365Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":22615,"end":22626},{"type":"TextQuoteSelector","exact":"fort malade","prefix":"elle là-dessus ; oui, vous êtes ","suffix":", j'en demeure d'accord, et plus"}]}]}
>```
>%%
>*%%PREFIX%%elle là-dessus ; oui, vous êtes%%HIGHLIGHT%% ==fort malade== %%POSTFIX%%, j'en demeure d'accord, et plus*
>%%LINK%%[[#^ulg6nodwhap|show annotation]]
>%%COMMENT%%
>amplifie le mot malade
>%%TAGS%%
>
^ulg6nodwhap


>%%
>```annotation-json
>{"created":"2022-06-24T14:27:39.459Z","text":"conserve son sang-froid","updated":"2022-06-24T14:27:39.459Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":22518,"end":22533},{"type":"TextQuoteSelector","exact":" Hé bien ! oui,","prefix":" malade, impudente ? TOINETTE. –","suffix":" Monsieur, vous êtes malade, n'a"}]}]}
>```
>%%
>*%%PREFIX%%malade, impudente ? TOINETTE. –%%HIGHLIGHT%% ==Hé bien ! oui,== %%POSTFIX%%Monsieur, vous êtes malade, n'a*
>%%LINK%%[[#^abklhuyo8y8|show annotation]]
>%%COMMENT%%
>conserve son sang-froid
>%%TAGS%%
>
^abklhuyo8y8


>%%
>```annotation-json
>{"created":"2022-06-24T14:29:12.493Z","text":"la situation semble être impossible pour qu'Angélique ne se marie pas avec Thomas Diafoirus","updated":"2022-06-24T14:29:12.493Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":22710,"end":22726},{"type":"TextQuoteSelector","exact":"Mais votre fille","prefix":"pensez : voilà 15 qui est fait. ","suffix":" doit épouser un mari pour elle "}]}]}
>```
>%%
>*%%PREFIX%%pensez : voilà 15 qui est fait.%%HIGHLIGHT%% ==Mais votre fille== %%POSTFIX%%doit épouser un mari pour elle*
>%%LINK%%[[#^hvzibzo986|show annotation]]
>%%COMMENT%%
>la situation semble être impossible pour qu'Angélique ne se marie pas avec Thomas Diafoirus
>%%TAGS%%
>
^hvzibzo986


>%%
>```annotation-json
>{"created":"2022-06-24T14:30:29.692Z","text":"raisonnement logique pour faire face à Argan","updated":"2022-06-24T14:30:29.692Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":22764,"end":22834},{"type":"TextQuoteSelector","exact":"n'étant point malade, il n'est pas nécessaire de lui donner un médecin","prefix":"épouser un mari pour elle ; et, ","suffix":". ARGAN. – C'est pour moi que je"}]}]}
>```
>%%
>*%%PREFIX%%épouser un mari pour elle ; et,%%HIGHLIGHT%% ==n'étant point malade, il n'est pas nécessaire de lui donner un médecin== %%POSTFIX%%. ARGAN. – C'est pour moi que je*
>%%LINK%%[[#^0ptgm3sf4ylj|show annotation]]
>%%COMMENT%%
>raisonnement logique pour faire face à Argan
>%%TAGS%%
>
^0ptgm3sf4ylj


>%%
>```annotation-json
>{"created":"2022-06-24T14:31:16.678Z","text":"- comique\n- rappelle l'égocentrisme et c'est déconcertant pour Toinette.","updated":"2022-06-24T14:31:16.678Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":22845,"end":22887},{"type":"TextQuoteSelector","exact":"C'est pour moi que je lui donne ce médecin","prefix":"lui donner un médecin. ARGAN. – ","suffix":" ; et une fille de bon naturel d"}]}]}
>```
>%%
>*%%PREFIX%%lui donner un médecin. ARGAN. –%%HIGHLIGHT%% ==C'est pour moi que je lui donne ce médecin== %%POSTFIX%%; et une fille de bon naturel d*
>%%LINK%%[[#^gp0ivq1yql|show annotation]]
>%%COMMENT%%
>- comique
>- rappelle l'égocentrisme et c'est déconcertant pour Toinette.
>%%TAGS%%
>
^gp0ivq1yql


>%%
>```annotation-json
>{"created":"2022-06-24T14:32:25.675Z","text":"pronom personnel","updated":"2022-06-24T14:32:25.675Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":22856,"end":22859},{"type":"TextQuoteSelector","exact":"moi","prefix":"un médecin. ARGAN. – C'est pour ","suffix":" que je lui donne ce médecin ; e"}]}]}
>```
>%%
>*%%PREFIX%%un médecin. ARGAN. – C'est pour%%HIGHLIGHT%% ==moi== %%POSTFIX%%que je lui donne ce médecin ; e*
>%%LINK%%[[#^3ibgbhr80f6|show annotation]]
>%%COMMENT%%
>pronom personnel
>%%TAGS%%
>
^3ibgbhr80f6


>%%
>```annotation-json
>{"created":"2022-06-24T14:33:05.220Z","text":"laisse suggérer que la fille devrait laisser son père utiliser une partie de sa vie, *ce qui est à toi est à moi* ","updated":"2022-06-24T14:33:05.220Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":22944,"end":22985},{"type":"TextQuoteSelector","exact":"ce qui est utile à la santé de son père. ","prefix":"turel doit être ravie d'épouser ","suffix":" Molière, Le Malade imaginaire, "}]}]}
>```
>%%
>*%%PREFIX%%turel doit être ravie d'épouser%%HIGHLIGHT%% ==ce qui est utile à la santé de son père.== %%POSTFIX%%Molière, Le Malade imaginaire,*
>%%LINK%%[[#^xqxju7tpaci|show annotation]]
>%%COMMENT%%
>laisse suggérer que la fille devrait laisser son père utiliser une partie de sa vie, *ce qui est à toi est à moi* 
>%%TAGS%%
>
^xqxju7tpaci


>%%
>```annotation-json
>{"created":"2022-06-24T14:35:20.659Z","text":"scène destinée à faire plaisir au spectateur dans un dialogue vif et dynamique","updated":"2022-06-24T14:35:20.659Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":23038,"end":23046},{"type":"TextQuoteSelector","exact":"scène 5 ","prefix":"maginaire, extrait de l’acte I, ","suffix":"        14 Extrait n°2 de l’œuvr"}]}]}
>```
>%%
>*%%PREFIX%%maginaire, extrait de l’acte I,%%HIGHLIGHT%% ==scène 5== %%POSTFIX%%14 Extrait n°2 de l’œuvr*
>%%LINK%%[[#^gd4p19fc8gk|show annotation]]
>%%COMMENT%%
>scène destinée à faire plaisir au spectateur dans un dialogue vif et dynamique
>%%TAGS%%
>
^gd4p19fc8gk


>%%
>```annotation-json
>{"created":"2022-06-24T14:36:37.326Z","text":"servante qui cherche à arranger les situations pénibles","updated":"2022-06-24T14:36:37.326Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21467,"end":21475},{"type":"TextQuoteSelector","exact":"TOINETTE","prefix":"Le Malade imaginaire de Molière ","suffix":". – Quoi ? Monsieur, vous auriez"}]}]}
>```
>%%
>*%%PREFIX%%Le Malade imaginaire de Molière%%HIGHLIGHT%% ==TOINETTE== %%POSTFIX%%. – Quoi ? Monsieur, vous auriez*
>%%LINK%%[[#^gdzagntf4hi|show annotation]]
>%%COMMENT%%
>servante qui cherche à arranger les situations pénibles
>%%TAGS%%
>
^gdzagntf4hi


>%%
>```annotation-json
>{"created":"2022-06-24T14:37:31.864Z","text":"extrait avec comique \n- de situation\n- de language\n- de caractère","updated":"2022-06-24T14:37:31.864Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":22986,"end":23046},{"type":"TextQuoteSelector","exact":"Molière, Le Malade imaginaire, extrait de l’acte I, scène 5 ","prefix":" utile à la santé de son père.  ","suffix":"        14 Extrait n°2 de l’œuvr"}]}]}
>```
>%%
>*%%PREFIX%%utile à la santé de son père.%%HIGHLIGHT%% ==Molière, Le Malade imaginaire, extrait de l’acte I, scène 5== %%POSTFIX%%14 Extrait n°2 de l’œuvr*
>%%LINK%%[[#^bzcqulmq5us|show annotation]]
>%%COMMENT%%
>extrait avec comique 
>- de situation
>- de language
>- de caractère
>%%TAGS%%
>
^bzcqulmq5us


>%%
>```annotation-json
>{"created":"2022-06-24T14:39:01.329Z","text":"rapport maitre / serviteur","updated":"2022-06-24T14:39:01.329Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/textes_oral_bac.pdf","target":[{"source":"vault:/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21400,"end":21411},{"type":"TextQuoteSelector","exact":"Extrait n°1","prefix":"ance, vers 157-192, 1913.  13   ","suffix":" de l’œuvre intégrale : Le Malad"}]}]}
>```
>%%
>*%%PREFIX%%ance, vers 157-192, 1913.  13%%HIGHLIGHT%% ==Extrait n°1== %%POSTFIX%%de l’œuvre intégrale : Le Malad*
>%%LINK%%[[#^w9cuwdjmml|show annotation]]
>%%COMMENT%%
>rapport maitre / serviteur
>%%TAGS%%
>
^w9cuwdjmml


>%%
>```annotation-json
>{"created":"2022-06-25T13:15:41.122Z","text":"Anaphore, écho au mot route","updated":"2022-06-25T13:15:41.122Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20089,"end":20091},{"type":"TextQuoteSelector","exact":"Je","prefix":"QUE ?     Je suis en route...   ","suffix":" suis en route J’ai toujours été"}]}]}
>```
>%%
>*%%PREFIX%%QUE ?     Je suis en route...%%HIGHLIGHT%% ==Je== %%POSTFIX%%suis en route J’ai toujours été*
>%%LINK%%[[#^x419sengngd|show annotation]]
>%%COMMENT%%
>Anaphore, écho au mot route
>%%TAGS%%
>
^x419sengngd


>%%
>```annotation-json
>{"created":"2022-06-25T13:18:24.372Z","text":"Le poète s'inscrit comme voyageur à différentes époques","updated":"2022-06-25T13:18:24.372Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20092,"end":20132},{"type":"TextQuoteSelector","exact":"suis en route J’ai toujours été en route","prefix":" ?     Je suis en route...   Je ","suffix":" Je suis en route avec la petite"}]}]}
>```
>%%
>*%%PREFIX%%?     Je suis en route...   Je%%HIGHLIGHT%% ==suis en route J’ai toujours été en route== %%POSTFIX%%Je suis en route avec la petite*
>%%LINK%%[[#^2g7q9gip46s|show annotation]]
>%%COMMENT%%
>Le poète s'inscrit comme voyageur à différentes époques
>%%TAGS%%
>
^2g7q9gip46s


>%%
>```annotation-json
>{"created":"2022-06-25T13:19:42.382Z","text":"Adverbe résonne avec le 1° vers","updated":"2022-06-25T13:19:42.382Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20111,"end":20119},{"type":"TextQuoteSelector","exact":"toujours","prefix":"oute...   Je suis en route J’ai ","suffix":" été en route Je suis en route a"}]}]}
>```
>%%
>*%%PREFIX%%oute...   Je suis en route J’ai%%HIGHLIGHT%% ==toujours== %%POSTFIX%%été en route Je suis en route a*
>%%LINK%%[[#^pnvajjlsdhd|show annotation]]
>%%COMMENT%%
>Adverbe résonne avec le 1° vers
>%%TAGS%%
>
^pnvajjlsdhd


>%%
>```annotation-json
>{"text":"- Elle peut ici évoquer \"Jeanne\" le personnage féminin que l'on trouve dans le poème, jeune prostituée.\n- mais elle peut aussi évoquer la fille de Louis 11 et Charles de Savoie, jeune fille diforme qui se tourne vers la spiritualité\n- elle peutt aussi représenter l'allégorie de le France pays d'adoption de Cendrars\n\nUne Jeanne l'accompagne dans le train imaginaire","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20165,"end":20182},{"type":"TextQuoteSelector","exact":"Jehanne de France","prefix":"Je suis en route avec la petite","suffix":". 5  Le train fait un saut péril"}]}],"created":"2022-06-25T13:21:06.661Z","updated":"2022-06-25T13:21:06.661Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf"}
>```
>%%
>*%%PREFIX%%Je suis en route avec la petite%%HIGHLIGHT%% ==Jehanne de France== %%POSTFIX%%. 5  Le train fait un saut péril*
>%%LINK%%[[#^br1q9rst41e|show annotation]]
>%%COMMENT%%
>- Elle peut ici évoquer "Jeanne" le personnage féminin que l'on trouve dans le poème, jeune prostituée.
>- mais elle peut aussi évoquer la fille de Louis 11 et Charles de Savoie, jeune fille diforme qui se tourne vers la spiritualité
>- elle peutt aussi représenter l'allégorie de le France pays d'adoption de Cendrars
>
>Une Jeanne l'accompagne dans le train imaginaire
>%%TAGS%%
>
^br1q9rst41e


>%%
>```annotation-json
>{"created":"2022-06-25T13:23:55.164Z","text":"Inscrit le poème dans différentes époques","updated":"2022-06-25T13:23:55.164Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20133,"end":20183},{"type":"TextQuoteSelector","exact":"Je suis en route avec la petite Jehanne de France.","prefix":"oute J’ai toujours été en route ","suffix":" 5  Le train fait un saut périll"}]}]}
>```
>%%
>*%%PREFIX%%oute J’ai toujours été en route%%HIGHLIGHT%% ==Je suis en route avec la petite Jehanne de France.== %%POSTFIX%%5  Le train fait un saut périll*
>%%LINK%%[[#^92ixh5velw7|show annotation]]
>%%COMMENT%%
>Inscrit le poème dans différentes époques
>%%TAGS%%
>
^92ixh5velw7


>%%
>```annotation-json
>{"created":"2022-06-25T13:28:09.572Z","text":"Anaphore imitant le rythme du train","updated":"2022-06-25T13:28:09.572Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20187,"end":20195},{"type":"TextQuoteSelector","exact":"Le train","prefix":"la petite Jehanne de France. 5  ","suffix":" fait un saut périlleux et retom"}]}]}
>```
>%%
>*%%PREFIX%%la petite Jehanne de France. 5%%HIGHLIGHT%% ==Le train== %%POSTFIX%%fait un saut périlleux et retom*
>%%LINK%%[[#^zlvrinzug9o|show annotation]]
>%%COMMENT%%
>Anaphore imitant le rythme du train
>%%TAGS%%
>
^zlvrinzug9o


>%%
>```annotation-json
>{"created":"2022-06-25T13:32:08.613Z","text":"les allitérations en r et en t font entendre son bruit.","updated":"2022-06-25T13:32:08.613Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20211,"end":20212},{"type":"TextQuoteSelector","exact":"r","prefix":"nce. 5  Le train fait un saut pé","suffix":"illeux et retombe sur toutes ses"}]}]}
>```
>%%
>*%%PREFIX%%nce. 5  Le train fait un saut pé%%HIGHLIGHT%% ==r== %%POSTFIX%%illeux et retombe sur toutes ses*
>%%LINK%%[[#^y7woq92i0uf|show annotation]]
>%%COMMENT%%
>les allitérations en r et en t font entendre son bruit.
>%%TAGS%%
>
^y7woq92i0uf


>%%
>```annotation-json
>{"created":"2022-06-25T13:33:13.557Z","text":"Le train est personnifié, ce qui donne un caractère fantastique ","updated":"2022-06-25T13:33:13.557Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20201,"end":20250},{"type":"TextQuoteSelector","exact":"un saut périlleux et retombe sur toutes ses roues","prefix":"nne de France. 5  Le train fait ","suffix":" Le train retombe sur ses roues "}]}]}
>```
>%%
>*%%PREFIX%%nne de France. 5  Le train fait%%HIGHLIGHT%% ==un saut périlleux et retombe sur toutes ses roues== %%POSTFIX%%Le train retombe sur ses roues*
>%%LINK%%[[#^iu7n4ernbs|show annotation]]
>%%COMMENT%%
>Le train est personnifié, ce qui donne un caractère fantastique 
>%%TAGS%%
>
^iu7n4ernbs


>%%
>```annotation-json
>{"created":"2022-06-25T13:34:21.840Z","text":"Epiphore (anaphore mais pas au début) ","updated":"2022-06-25T13:34:21.840Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20230,"end":20250},{"type":"TextQuoteSelector","exact":"sur toutes ses roues","prefix":"it un saut périlleux et retombe ","suffix":" Le train retombe sur ses roues "}]}]}
>```
>%%
>*%%PREFIX%%it un saut périlleux et retombe%%HIGHLIGHT%% ==sur toutes ses roues== %%POSTFIX%%Le train retombe sur ses roues*
>%%LINK%%[[#^c084nydwvgo|show annotation]]
>%%COMMENT%%
>Epiphore (anaphore mais pas au début) 
>%%TAGS%%
>
^c084nydwvgo


>%%
>```annotation-json
>{"created":"2022-06-25T13:37:13.575Z","text":"Éloge de la machine\nRésonne poétiquement avec modernité ","updated":"2022-06-25T13:37:13.575Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20282,"end":20329},{"type":"TextQuoteSelector","exact":"Le train retombe toujours sur toutes ses roues.","prefix":" Le train retombe sur ses roues ","suffix":"  10 “Blaise, dis, sommes-nous b"}]}]}
>```
>%%
>*%%PREFIX%%Le train retombe sur ses roues%%HIGHLIGHT%% ==Le train retombe toujours sur toutes ses roues.== %%POSTFIX%%10 “Blaise, dis, sommes-nous b*
>%%LINK%%[[#^jkqw9trq52f|show annotation]]
>%%COMMENT%%
>Éloge de la machine
>Résonne poétiquement avec modernité 
>%%TAGS%%
>
^jkqw9trq52f


>%%
>```annotation-json
>{"text":"Associé deux lieux différents :\n- Paris où Blaise Cendrars fréquente Jeanne à Montmartre \n- comme le personnage qui l'accompagne dans le train qui est imaginaire","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20334,"end":20386},{"type":"TextQuoteSelector","exact":"“Blaise, dis, sommes-nous bien loin de Montmartre ?”","prefix":"jours sur toutes ses roues.  10","suffix":"Nous sommes loin, Jeanne, tu r"}]}],"created":"2022-06-25T13:53:19.814Z","updated":"2022-06-25T13:53:19.814Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf"}
>```
>%%
>*%%PREFIX%%jours sur toutes ses roues.  10%%HIGHLIGHT%% ==“Blaise, dis, sommes-nous bien loin de Montmartre ?”== %%POSTFIX%%Nous sommes loin, Jeanne, tu r*
>%%LINK%%[[#^fmsc87gq2hp|show annotation]]
>%%COMMENT%%
>Associé deux lieux différents :
>- Paris où Blaise Cendrars fréquente Jeanne à Montmartre 
>- comme le personnage qui l'accompagne dans le train qui est imaginaire
>%%TAGS%%
>
^fmsc87gq2hp


>%%
>```annotation-json
>{"created":"2022-06-25T14:19:43.276Z","text":"Orthographe différente et correspond au présent d'énonciation parce que c'est le temps de l'écriture du poème","updated":"2022-06-25T14:19:43.276Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20388,"end":20412},{"type":"TextQuoteSelector","exact":"Nous sommes loin, Jeanne","prefix":"ous bien loin de Montmartre ?”  ","suffix":", tu roules depuis sept jours Tu"}]}]}
>```
>%%
>*%%PREFIX%%ous bien loin de Montmartre ?”%%HIGHLIGHT%% ==Nous sommes loin, Jeanne== %%POSTFIX%%, tu roules depuis sept jours Tu*
>%%LINK%%[[#^k4llxr74wz|show annotation]]
>%%COMMENT%%
>Orthographe différente et correspond au présent d'énonciation parce que c'est le temps de l'écriture du poème
>%%TAGS%%
>
^k4llxr74wz


>%%
>```annotation-json
>{"created":"2022-06-25T14:23:16.582Z","text":"Relance le voyage poétique","updated":"2022-06-25T14:23:16.582Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20414,"end":20441},{"type":"TextQuoteSelector","exact":"tu roules depuis sept jours","prefix":"e ?”  Nous sommes loin, Jeanne, ","suffix":" Tu es loin de Montmartre, de la"}]}]}
>```
>%%
>*%%PREFIX%%e ?”  Nous sommes loin, Jeanne,%%HIGHLIGHT%% ==tu roules depuis sept jours== %%POSTFIX%%Tu es loin de Montmartre, de la*
>%%LINK%%[[#^rt9y8dafhp|show annotation]]
>%%COMMENT%%
>Relance le voyage poétique
>%%TAGS%%
>
^rt9y8dafhp


>%%
>```annotation-json
>{"created":"2022-06-25T15:24:15.262Z","text":"Champs lexical de la protection laissant apparaître la Sibérie ","updated":"2022-06-25T15:24:15.262Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20533,"end":20540},{"type":"TextQuoteSelector","exact":"blottie","prefix":"acré-Cœur contre lequel tu t’es ","suffix":" 15 Paris a disparu et son énorm"}]}]}
>```
>%%
>*%%PREFIX%%acré-Cœur contre lequel tu t’es%%HIGHLIGHT%% ==blottie== %%POSTFIX%%15 Paris a disparu et son énorm*
>%%LINK%%[[#^gg792o5zpvc|show annotation]]
>%%COMMENT%%
>Champs lexical de la protection laissant apparaître la Sibérie 
>%%TAGS%%
>
^gg792o5zpvc


>%%
>```annotation-json
>{"created":"2022-06-25T15:25:27.740Z","text":"Champs lexical de la protection laissant apparaître la Sibérie ","updated":"2022-06-25T15:25:27.740Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20488,"end":20495},{"type":"TextQuoteSelector","exact":"nourrie","prefix":"Montmartre, de la Butte qui t’a ","suffix":", du Sacré-Cœur contre lequel tu"}]}]}
>```
>%%
>*%%PREFIX%%Montmartre, de la Butte qui t’a%%HIGHLIGHT%% ==nourrie== %%POSTFIX%%, du Sacré-Cœur contre lequel tu*
>%%LINK%%[[#^mjsc0ew2ay|show annotation]]
>%%COMMENT%%
>Champs lexical de la protection laissant apparaître la Sibérie 
>%%TAGS%%
>
^mjsc0ew2ay


>%%
>```annotation-json
>{"created":"2022-06-25T15:28:36.382Z","text":"Univers parisien familier ","updated":"2022-06-25T15:28:36.382Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20474,"end":20479},{"type":"TextQuoteSelector","exact":"Butte","prefix":"Tu es loin de Montmartre, de la ","suffix":" qui t’a nourrie, du Sacré-Cœur "}]}]}
>```
>%%
>*%%PREFIX%%Tu es loin de Montmartre, de la%%HIGHLIGHT%% ==Butte== %%POSTFIX%%qui t’a nourrie, du Sacré-Cœur*
>%%LINK%%[[#^ucu23lznic|show annotation]]
>%%COMMENT%%
>Univers parisien familier 
>%%TAGS%%
>
^ucu23lznic


>%%
>```annotation-json
>{"created":"2022-06-25T15:29:20.089Z","text":"Univers parisien familier ","updated":"2022-06-25T15:29:20.089Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20500,"end":20510},{"type":"TextQuoteSelector","exact":"Sacré-Cœur","prefix":"de la Butte qui t’a nourrie, du ","suffix":" contre lequel tu t’es blottie 1"}]}]}
>```
>%%
>*%%PREFIX%%de la Butte qui t’a nourrie, du%%HIGHLIGHT%% ==Sacré-Cœur== %%POSTFIX%%contre lequel tu t’es blottie 1*
>%%LINK%%[[#^586cvlr7yan|show annotation]]
>%%COMMENT%%
>Univers parisien familier 
>%%TAGS%%
>
^586cvlr7yan


>%%
>```annotation-json
>{"created":"2022-06-25T15:29:42.883Z","text":"Univers parisien familier ","updated":"2022-06-25T15:29:42.883Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20456,"end":20466},{"type":"TextQuoteSelector","exact":"Montmartre","prefix":"depuis sept jours Tu es loin de ","suffix":", de la Butte qui t’a nourrie, d"}]}]}
>```
>%%
>*%%PREFIX%%depuis sept jours Tu es loin de%%HIGHLIGHT%% ==Montmartre== %%POSTFIX%%, de la Butte qui t’a nourrie, d*
>%%LINK%%[[#^pzi0l608csq|show annotation]]
>%%COMMENT%%
>Univers parisien familier 
>%%TAGS%%
>
^pzi0l608csq


>%%
>```annotation-json
>{"created":"2022-06-25T15:30:59.610Z","text":"Assonance de u","updated":"2022-06-25T15:30:59.610Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20559,"end":20560},{"type":"TextQuoteSelector","exact":" ","prefix":" t’es blottie 15 Paris a disparu","suffix":"et son énorme flambée Il n’y a p"}]}]}
>```
>%%
>*%%PREFIX%%t’es blottie 15 Paris a disparu%%HIGHLIGHT%% ==== %%POSTFIX%%et son énorme flambée Il n’y a p*
>%%LINK%%[[#^95uh8wjd8m|show annotation]]
>%%COMMENT%%
>Assonance de u
>%%TAGS%%
>
^95uh8wjd8m


>%%
>```annotation-json
>{"created":"2022-06-25T15:31:44.211Z","text":"Assonance de u","updated":"2022-06-25T15:31:44.211Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20558,"end":20559},{"type":"TextQuoteSelector","exact":"u","prefix":"u t’es blottie 15 Paris a dispar","suffix":" et son énorme flambée Il n’y a "}]}]}
>```
>%%
>*%%PREFIX%%u t’es blottie 15 Paris a dispar%%HIGHLIGHT%% ==u== %%POSTFIX%%et son énorme flambée Il n’y a*
>%%LINK%%[[#^2yart4pls7a|show annotation]]
>%%COMMENT%%
>Assonance de u
>%%TAGS%%
>
^2yart4pls7a


>%%
>```annotation-json
>{"created":"2022-06-25T15:35:19.624Z","text":"Fait référence à son pseudonyme ","updated":"2022-06-25T15:35:19.624Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20582,"end":20621},{"type":"TextQuoteSelector","exact":"Il n’y a plus que les cendres continues","prefix":"a disparu et son énorme flambée ","suffix":" La pluie qui tombe La tourbe qu"}]}]}
>```
>%%
>*%%PREFIX%%a disparu et son énorme flambée%%HIGHLIGHT%% ==Il n’y a plus que les cendres continues== %%POSTFIX%%La pluie qui tombe La tourbe qu*
>%%LINK%%[[#^uvl6vl0ytgr|show annotation]]
>%%COMMENT%%
>Fait référence à son pseudonyme 
>%%TAGS%%
>
^uvl6vl0ytgr


>%%
>```annotation-json
>{"created":"2022-06-25T18:30:25.402Z","text":"Le pont mirabeau est un symbole de modernité et d'union ; mais c'est là où on voit une rupture avec ce qui s'est fait avant","updated":"2022-06-25T18:30:25.402Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":16390,"end":16406},{"type":"TextQuoteSelector","exact":"Le Pont Mirabeau","prefix":"ols de Guillaume Apollinaire.   ","suffix":"  Sous le pont Mirabeau coule la"}]}]}
>```
>%%
>*%%PREFIX%%ols de Guillaume Apollinaire.%%HIGHLIGHT%% ==Le Pont Mirabeau== %%POSTFIX%%Sous le pont Mirabeau coule la*
>%%LINK%%[[#^lvdhj35p04a|show annotation]]
>%%COMMENT%%
>Le pont mirabeau est un symbole de modernité et d'union ; mais c'est là où on voit une rupture avec ce qui s'est fait avant
>%%TAGS%%
>
^lvdhj35p04a


>%%
>```annotation-json
>{"created":"2022-06-25T18:32:42.123Z","text":"Métaphore du temps qui passe","updated":"2022-06-25T18:32:42.123Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":16430,"end":16435},{"type":"TextQuoteSelector","exact":"coule","prefix":"Mirabeau  Sous le pont Mirabeau ","suffix":" la Seine Et nos amours Faut-il "}]}]}
>```
>%%
>*%%PREFIX%%Mirabeau  Sous le pont Mirabeau%%HIGHLIGHT%% ==coule== %%POSTFIX%%la Seine Et nos amours Faut-il*
>%%LINK%%[[#^4typ0evfliv|show annotation]]
>%%COMMENT%%
>Métaphore du temps qui passe
>%%TAGS%%
>
^4typ0evfliv




>%%
>```annotation-json
>{"created":"2022-06-25T18:40:09.701Z","text":"Style archaïque L'écriture est une tentative retrouver ce qu'il s'est passé dans les souvenirs","updated":"2022-06-25T18:40:09.701Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":16445,"end":16458},{"type":"TextQuoteSelector","exact":"Et nos amours","prefix":"le pont Mirabeau coule la Seine ","suffix":" Faut-il qu’il m’en souvienne La"}]}]}
>```
>%%
>*%%PREFIX%%le pont Mirabeau coule la Seine%%HIGHLIGHT%% ==Et nos amours== %%POSTFIX%%Faut-il qu’il m’en souvienne La*
>%%LINK%%[[#^f1hhrr3mgep|show annotation]]
>%%COMMENT%%
>Style archaïque L'écriture est une tentative retrouver ce qu'il s'est passé dans les souvenirs
>%%TAGS%%
>
^f1hhrr3mgep


>%%
>```annotation-json
>{"created":"2022-06-25T18:40:30.554Z","text":"Conjonction de coordination qui indique que le temps est destructeur pour apollinaire","updated":"2022-06-25T18:40:30.554Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":16445,"end":16447},{"type":"TextQuoteSelector","exact":"Et","prefix":"le pont Mirabeau coule la Seine ","suffix":" nos amours Faut-il qu’il m’en s"}]}]}
>```
>%%
>*%%PREFIX%%le pont Mirabeau coule la Seine%%HIGHLIGHT%% ==Et== %%POSTFIX%%nos amours Faut-il qu’il m’en s*
>%%LINK%%[[#^1gc1ojz2617|show annotation]]
>%%COMMENT%%
>Conjonction de coordination qui indique que le temps est destructeur pour apollinaire
>%%TAGS%%
>
^1gc1ojz2617


>%%
>```annotation-json
>{"created":"2022-06-25T18:42:35.273Z","text":"Impersonnel montre que\nLa solitude domine, tout cela a disparu -> les personnes en elles mêmes ont disparu, ce sont devenues des pensées qui répète les souvenirs de l'auteur","updated":"2022-06-25T18:42:35.273Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":16459,"end":16487},{"type":"TextQuoteSelector","exact":"Faut-il qu’il m’en souvienne","prefix":"au coule la Seine Et nos amours ","suffix":" La joie venait toujours après l"}]}]}
>```
>%%
>*%%PREFIX%%au coule la Seine Et nos amours%%HIGHLIGHT%% ==Faut-il qu’il m’en souvienne== %%POSTFIX%%La joie venait toujours après l*
>%%LINK%%[[#^61ezsno2xe4|show annotation]]
>%%COMMENT%%
>Impersonnel montre que
>La solitude domine, tout cela a disparu -> les personnes en elles mêmes ont disparu, ce sont devenues des pensées qui répète les souvenirs de l'auteur
>%%TAGS%%
>
^61ezsno2xe4


>%%
>```annotation-json
>{"created":"2022-06-25T18:43:29.680Z","text":"L'auteur demeure avec sa pensée et ses souvenirs ","updated":"2022-06-25T18:43:29.680Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":16579,"end":16590},{"type":"TextQuoteSelector","exact":"je demeure ","prefix":"nne l’heure Les jours s’en vont ","suffix":" Les mains dans les mains reston"}]}]}
>```
>%%
>*%%PREFIX%%nne l’heure Les jours s’en vont%%HIGHLIGHT%% ==je demeure== %%POSTFIX%%Les mains dans les mains reston*
>%%LINK%%[[#^pawble1wwm9|show annotation]]
>%%COMMENT%%
>L'auteur demeure avec sa pensée et ses souvenirs 
>%%TAGS%%
>
^pawble1wwm9


>%%
>```annotation-json
>{"created":"2022-06-25T18:47:03.005Z","text":"répétitions -> effet de circularité, mots fonctionnant par couple ; registre lyrique\n\n-> intimité avec Marie, l'auteur croit au bonheur partagé -> amour passé","updated":"2022-06-25T18:47:03.005Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":16591,"end":16635},{"type":"TextQuoteSelector","exact":"Les mains dans les mains restons face à face","prefix":"Les jours s’en vont je demeure  ","suffix":" 10 Tandis que sous Le pont de n"}]}]}
>```
>%%
>*%%PREFIX%%Les jours s’en vont je demeure%%HIGHLIGHT%% ==Les mains dans les mains restons face à face== %%POSTFIX%%10 Tandis que sous Le pont de n*
>%%LINK%%[[#^n6ygrl68t0j|show annotation]]
>%%COMMENT%%
>répétitions -> effet de circularité, mots fonctionnant par couple ; registre lyrique
>
>-> intimité avec Marie, l'auteur croit au bonheur partagé -> amour passé
>%%TAGS%%
>
^n6ygrl68t0j


>%%
>```annotation-json
>{"created":"2022-06-25T18:48:39.620Z","text":"Effet miroir\n\nCorrespondance entre paysage et sentiments","updated":"2022-06-25T18:48:39.620Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":16655,"end":16680},{"type":"TextQuoteSelector","exact":"Le pont de nos bras passe","prefix":" face à face 10 Tandis que sous ","suffix":" Des éternels regards l’onde si "}]}]}
>```
>%%
>*%%PREFIX%%face à face 10 Tandis que sous%%HIGHLIGHT%% ==Le pont de nos bras passe== %%POSTFIX%%Des éternels regards l’onde si*
>%%LINK%%[[#^exkxur8k198|show annotation]]
>%%COMMENT%%
>Effet miroir
>
>Correspondance entre paysage et sentiments
>%%TAGS%%
>
^exkxur8k198


>%%
>```annotation-json
>{"created":"2022-06-26T11:59:09.137Z","text":"symbole d'une grande vitesse ?","updated":"2022-06-26T11:59:09.137Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20260,"end":20281},{"type":"TextQuoteSelector","exact":"retombe sur ses roues","prefix":"e sur toutes ses roues Le train ","suffix":" Le train retombe toujours sur t"}]}]}
>```
>%%
>*%%PREFIX%%e sur toutes ses roues Le train%%HIGHLIGHT%% ==retombe sur ses roues== %%POSTFIX%%Le train retombe toujours sur t*
>%%LINK%%[[#^k8821r7afzs|show annotation]]
>%%COMMENT%%
>symbole d'une grande vitesse ?
>%%TAGS%%
>
^k8821r7afzs


>%%
>```annotation-json
>{"created":"2022-06-26T12:09:38.994Z","text":"phrases nominales accentuant les sensations à l'état brut","updated":"2022-06-26T12:09:38.994Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20622,"end":20686},{"type":"TextQuoteSelector","exact":"La pluie qui tombe La tourbe qui se gonfle La Sibérie qui tourne","prefix":" plus que les cendres continues ","suffix":" 20 Les lourdes nappes de neige "}]}]}
>```
>%%
>*%%PREFIX%%plus que les cendres continues%%HIGHLIGHT%% ==La pluie qui tombe La tourbe qui se gonfle La Sibérie qui tourne== %%POSTFIX%%20 Les lourdes nappes de neige*
>%%LINK%%[[#^8wg2fbb559o|show annotation]]
>%%COMMENT%%
>phrases nominales accentuant les sensations à l'état brut
>%%TAGS%%
>
^8wg2fbb559o


>%%
>```annotation-json
>{"created":"2022-06-26T12:11:25.127Z","text":"juxtapositions d'éléments sans explications ce qui accentue la frénétique du voyage","updated":"2022-06-26T12:11:25.127Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20690,"end":20880},{"type":"TextQuoteSelector","exact":"Les lourdes nappes de neige qui remontent Et le grelot de la folie qui grelotte comme un dernier désir dans l’air bleui Le train palpite au cœur des horizons plombés Et ton chagrin ricane...","prefix":"gonfle La Sibérie qui tourne 20 ","suffix":"  25 “Dis, Blaise, sommes-nous b"}]}]}
>```
>%%
>*%%PREFIX%%gonfle La Sibérie qui tourne 20%%HIGHLIGHT%% ==Les lourdes nappes de neige qui remontent Et le grelot de la folie qui grelotte comme un dernier désir dans l’air bleui Le train palpite au cœur des horizons plombés Et ton chagrin ricane...== %%POSTFIX%%25 “Dis, Blaise, sommes-nous b*
>%%LINK%%[[#^75zhyr59sfd|show annotation]]
>%%COMMENT%%
>juxtapositions d'éléments sans explications ce qui accentue la frénétique du voyage
>%%TAGS%%
>
^75zhyr59sfd


>%%
>```annotation-json
>{"created":"2022-06-26T12:13:33.185Z","text":"idée de fuite accentuant la frénésie du voyage","updated":"2022-06-26T12:13:33.185Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21281,"end":21291},{"type":"TextQuoteSelector","exact":"S’enfuient","prefix":" ciel, les locomotives en furie ","suffix":" 35  Blaise Cendrars, La Prose d"}]}]}
>```
>%%
>*%%PREFIX%%ciel, les locomotives en furie%%HIGHLIGHT%% ==S’enfuient== %%POSTFIX%%35  Blaise Cendrars, La Prose d*
>%%LINK%%[[#^wvlyy5prukj|show annotation]]
>%%COMMENT%%
>idée de fuite accentuant la frénésie du voyage
>%%TAGS%%
>
^wvlyy5prukj


>%%
>```annotation-json
>{"created":"2022-06-26T12:14:18.717Z","text":"comparaison à un accordéon qui fait assourdir les voyageurs","updated":"2022-06-26T12:14:18.717Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21178,"end":21196},{"type":"TextQuoteSelector","exact":"comme un accordéon","prefix":" s’étire s’allonge et se retire ","suffix":" qu’une main sadique tourmente D"}]}]}
>```
>%%
>*%%PREFIX%%s’étire s’allonge et se retire%%HIGHLIGHT%% ==comme un accordéon== %%POSTFIX%%qu’une main sadique tourmente D*
>%%LINK%%[[#^goqlkc1xgh5|show annotation]]
>%%COMMENT%%
>comparaison à un accordéon qui fait assourdir les voyageurs
>%%TAGS%%
>
^goqlkc1xgh5


>%%
>```annotation-json
>{"created":"2022-06-26T12:15:55.605Z","text":"métonymie et personnification montrant le bruit du train","updated":"2022-06-26T12:15:55.605Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21255,"end":21280},{"type":"TextQuoteSelector","exact":" les locomotives en furie","prefix":"nte Dans les déchirures du ciel,","suffix":" S’enfuient 35  Blaise Cendrars,"}]}]}
>```
>%%
>*%%PREFIX%%nte Dans les déchirures du ciel,%%HIGHLIGHT%% ==les locomotives en furie== %%POSTFIX%%S’enfuient 35  Blaise Cendrars,*
>%%LINK%%[[#^ebbxuv7f3d|show annotation]]
>%%COMMENT%%
>métonymie et personnification montrant le bruit du train
>%%TAGS%%
>
^ebbxuv7f3d


>%%
>```annotation-json
>{"created":"2022-06-26T12:16:34.337Z","text":"Il y a aussi l'idée de l'orage, d'une perturbation climatique violente qui accentue cette folie du train","updated":"2022-06-26T12:16:34.337Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21227,"end":21254},{"type":"TextQuoteSelector","exact":"Dans les déchirures du ciel","prefix":"n qu’une main sadique tourmente ","suffix":", les locomotives en furie S’enf"}]}]}
>```
>%%
>*%%PREFIX%%n qu’une main sadique tourmente%%HIGHLIGHT%% ==Dans les déchirures du ciel== %%POSTFIX%%, les locomotives en furie S’enf*
>%%LINK%%[[#^bddkroapkd4|show annotation]]
>%%COMMENT%%
>Il y a aussi l'idée de l'orage, d'une perturbation climatique violente qui accentue cette folie du train
>%%TAGS%%
>
^bddkroapkd4


>%%
>```annotation-json
>{"created":"2022-06-26T12:18:24.310Z","text":"le train entraine une déformation inquiétante du paysage","updated":"2022-06-26T12:18:24.310Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21138,"end":21177},{"type":"TextQuoteSelector","exact":"Le monde s’étire s’allonge et se retire","prefix":"i gesticulent et les étranglent ","suffix":" comme un accordéon qu’une main "}]}]}
>```
>%%
>*%%PREFIX%%i gesticulent et les étranglent%%HIGHLIGHT%% ==Le monde s’étire s’allonge et se retire== %%POSTFIX%%comme un accordéon qu’une main*
>%%LINK%%[[#^2gkddu57l1y|show annotation]]
>%%COMMENT%%
>le train entraine une déformation inquiétante du paysage
>%%TAGS%%
>
^2gkddu57l1y


>%%
>```annotation-json
>{"created":"2022-06-26T12:19:10.354Z","text":"lexique péjoratif pour dire que les gares sont en ruines","updated":"2022-06-26T12:19:10.354Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20978,"end":21026},{"type":"TextQuoteSelector","exact":"Toutes les gares lézardées obliques sur la route","prefix":"uiétudes Oublie les inquiétudes ","suffix":" 30  12 Les fils télégraphiques "}]}]}
>```
>%%
>*%%PREFIX%%uiétudes Oublie les inquiétudes%%HIGHLIGHT%% ==Toutes les gares lézardées obliques sur la route== %%POSTFIX%%30  12 Les fils télégraphiques*
>%%LINK%%[[#^2efkpu29qu9|show annotation]]
>%%COMMENT%%
>lexique péjoratif pour dire que les gares sont en ruines
>%%TAGS%%
>
^2efkpu29qu9


>%%
>```annotation-json
>{"created":"2022-06-26T12:19:55.458Z","text":"allégorie avec l'idée de destruction qui va donc vers l'idée de la mort","updated":"2022-06-26T12:19:55.458Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21058,"end":21080},{"type":"TextQuoteSelector","exact":"auxquels elles pendent","prefix":" 30  12 Les fils télégraphiques ","suffix":" Les poteaux grimaçants qui gest"}]}]}
>```
>%%
>*%%PREFIX%%30  12 Les fils télégraphiques%%HIGHLIGHT%% ==auxquels elles pendent== %%POSTFIX%%Les poteaux grimaçants qui gest*
>%%LINK%%[[#^pq6504k0cvk|show annotation]]
>%%COMMENT%%
>allégorie avec l'idée de destruction qui va donc vers l'idée de la mort
>%%TAGS%%
>
^pq6504k0cvk


>%%
>```annotation-json
>{"created":"2022-06-26T12:22:33.492Z","text":"allégorie avec lexique funèbre ce qui rend le décor inquiétant ","updated":"2022-06-26T12:22:33.492Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21104,"end":21137},{"type":"TextQuoteSelector","exact":"qui gesticulent et les étranglent","prefix":" pendent Les poteaux grimaçants ","suffix":" Le monde s’étire s’allonge et s"}]}]}
>```
>%%
>*%%PREFIX%%pendent Les poteaux grimaçants%%HIGHLIGHT%% ==qui gesticulent et les étranglent== %%POSTFIX%%Le monde s’étire s’allonge et s*
>%%LINK%%[[#^azhqryp3hu|show annotation]]
>%%COMMENT%%
>allégorie avec lexique funèbre ce qui rend le décor inquiétant 
>%%TAGS%%
>
^azhqryp3hu


>%%
>```annotation-json
>{"created":"2022-06-26T12:25:10.657Z","text":"une force mystérieuse derrière ça qui montre une idée de souffrance et qui se démarque de la main de Dieu de la vision chrétienne","updated":"2022-06-26T12:25:10.657Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":21200,"end":21226},{"type":"TextQuoteSelector","exact":"une main sadique tourmente","prefix":"se retire comme un accordéon qu’","suffix":" Dans les déchirures du ciel, le"}]}]}
>```
>%%
>*%%PREFIX%%se retire comme un accordéon qu’%%HIGHLIGHT%% ==une main sadique tourmente== %%POSTFIX%%Dans les déchirures du ciel, le*
>%%LINK%%[[#^dnzv8ugqx9p|show annotation]]
>%%COMMENT%%
>une force mystérieuse derrière ça qui montre une idée de souffrance et qui se démarque de la main de Dieu de la vision chrétienne
>%%TAGS%%
>
^dnzv8ugqx9p


>%%
>```annotation-json
>{"created":"2022-06-26T12:46:07.190Z","text":"référence aux vers d'après car partage de quelque chose qui change par rapport à la vision chrétienne","updated":"2022-06-26T12:46:07.190Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20939,"end":20978},{"type":"TextQuoteSelector","exact":"Les inquiétudes Oublie les inquiétudes ","prefix":"ous bien loin de Montmartre ?”  ","suffix":"Toutes les gares lézardées obliq"}]}]}
>```
>%%
>*%%PREFIX%%ous bien loin de Montmartre ?”%%HIGHLIGHT%% ==Les inquiétudes Oublie les inquiétudes== %%POSTFIX%%Toutes les gares lézardées obliq*
>%%LINK%%[[#^a8ukpe6ce9i|show annotation]]
>%%COMMENT%%
>référence aux vers d'après car partage de quelque chose qui change par rapport à la vision chrétienne
>%%TAGS%%
>
^a8ukpe6ce9i


>%%
>```annotation-json
>{"created":"2022-06-26T12:48:47.993Z","text":"voyage qui permet de fuir les problèmes\n- peut-être une référence à une guerre russe contre Japonais en 1905 et le poète a été obligé de fuir","updated":"2022-06-26T12:48:47.993Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20955,"end":20977},{"type":"TextQuoteSelector","exact":"Oublie les inquiétudes","prefix":" Montmartre ?”  Les inquiétudes ","suffix":" Toutes les gares lézardées obli"}]}]}
>```
>%%
>*%%PREFIX%%Montmartre ?”  Les inquiétudes%%HIGHLIGHT%% ==Oublie les inquiétudes== %%POSTFIX%%Toutes les gares lézardées obli*
>%%LINK%%[[#^025anyeu170b|show annotation]]
>%%COMMENT%%
>voyage qui permet de fuir les problèmes
>- peut-être une référence à une guerre russe contre Japonais en 1905 et le poète a été obligé de fuir
>%%TAGS%%
>
^025anyeu170b


>%%
>```annotation-json
>{"created":"2022-06-26T12:51:26.507Z","text":"lieux où Cendrars a du fuir à cause d'une guerre en 1905 où Russes et Japonais s'affrontaient","updated":"2022-06-26T12:51:26.507Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":20665,"end":20675},{"type":"TextQuoteSelector","exact":"La Sibérie","prefix":"i tombe La tourbe qui se gonfle ","suffix":" qui tourne 20 Les lourdes nappe"}]}]}
>```
>%%
>*%%PREFIX%%i tombe La tourbe qui se gonfle%%HIGHLIGHT%% ==La Sibérie== %%POSTFIX%%qui tourne 20 Les lourdes nappe*
>%%LINK%%[[#^8lparonco24|show annotation]]
>%%COMMENT%%
>lieux où Cendrars a du fuir à cause d'une guerre en 1905 où Russes et Japonais s'affrontaient
>%%TAGS%%
>
^8lparonco24


>%%
>```annotation-json
>{"created":"2022-06-26T13:51:57.647Z","text":"champs lexical du temps et un des thèmes du poème","updated":"2022-06-26T13:51:57.647Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":19095,"end":19107},{"type":"TextQuoteSelector","exact":"un seul jour","prefix":" l'océan des âges Jeter l'ancre ","suffix":" ?  5 Ô lac ! l'année à peine a "}]}]}
>```
>%%
>*%%PREFIX%%l'océan des âges Jeter l'ancre%%HIGHLIGHT%% ==un seul jour== %%POSTFIX%%?  5 Ô lac ! l'année à peine a*
>%%LINK%%[[#^exqd2rbvo3g|show annotation]]
>%%COMMENT%%
>champs lexical du temps et un des thèmes du poème
>%%TAGS%%
>
^exqd2rbvo3g


>%%
>```annotation-json
>{"created":"2022-06-26T13:53:41.589Z","text":"champs lexical du temps et un des thèmes du poème","updated":"2022-06-26T13:53:41.589Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18999,"end":19003},{"type":"TextQuoteSelector","exact":"nuit","prefix":"rs de nouveaux rivages, Dans la ","suffix":" éternelle emportés sans retour,"}]}]}
>```
>%%
>*%%PREFIX%%rs de nouveaux rivages, Dans la%%HIGHLIGHT%% ==nuit== %%POSTFIX%%éternelle emportés sans retour,*
>%%LINK%%[[#^9k9ivje97vv|show annotation]]
>%%COMMENT%%
>champs lexical du temps et un des thèmes du poème
>%%TAGS%%
>
^9k9ivje97vv


>%%
>```annotation-json
>{"created":"2022-06-26T13:54:34.124Z","text":"métaphore du temps en eau ","updated":"2022-06-26T13:54:34.124Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18948,"end":18989},{"type":"TextQuoteSelector","exact":"toujours poussés vers de nouveaux rivages","prefix":"ITÉ POÉTIQUE ?   Le Lac. Ainsi, ","suffix":", Dans la nuit éternelle emporté"}]}]}
>```
>%%
>*%%PREFIX%%ITÉ POÉTIQUE ?   Le Lac. Ainsi,%%HIGHLIGHT%% ==toujours poussés vers de nouveaux rivages== %%POSTFIX%%, Dans la nuit éternelle emporté*
>%%LINK%%[[#^um6hvi4x3a|show annotation]]
>%%COMMENT%%
>métaphore du temps en eau 
>%%TAGS%%
>
^um6hvi4x3a


>%%
>```annotation-json
>{"created":"2022-06-26T15:05:01.057Z","text":"métaphore du temps en eau","updated":"2022-06-26T15:05:01.057Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":19806,"end":19848},{"type":"TextQuoteSelector","exact":"suspends ton vol, et vous, heures propices","prefix":"mber ces mots :  25 « Ô temps ! ","suffix":" !  10 Suspendez votre cours : L"}]}]}
>```
>%%
>*%%PREFIX%%mber ces mots :  25 « Ô temps !%%HIGHLIGHT%% ==suspends ton vol, et vous, heures propices== %%POSTFIX%%!  10 Suspendez votre cours : L*
>%%LINK%%[[#^ow4ket9wlsc|show annotation]]
>%%COMMENT%%
>métaphore du temps en eau
>%%TAGS%%
>
^ow4ket9wlsc


>%%
>```annotation-json
>{"created":"2022-06-26T15:06:46.619Z","text":"L'auteure s'adresse directement au temps avec apostrophes","updated":"2022-06-26T15:06:46.619Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":19795,"end":19849},{"type":"TextQuoteSelector","exact":" Ô temps ! suspends ton vol, et vous, heures propices ","prefix":"e Laissa tomber ces mots :  25 «","suffix":"!  10 Suspendez votre cours : La"}]}]}
>```
>%%
>*%%PREFIX%%e Laissa tomber ces mots :  25 «%%HIGHLIGHT%% ==Ô temps ! suspends ton vol, et vous, heures propices== %%POSTFIX%%!  10 Suspendez votre cours : La*
>%%LINK%%[[#^3jnxl4jkl94|show annotation]]
>%%COMMENT%%
>L'auteure s'adresse directement au temps avec apostrophes
>%%TAGS%%
>
^3jnxl4jkl94


>%%
>```annotation-json
>{"created":"2022-06-26T15:40:44.019Z","text":"métaphore filée du temps","updated":"2022-06-26T15:40:44.019Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":19063,"end":19080},{"type":"TextQuoteSelector","exact":" l'océan des âges","prefix":"our, Ne pourrons-nous jamais sur","suffix":" Jeter l'ancre un seul jour ?  5"}]}]}
>```
>%%
>*%%PREFIX%%our, Ne pourrons-nous jamais sur%%HIGHLIGHT%% ==l'océan des âges== %%POSTFIX%%Jeter l'ancre un seul jour ?  5*
>%%LINK%%[[#^kodegrgpl|show annotation]]
>%%COMMENT%%
>métaphore filée du temps
>%%TAGS%%
>
^kodegrgpl


>%%
>```annotation-json
>{"created":"2022-06-26T15:44:25.522Z","text":"opposition entre passé et présent mais avec correlation","updated":"2022-06-26T15:44:25.522Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":19632,"end":19643},{"type":"TextQuoteSelector","exact":"Tout à coup","prefix":"dence Tes flots harmonieux.  20 ","suffix":" des accents inconnus à la terre"}]}]}
>```
>%%
>*%%PREFIX%%dence Tes flots harmonieux.  20%%HIGHLIGHT%% ==Tout à coup== %%POSTFIX%%des accents inconnus à la terre*
>%%LINK%%[[#^tfdj773ny2q|show annotation]]
>%%COMMENT%%
>opposition entre passé et présent mais avec correlation
>%%TAGS%%
>
^tfdj773ny2q


>%%
>```annotation-json
>{"created":"2022-06-26T15:52:29.564Z","text":"un lieu de nature","updated":"2022-06-26T15:52:29.564Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18933,"end":18939},{"type":"TextQuoteSelector","exact":"Le Lac","prefix":"cours :  MODERNITÉ POÉTIQUE ?   ","suffix":". Ainsi, toujours poussés vers d"}]}]}
>```
>%%
>*%%PREFIX%%cours :  MODERNITÉ POÉTIQUE ?%%HIGHLIGHT%% ==Le Lac== %%POSTFIX%%. Ainsi, toujours poussés vers d*
>%%LINK%%[[#^bm2uk7hen1p|show annotation]]
>%%COMMENT%%
>un lieu de nature
>%%TAGS%%
>
^bm2uk7hen1p


>%%
>```annotation-json
>{"created":"2022-06-26T15:53:08.956Z","text":"marque du bonheur de la nature","updated":"2022-06-26T15:53:08.956Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":19169,"end":19181},{"type":"TextQuoteSelector","exact":"flots chéris","prefix":"a fini sa carrière, Et près des ","suffix":" qu'elle devait revoir, Regarde "}]}]}
>```
>%%
>*%%PREFIX%%a fini sa carrière, Et près des%%HIGHLIGHT%% ==flots chéris== %%POSTFIX%%qu'elle devait revoir, Regarde*
>%%LINK%%[[#^j2r8oa5dod|show annotation]]
>%%COMMENT%%
>marque du bonheur de la nature
>%%TAGS%%
>
^j2r8oa5dod


>%%
>```annotation-json
>{"created":"2022-06-26T15:53:47.037Z","text":"métaphore du navigateur montre l'impuissance de l'homme face à la nature","updated":"2022-06-26T15:53:47.037Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":19474,"end":19498},{"type":"TextQuoteSelector","exact":"nous voguions en silence","prefix":" 15 Un soir, t'en souvient-il ? ","suffix":" ; On n'entendait au loin, sur l"}]}]}
>```
>%%
>*%%PREFIX%%15 Un soir, t'en souvient-il ?%%HIGHLIGHT%% ==nous voguions en silence== %%POSTFIX%%; On n'entendait au loin, sur l*
>%%LINK%%[[#^cvvb2tqiaxj|show annotation]]
>%%COMMENT%%
>métaphore du navigateur montre l'impuissance de l'homme face à la nature
>%%TAGS%%
>
^cvvb2tqiaxj


>%%
>```annotation-json
>{"created":"2022-06-26T15:54:30.527Z","text":"vocatif → invocation) tous les éléments de la nature pour qu’ils témoignent du passé, des sentiments du poète \n\n→ réseau lexical de la nature « ô lac »","updated":"2022-06-26T15:54:30.527Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":19113,"end":19114},{"type":"TextQuoteSelector","exact":"Ô","prefix":"Jeter l'ancre un seul jour ?  5 ","suffix":" lac ! l'année à peine a fini sa"}]}]}
>```
>%%
>*%%PREFIX%%Jeter l'ancre un seul jour ?  5%%HIGHLIGHT%% ==Ô== %%POSTFIX%%lac ! l'année à peine a fini sa*
>%%LINK%%[[#^l8u1s7a8g0h|show annotation]]
>%%COMMENT%%
>vocatif → invocation) tous les éléments de la nature pour qu’ils témoignent du passé, des sentiments du poète 
>
>→ réseau lexical de la nature « ô lac »
>%%TAGS%%
>
^l8u1s7a8g0h


>%%
>```annotation-json
>{"created":"2022-06-26T15:56:18.489Z","text":"Cela veut dire qu'ils ont aimé ce qui est la concentration de tout ce qui a été dit dans le poème. \nCe vers est la chute et l’apogée du poème : le poète constate le pouvoir des sentiments","updated":"2022-06-26T15:56:18.489Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":19879,"end":19900},{"type":"TextQuoteSelector","exact":"Laissez-nous savourer","prefix":"s !  10 Suspendez votre cours : ","suffix":" les rapides délices Des plus be"}]}]}
>```
>%%
>*%%PREFIX%%s !  10 Suspendez votre cours :%%HIGHLIGHT%% ==Laissez-nous savourer== %%POSTFIX%%les rapides délices Des plus be*
>%%LINK%%[[#^jw1ev1hf2v|show annotation]]
>%%COMMENT%%
>Cela veut dire qu'ils ont aimé ce qui est la concentration de tout ce qui a été dit dans le poème. 
>Ce vers est la chute et l’apogée du poème : le poète constate le pouvoir des sentiments
>%%TAGS%%
>
^jw1ev1hf2v


>%%
>```annotation-json
>{"created":"2022-06-26T15:57:42.264Z","text":"le poète montre qu'il y a un rapport entre le language et le paysage","updated":"2022-06-26T15:57:42.264Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":19644,"end":19675},{"type":"TextQuoteSelector","exact":"des accents inconnus à la terre","prefix":"ots harmonieux.  20 Tout à coup ","suffix":" Du rivage charmé frappèrent les"}]}]}
>```
>%%
>*%%PREFIX%%ots harmonieux.  20 Tout à coup%%HIGHLIGHT%% ==des accents inconnus à la terre== %%POSTFIX%%Du rivage charmé frappèrent les*
>%%LINK%%[[#^mmg6x2h64q9|show annotation]]
>%%COMMENT%%
>le poète montre qu'il y a un rapport entre le language et le paysage
>%%TAGS%%
>
^mmg6x2h64q9


>%%
>```annotation-json
>{"created":"2022-06-26T15:58:32.313Z","text":"personnification","updated":"2022-06-26T15:58:32.313Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":19383,"end":19392},{"type":"TextQuoteSelector","exact":" le vent ","prefix":"sur leurs flancs déchirés, Ainsi","suffix":"jetait l'écume de tes ondes Sur "}]}]}
>```
>%%
>*%%PREFIX%%sur leurs flancs déchirés, Ainsi%%HIGHLIGHT%% ==le vent== %%POSTFIX%%jetait l'écume de tes ondes Sur*
>%%LINK%%[[#^mni9a249mdo|show annotation]]
>%%COMMENT%%
>personnification
>%%TAGS%%
>
^mni9a249mdo


>%%
>```annotation-json
>{"text":"propose une représentation classique de l'automne, lyrique dans un poème irrégulier (vers)  -> \n   énergique\n   lecture libre\n\nAutomne personnifié\nL'auteur y voit une tragédie qui se fait à chaque strophe, les strophes font les actes jusqu'au dénouement.","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18214,"end":18228},{"type":"TextQuoteSelector","exact":"Automne malade","prefix":"ols de Guillaume Apollinaire.","suffix":"Automne malade et adoré Tu mou"}]}],"created":"2022-06-27T09:18:55.386Z","updated":"2022-06-27T09:18:55.386Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf"}
>```
>%%
>*%%PREFIX%%ols de Guillaume Apollinaire.%%HIGHLIGHT%% ==Automne malade== %%POSTFIX%%Automne malade et adoré Tu mou*
>%%LINK%%[[#^a60qthtmfp9|show annotation]]
>%%COMMENT%%
>propose une représentation classique de l'automne, lyrique dans un poème irrégulier (vers)  -> 
>   énergique
>   lecture libre
>
>Automne personnifié
>L'auteur y voit une tragédie qui se fait à chaque strophe, les strophes font les actes jusqu'au dénouement.
>%%TAGS%%
>
^a60qthtmfp9


>%%
>```annotation-json
>{"created":"2022-06-27T09:21:30.233Z","text":"paysage familier","updated":"2022-06-27T09:21:30.233Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18296,"end":18309},{"type":"TextQuoteSelector","exact":"les roseraies","prefix":" quand l’ouragan soufflera dans ","suffix":" Quand il aura neigé Dans les ve"}]}]}
>```
>%%
>*%%PREFIX%%quand l’ouragan soufflera dans%%HIGHLIGHT%% ==les roseraies== %%POSTFIX%%Quand il aura neigé Dans les ve*
>%%LINK%%[[#^y85de9xd0l|show annotation]]
>%%COMMENT%%
>paysage familier
>%%TAGS%%
>
^y85de9xd0l


>%%
>```annotation-json
>{"created":"2022-06-27T09:22:05.080Z","text":"paysage familier","updated":"2022-06-27T09:22:05.080Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18336,"end":18346},{"type":"TextQuoteSelector","exact":"es vergers","prefix":"raies Quand il aura neigé Dans l","suffix":" 5  Pauvre automne Meurs en blan"}]}]}
>```
>%%
>*%%PREFIX%%raies Quand il aura neigé Dans l%%HIGHLIGHT%% ==es vergers== %%POSTFIX%%5  Pauvre automne Meurs en blan*
>%%LINK%%[[#^msbfwky5wgk|show annotation]]
>%%COMMENT%%
>paysage familier
>%%TAGS%%
>
^msbfwky5wgk


>%%
>```annotation-json
>{"created":"2022-06-27T09:22:15.927Z","text":"paysage familier","updated":"2022-06-27T09:22:15.927Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18411,"end":18425},{"type":"TextQuoteSelector","exact":"de fruits mûrs","prefix":"heur et en richesse De neige et ","suffix":" Au fond du ciel 10 Des épervier"}]}]}
>```
>%%
>*%%PREFIX%%heur et en richesse De neige et%%HIGHLIGHT%% ==de fruits mûrs== %%POSTFIX%%Au fond du ciel 10 Des épervier*
>%%LINK%%[[#^my07owlew4b|show annotation]]
>%%COMMENT%%
>paysage familier
>%%TAGS%%
>
^my07owlew4b


>%%
>```annotation-json
>{"created":"2022-06-27T09:22:47.944Z","text":"paysage familier","updated":"2022-06-27T09:22:47.944Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18762,"end":18786},{"type":"TextQuoteSelector","exact":"Les feuilles Qu’on foule","prefix":"es en automne feuille à feuille ","suffix":" Un train Qui roule 25 La vie S’"}]}]}
>```
>%%
>*%%PREFIX%%es en automne feuille à feuille%%HIGHLIGHT%% ==Les feuilles Qu’on foule== %%POSTFIX%%Un train Qui roule 25 La vie S’*
>%%LINK%%[[#^lde8jgewjrq|show annotation]]
>%%COMMENT%%
>paysage familier
>%%TAGS%%
>
^lde8jgewjrq


>%%
>```annotation-json
>{"created":"2022-06-27T09:23:12.865Z","text":"animal lié à l'automne","updated":"2022-06-27T09:23:12.865Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18445,"end":18458},{"type":"TextQuoteSelector","exact":"Des éperviers","prefix":" fruits mûrs Au fond du ciel 10 ","suffix":" planent Sur les nixes nicettes "}]}]}
>```
>%%
>*%%PREFIX%%fruits mûrs Au fond du ciel 10%%HIGHLIGHT%% ==Des éperviers== %%POSTFIX%%planent Sur les nixes nicettes*
>%%LINK%%[[#^83hbh5bpost|show annotation]]
>%%COMMENT%%
>animal lié à l'automne
>%%TAGS%%
>
^83hbh5bpost


>%%
>```annotation-json
>{"created":"2022-06-27T09:23:39.189Z","text":"animal lié à l'automne","updated":"2022-06-27T09:23:39.189Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18568,"end":18577},{"type":"TextQuoteSelector","exact":"Les cerfs","prefix":"imé  Aux lisières lointaines 15 ","suffix":" ont bramé  Et que j’aime ô sais"}]}]}
>```
>%%
>*%%PREFIX%%imé  Aux lisières lointaines 15%%HIGHLIGHT%% ==Les cerfs== %%POSTFIX%%ont bramé  Et que j’aime ô sais*
>%%LINK%%[[#^3gth15m5zyj|show annotation]]
>%%COMMENT%%
>animal lié à l'automne
>%%TAGS%%
>
^3gth15m5zyj


>%%
>```annotation-json
>{"created":"2022-06-27T09:24:14.665Z","text":"assonance en \"è\"\nrésonne avec le bramement du cerf","updated":"2022-06-27T09:24:14.665Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18549,"end":18550},{"type":"TextQuoteSelector","exact":"è","prefix":" Qui n’ont jamais aimé  Aux lisi","suffix":"res lointaines 15 Les cerfs ont "}]}]}
>```
>%%
>*%%PREFIX%%Qui n’ont jamais aimé  Aux lisi%%HIGHLIGHT%% ==è== %%POSTFIX%%res lointaines 15 Les cerfs ont*
>%%LINK%%[[#^dkl1up1y4oj|show annotation]]
>%%COMMENT%%
>assonance en "è"
>résonne avec le bramement du cerf
>%%TAGS%%
>
^dkl1up1y4oj


>%%
>```annotation-json
>{"created":"2022-06-27T09:24:34.301Z","text":"assonance en \"è\"","updated":"2022-06-27T09:24:34.301Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18559,"end":18561},{"type":"TextQuoteSelector","exact":"ai","prefix":" jamais aimé  Aux lisières loint","suffix":"nes 15 Les cerfs ont bramé  Et q"}]}]}
>```
>%%
>*%%PREFIX%%jamais aimé  Aux lisières loint%%HIGHLIGHT%% ==ai== %%POSTFIX%%nes 15 Les cerfs ont bramé  Et q*
>%%LINK%%[[#^lys9zvp1zag|show annotation]]
>%%COMMENT%%
>assonance en "è"
>%%TAGS%%
>
^lys9zvp1zag


>%%
>```annotation-json
>{"created":"2022-06-27T09:27:48.914Z","text":" **[[allitération]]s** en « **r** », résonne avec le bramement du cerf","updated":"2022-06-27T09:27:48.914Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18574,"end":18575},{"type":"TextQuoteSelector","exact":"r","prefix":"ux lisières lointaines 15 Les ce","suffix":"fs ont bramé  Et que j’aime ô sa"}]}]}
>```
>%%
>*%%PREFIX%%ux lisières lointaines 15 Les ce%%HIGHLIGHT%% ==r== %%POSTFIX%%fs ont bramé  Et que j’aime ô sa*
>%%LINK%%[[#^pw967xwo0k|show annotation]]
>%%COMMENT%%
> **[[allitération]]s** en « **r** », résonne avec le bramement du cerf
>%%TAGS%%
>
^pw967xwo0k


>%%
>```annotation-json
>{"created":"2022-06-27T09:28:15.199Z","text":" **[[allitération]]s** en « **r** »","updated":"2022-06-27T09:28:15.199Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18583,"end":18584},{"type":"TextQuoteSelector","exact":"r","prefix":"es lointaines 15 Les cerfs ont b","suffix":"amé  Et que j’aime ô saison que "}]}]}
>```
>%%
>*%%PREFIX%%es lointaines 15 Les cerfs ont b%%HIGHLIGHT%% ==r== %%POSTFIX%%amé  Et que j’aime ô saison que*
>%%LINK%%[[#^zrh3xhqlql|show annotation]]
>%%COMMENT%%
> **[[allitération]]s** en « **r** »
>%%TAGS%%
>
^zrh3xhqlql


>%%
>```annotation-json
>{"created":"2022-06-27T09:29:44.078Z","text":"attente de l'hiver","updated":"2022-06-27T09:29:44.078Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18310,"end":18329},{"type":"TextQuoteSelector","exact":"Quand il aura neigé","prefix":"an soufflera dans les roseraies ","suffix":" Dans les vergers 5  Pauvre auto"}]}]}
>```
>%%
>*%%PREFIX%%an soufflera dans les roseraies%%HIGHLIGHT%% ==Quand il aura neigé== %%POSTFIX%%Dans les vergers 5  Pauvre auto*
>%%LINK%%[[#^1uf51iuk36e|show annotation]]
>%%COMMENT%%
>attente de l'hiver
>%%TAGS%%
>
^1uf51iuk36e


>%%
>```annotation-json
>{"created":"2022-06-27T09:30:18.726Z","text":"automne personnifié avec le fait qu'il se trouve avant l'hiver","updated":"2022-06-27T09:30:18.726Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18230,"end":18253},{"type":"TextQuoteSelector","exact":"Automne malade et adoré","prefix":" Apollinaire.   Automne malade  ","suffix":" Tu mourras quand l’ouragan souf"}]}]}
>```
>%%
>*%%PREFIX%%Apollinaire.   Automne malade%%HIGHLIGHT%% ==Automne malade et adoré== %%POSTFIX%%Tu mourras quand l’ouragan souf*
>%%LINK%%[[#^yp9qja6owur|show annotation]]
>%%COMMENT%%
>automne personnifié avec le fait qu'il se trouve avant l'hiver
>%%TAGS%%
>
^yp9qja6owur


>%%
>```annotation-json
>{"created":"2022-06-27T09:31:20.350Z","text":"automne de manière affective personnifié  et fait paraitre l'hiver comme l'inévitable","updated":"2022-06-27T09:31:20.350Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18350,"end":18364},{"type":"TextQuoteSelector","exact":"Pauvre automne","prefix":" aura neigé Dans les vergers 5  ","suffix":" Meurs en blancheur et en riches"}]}]}
>```
>%%
>*%%PREFIX%%aura neigé Dans les vergers 5%%HIGHLIGHT%% ==Pauvre automne== %%POSTFIX%%Meurs en blancheur et en riches*
>%%LINK%%[[#^qyd3tqxodt|show annotation]]
>%%COMMENT%%
>automne de manière affective personnifié  et fait paraitre l'hiver comme l'inévitable
>%%TAGS%%
>
^qyd3tqxodt


>%%
>```annotation-json
>{"created":"2022-06-27T09:33:13.080Z","text":"métonymie de l'automne personnifié","updated":"2022-06-27T09:33:13.080Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18677,"end":18709},{"type":"TextQuoteSelector","exact":"Le vent et la forêt qui pleurent","prefix":" tombant sans qu’on les cueille ","suffix":" 20 Toutes leurs larmes en autom"}]}]}
>```
>%%
>*%%PREFIX%%tombant sans qu’on les cueille%%HIGHLIGHT%% ==Le vent et la forêt qui pleurent== %%POSTFIX%%20 Toutes leurs larmes en autom*
>%%LINK%%[[#^u3n6p2fmkta|show annotation]]
>%%COMMENT%%
>métonymie de l'automne personnifié
>%%TAGS%%
>
^u3n6p2fmkta


>%%
>```annotation-json
>{"created":"2022-06-27T09:33:52.065Z","text":"Le sentiment de mélancolie est présent dans tout le texte : ce sentiment, attribué à la saison, est aussi celui ressenti par le poète. Il y a donc une correspondance entre l’âme du poète et la saison de l’automne, correspondance particulièrement mise en évidence avec la métaphore des larmes et des feuilles","updated":"2022-06-27T09:33:52.065Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18744,"end":18761},{"type":"TextQuoteSelector","exact":"feuille à feuille","prefix":" Toutes leurs larmes en automne ","suffix":" Les feuilles Qu’on foule Un tra"}]}]}
>```
>%%
>*%%PREFIX%%Toutes leurs larmes en automne%%HIGHLIGHT%% ==feuille à feuille== %%POSTFIX%%Les feuilles Qu’on foule Un tra*
>%%LINK%%[[#^q24lg9zifc|show annotation]]
>%%COMMENT%%
>Le sentiment de mélancolie est présent dans tout le texte : ce sentiment, attribué à la saison, est aussi celui ressenti par le poète. Il y a donc une correspondance entre l’âme du poète et la saison de l’automne, correspondance particulièrement mise en évidence avec la métaphore des larmes et des feuilles
>%%TAGS%%
>
^q24lg9zifc


>%%
>```annotation-json
>{"created":"2022-06-27T09:34:18.245Z","text":"là où la tristesse est la plus accentuait","updated":"2022-06-27T09:34:18.245Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18816,"end":18824},{"type":"TextQuoteSelector","exact":"S’écoule","prefix":"le Un train Qui roule 25 La vie ","suffix":"      Guillaume Apollinaire, Alc"}]}]}
>```
>%%
>*%%PREFIX%%le Un train Qui roule 25 La vie%%HIGHLIGHT%% ==S’écoule== %%POSTFIX%%Guillaume Apollinaire, Alc*
>%%LINK%%[[#^7sm0n46jz2m|show annotation]]
>%%COMMENT%%
>là où la tristesse est la plus accentuait
>%%TAGS%%
>
^7sm0n46jz2m


>%%
>```annotation-json
>{"created":"2022-06-27T09:36:35.304Z","text":"souligne que l'hiver est inévitable et donc une certaine mélancolie","updated":"2022-06-27T09:36:35.304Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18762,"end":18825},{"type":"TextQuoteSelector","exact":"Les feuilles Qu’on foule Un train Qui roule 25 La vie S’écoule ","prefix":"es en automne feuille à feuille ","suffix":"     Guillaume Apollinaire, Alco"}]}]}
>```
>%%
>*%%PREFIX%%es en automne feuille à feuille%%HIGHLIGHT%% ==Les feuilles Qu’on foule Un train Qui roule 25 La vie S’écoule== %%POSTFIX%%Guillaume Apollinaire, Alco*
>%%LINK%%[[#^50vt5hpg1us|show annotation]]
>%%COMMENT%%
>souligne que l'hiver est inévitable et donc une certaine mélancolie
>%%TAGS%%
>
^50vt5hpg1us


>%%
>```annotation-json
>{"created":"2022-06-27T09:38:42.977Z","text":"alexandrin","updated":"2022-06-27T09:38:42.977Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18589,"end":18634},{"type":"TextQuoteSelector","exact":"Et que j’aime ô saison que j’aime tes rumeurs","prefix":"ntaines 15 Les cerfs ont bramé  ","suffix":" Les fruits tombant sans qu’on l"}]}]}
>```
>%%
>*%%PREFIX%%ntaines 15 Les cerfs ont bramé%%HIGHLIGHT%% ==Et que j’aime ô saison que j’aime tes rumeurs== %%POSTFIX%%Les fruits tombant sans qu’on l*
>%%LINK%%[[#^6q9bcvjl1jj|show annotation]]
>%%COMMENT%%
>alexandrin
>%%TAGS%%
>
^6q9bcvjl1jj


>%%
>```annotation-json
>{"created":"2022-06-27T09:39:12.172Z","text":"alexandrin","updated":"2022-06-27T09:39:12.172Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18713,"end":18761},{"type":"TextQuoteSelector","exact":"Toutes leurs larmes en automne feuille à feuille","prefix":"ent et la forêt qui pleurent 20 ","suffix":" Les feuilles Qu’on foule Un tra"}]}]}
>```
>%%
>*%%PREFIX%%ent et la forêt qui pleurent 20%%HIGHLIGHT%% ==Toutes leurs larmes en automne feuille à feuille== %%POSTFIX%%Les feuilles Qu’on foule Un tra*
>%%LINK%%[[#^n6370h015ih|show annotation]]
>%%COMMENT%%
>alexandrin
>%%TAGS%%
>
^n6370h015ih


>%%
>```annotation-json
>{"created":"2022-06-27T09:39:22.290Z","text":"octosyllabe","updated":"2022-06-27T09:39:22.290Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18635,"end":18676},{"type":"TextQuoteSelector","exact":"Les fruits tombant sans qu’on les cueille","prefix":"ô saison que j’aime tes rumeurs ","suffix":" Le vent et la forêt qui pleuren"}]}]}
>```
>%%
>*%%PREFIX%%ô saison que j’aime tes rumeurs%%HIGHLIGHT%% ==Les fruits tombant sans qu’on les cueille== %%POSTFIX%%Le vent et la forêt qui pleuren*
>%%LINK%%[[#^k4m6x9no98|show annotation]]
>%%COMMENT%%
>octosyllabe
>%%TAGS%%
>
^k4m6x9no98


>%%
>```annotation-json
>{"created":"2022-06-27T09:39:41.505Z","text":"octosyllabe","updated":"2022-06-27T09:39:41.505Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18677,"end":18709},{"type":"TextQuoteSelector","exact":"Le vent et la forêt qui pleurent","prefix":" tombant sans qu’on les cueille ","suffix":" 20 Toutes leurs larmes en autom"}]}]}
>```
>%%
>*%%PREFIX%%tombant sans qu’on les cueille%%HIGHLIGHT%% ==Le vent et la forêt qui pleurent== %%POSTFIX%%20 Toutes leurs larmes en autom*
>%%LINK%%[[#^jop4t1h77i|show annotation]]
>%%COMMENT%%
>octosyllabe
>%%TAGS%%
>
^jop4t1h77i


>%%
>```annotation-json
>{"created":"2022-06-27T09:40:34.970Z","text":"alexandrin","updated":"2022-06-27T09:40:34.970Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18762,"end":18824},{"type":"TextQuoteSelector","exact":"Les feuilles Qu’on foule Un train Qui roule 25 La vie S’écoule","prefix":"es en automne feuille à feuille ","suffix":"      Guillaume Apollinaire, Alc"}]}]}
>```
>%%
>*%%PREFIX%%es en automne feuille à feuille%%HIGHLIGHT%% ==Les feuilles Qu’on foule Un train Qui roule 25 La vie S’écoule== %%POSTFIX%%Guillaume Apollinaire, Alc*
>%%LINK%%[[#^nldcpj325a|show annotation]]
>%%COMMENT%%
>alexandrin
>%%TAGS%%
>
^nldcpj325a


>%%
>```annotation-json
>{"created":"2022-06-27T09:42:13.041Z","text":"s'adresse à l'automne de façon intime","updated":"2022-06-27T09:42:13.041Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18254,"end":18256},{"type":"TextQuoteSelector","exact":"Tu","prefix":"malade  Automne malade et adoré ","suffix":" mourras quand l’ouragan souffle"}]}]}
>```
>%%
>*%%PREFIX%%malade  Automne malade et adoré%%HIGHLIGHT%% ==Tu== %%POSTFIX%%mourras quand l’ouragan souffle*
>%%LINK%%[[#^0dzh7mizyr8o|show annotation]]
>%%COMMENT%%
>s'adresse à l'automne de façon intime
>%%TAGS%%
>
^0dzh7mizyr8o



>%%
>```annotation-json
>{"created":"2022-06-27T09:44:51.413Z","text":"conjonction de coordination à valeur additive","updated":"2022-06-27T09:44:51.413Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18589,"end":18591},{"type":"TextQuoteSelector","exact":"Et","prefix":"ntaines 15 Les cerfs ont bramé  ","suffix":" que j’aime ô saison que j’aime "}]}]}
>```
>%%
>*%%PREFIX%%ntaines 15 Les cerfs ont bramé%%HIGHLIGHT%% ==Et== %%POSTFIX%%que j’aime ô saison que j’aime*
>%%LINK%%[[#^8nigwrg53kv|show annotation]]
>%%COMMENT%%
>conjonction de coordination à valeur additive
>%%TAGS%%
>
^8nigwrg53kv


>%%
>```annotation-json
>{"created":"2022-06-27T09:45:15.070Z","text":"l’interjection « ô » qui marque un sentiment exalté","updated":"2022-06-27T09:45:15.070Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18603,"end":18604},{"type":"TextQuoteSelector","exact":"ô","prefix":" cerfs ont bramé  Et que j’aime ","suffix":" saison que j’aime tes rumeurs L"}]}]}
>```
>%%
>*%%PREFIX%%cerfs ont bramé  Et que j’aime%%HIGHLIGHT%% ==ô== %%POSTFIX%%saison que j’aime tes rumeurs L*
>%%LINK%%[[#^93o67a6g484|show annotation]]
>%%COMMENT%%
>l’interjection « ô » qui marque un sentiment exalté
>%%TAGS%%
>
^93o67a6g484



>%%
>```annotation-json
>{"created":"2022-06-27T09:50:06.151Z","text":"futur inéluctable\nOn retrouve enfin le thème de la fuite du temps, thème traditionnel de la poésie lyrique.","updated":"2022-06-27T09:50:06.151Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18257,"end":18264},{"type":"TextQuoteSelector","exact":"mourras","prefix":"ade  Automne malade et adoré Tu ","suffix":" quand l’ouragan soufflera dans "}]}]}
>```
>%%
>*%%PREFIX%%ade  Automne malade et adoré Tu%%HIGHLIGHT%% ==mourras== %%POSTFIX%%quand l’ouragan soufflera dans*
>%%LINK%%[[#^95b198t2ak6|show annotation]]
>%%COMMENT%%
>futur inéluctable
>On retrouve enfin le thème de la fuite du temps, thème traditionnel de la poésie lyrique.
>%%TAGS%%
>
^95b198t2ak6


>%%
>```annotation-json
>{"created":"2022-06-27T09:51:22.811Z","text":"laissé par le futur\nthème de la fuite du temps","updated":"2022-06-27T09:51:22.811Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18365,"end":18370},{"type":"TextQuoteSelector","exact":"Meurs","prefix":"s les vergers 5  Pauvre automne ","suffix":" en blancheur et en richesse De "}]}]}
>```
>%%
>*%%PREFIX%%s les vergers 5  Pauvre automne%%HIGHLIGHT%% ==Meurs== %%POSTFIX%%en blancheur et en richesse De*
>%%LINK%%[[#^b3co21hn84o|show annotation]]
>%%COMMENT%%
>laissé par le futur
>thème de la fuite du temps
>%%TAGS%%
>
^b3co21hn84o


>%%
>```annotation-json
>{"created":"2022-06-27T09:53:19.673Z","text":"répétition lyrique de « que j’aime »","updated":"2022-06-27T09:53:19.673Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18535,"end":18539},{"type":"TextQuoteSelector","exact":"aimé","prefix":"erts et naines Qui n’ont jamais ","suffix":"  Aux lisières lointaines 15 Les"}]}]}
>```
>%%
>*%%PREFIX%%erts et naines Qui n’ont jamais%%HIGHLIGHT%% ==aimé== %%POSTFIX%%Aux lisières lointaines 15 Les*
>%%LINK%%[[#^mtuqvq6sk8|show annotation]]
>%%COMMENT%%
>répétition lyrique de « que j’aime »
>%%TAGS%%
>
^mtuqvq6sk8


>%%
>```annotation-json
>{"created":"2022-06-27T09:54:33.506Z","text":"passé laissé par le présent\nthème de la fuite du temps","updated":"2022-06-27T09:54:33.506Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18524,"end":18527},{"type":"TextQuoteSelector","exact":"ont","prefix":"x cheveux verts et naines Qui n’","suffix":" jamais aimé  Aux lisières loint"}]}]}
>```
>%%
>*%%PREFIX%%x cheveux verts et naines Qui n’%%HIGHLIGHT%% ==ont== %%POSTFIX%%jamais aimé  Aux lisières loint*
>%%LINK%%[[#^d4sf1nrsl07|show annotation]]
>%%COMMENT%%
>passé laissé par le présent
>thème de la fuite du temps
>%%TAGS%%
>
^d4sf1nrsl07


>%%
>```annotation-json
>{"created":"2022-06-27T10:45:11.957Z","text":"allitération en r qui montre le vent","updated":"2022-06-27T10:45:11.957Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18275,"end":18276},{"type":"TextQuoteSelector","exact":"r","prefix":"e et adoré Tu mourras quand l’ou","suffix":"agan soufflera dans les roseraie"}]}]}
>```
>%%
>*%%PREFIX%%e et adoré Tu mourras quand l’ou%%HIGHLIGHT%% ==r== %%POSTFIX%%agan soufflera dans les roseraie*
>%%LINK%%[[#^ysxihlz5i3|show annotation]]
>%%COMMENT%%
>allitération en r qui montre le vent
>%%TAGS%%
>
^ysxihlz5i3


>%%
>```annotation-json
>{"created":"2022-06-27T11:38:20.680Z","text":"porte en lui le feu","updated":"2022-06-27T11:38:20.680Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17338,"end":17366},{"type":"TextQuoteSelector","exact":"je transporte et que j'adore","prefix":"J'ai jeté dans le noble feu Que ","suffix":" De vives mains et même feu Ce P"}]}]}
>```
>%%
>*%%PREFIX%%J'ai jeté dans le noble feu Que%%HIGHLIGHT%% ==je transporte et que j'adore== %%POSTFIX%%De vives mains et même feu Ce P*
>%%LINK%%[[#^hx39zi62g7b|show annotation]]
>%%COMMENT%%
>porte en lui le feu
>%%TAGS%%
>
^hx39zi62g7b


>%%
>```annotation-json
>{"created":"2022-06-27T11:39:31.073Z","text":"fonction purificatrice, adoration mystique dans ce cas-là pour soi et pour la poésie","updated":"2022-06-27T11:39:31.073Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17324,"end":17329},{"type":"TextQuoteSelector","exact":"noble","prefix":"léon Roinard  J'ai jeté dans le ","suffix":" feu Que je transporte et que j'"}]}]}
>```
>%%
>*%%PREFIX%%léon Roinard  J'ai jeté dans le%%HIGHLIGHT%% ==noble== %%POSTFIX%%feu Que je transporte et que j'*
>%%LINK%%[[#^wbfqf6sps9q|show annotation]]
>%%COMMENT%%
>fonction purificatrice, adoration mystique dans ce cas-là pour soi et pour la poésie
>%%TAGS%%
>
^wbfqf6sps9q


>%%
>```annotation-json
>{"created":"2022-06-27T11:40:49.484Z","text":"ardeur \njeu de mots avec le sens de feu","updated":"2022-06-27T11:40:49.484Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17385,"end":17393},{"type":"TextQuoteSelector","exact":"même feu","prefix":"t que j'adore De vives mains et ","suffix":" Ce Passé ces têtes de morts 5 F"}]}]}
>```
>%%
>*%%PREFIX%%t que j'adore De vives mains et%%HIGHLIGHT%% ==même feu== %%POSTFIX%%Ce Passé ces têtes de morts 5 F*
>%%LINK%%[[#^5g5loluqtua|show annotation]]
>%%COMMENT%%
>ardeur 
>jeu de mots avec le sens de feu
>%%TAGS%%
>
^5g5loluqtua


>%%
>```annotation-json
>{"created":"2022-06-27T11:42:51.345Z","text":"le passé équivaut à la mort","updated":"2022-06-27T11:42:51.345Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17394,"end":17421},{"type":"TextQuoteSelector","exact":"Ce Passé ces têtes de morts","prefix":"dore De vives mains et même feu ","suffix":" 5 Flamme je fais ce que tu veux"}]}]}
>```
>%%
>*%%PREFIX%%dore De vives mains et même feu%%HIGHLIGHT%% ==Ce Passé ces têtes de morts== %%POSTFIX%%5 Flamme je fais ce que tu veux*
>%%LINK%%[[#^jt0w6bv8sfg|show annotation]]
>%%COMMENT%%
>le passé équivaut à la mort
>%%TAGS%%
>
^jt0w6bv8sfg


>%%
>```annotation-json
>{"created":"2022-06-27T11:44:20.133Z","text":"symbolisent le regret de l'amour chrétien\nmortes du passé","updated":"2022-06-27T11:44:20.133Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17617,"end":17626},{"type":"TextQuoteSelector","exact":"ces têtes","prefix":"and'plaintes végétales  Où sont ","suffix":" que j'avais Où est le Dieu de m"}]}]}
>```
>%%
>*%%PREFIX%%and'plaintes végétales  Où sont%%HIGHLIGHT%% ==ces têtes== %%POSTFIX%%que j'avais Où est le Dieu de m*
>%%LINK%%[[#^cpc1n9cz9rc|show annotation]]
>%%COMMENT%%
>symbolisent le regret de l'amour chrétien
>mortes du passé
>%%TAGS%%
>
^cpc1n9cz9rc


>%%
>```annotation-json
>{"created":"2022-06-27T11:44:51.380Z","text":"personnification de la flamme par la soumission du poète","updated":"2022-06-27T11:44:51.380Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17424,"end":17453},{"type":"TextQuoteSelector","exact":"Flamme je fais ce que tu veux","prefix":"u Ce Passé ces têtes de morts 5 ","suffix":"  Le galop soudain des étoiles N"}]}]}
>```
>%%
>*%%PREFIX%%u Ce Passé ces têtes de morts 5%%HIGHLIGHT%% ==Flamme je fais ce que tu veux== %%POSTFIX%%Le galop soudain des étoiles N*
>%%LINK%%[[#^wbk04lzda2|show annotation]]
>%%COMMENT%%
>personnification de la flamme par la soumission du poète
>%%TAGS%%
>
^wbk04lzda2


>%%
>```annotation-json
>{"created":"2022-06-27T11:47:40.808Z","text":"dimension cosmique","updated":"2022-06-27T11:47:40.808Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17472,"end":17483},{"type":"TextQuoteSelector","exact":"des étoiles","prefix":"e que tu veux  Le galop soudain ","suffix":" N'étant que ce qui deviendra Se"}]}]}
>```
>%%
>*%%PREFIX%%e que tu veux  Le galop soudain%%HIGHLIGHT%% ==des étoiles== %%POSTFIX%%N'étant que ce qui deviendra Se*
>%%LINK%%[[#^lsjf4o6c1l|show annotation]]
>%%COMMENT%%
>dimension cosmique
>%%TAGS%%
>
^lsjf4o6c1l


>%%
>```annotation-json
>{"created":"2022-06-27T11:48:36.233Z","text":"allitérations en a","updated":"2022-06-27T11:48:36.233Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17511,"end":17512},{"type":"TextQuoteSelector","exact":"a","prefix":"iles N'étant que ce qui deviendr","suffix":" Se mêle au hennissement mâle 10"}]}]}
>```
>%%
>*%%PREFIX%%iles N'étant que ce qui deviendr%%HIGHLIGHT%% ==a== %%POSTFIX%%Se mêle au hennissement mâle 10*
>%%LINK%%[[#^yg5cnmmmrkg|show annotation]]
>%%COMMENT%%
>allitérations en a
>%%TAGS%%
>
^yg5cnmmmrkg


>%%
>```annotation-json
>{"created":"2022-06-27T11:49:08.995Z","text":"exubérance de la vie, image violente","updated":"2022-06-27T11:49:08.995Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17455,"end":17483},{"type":"TextQuoteSelector","exact":"Le galop soudain des étoiles","prefix":" Flamme je fais ce que tu veux  ","suffix":" N'étant que ce qui deviendra Se"}]}]}
>```
>%%
>*%%PREFIX%%Flamme je fais ce que tu veux%%HIGHLIGHT%% ==Le galop soudain des étoiles== %%POSTFIX%%N'étant que ce qui deviendra Se*
>%%LINK%%[[#^bsc6n6ump4j|show annotation]]
>%%COMMENT%%
>exubérance de la vie, image violente
>%%TAGS%%
>
^bsc6n6ump4j


>%%
>```annotation-json
>{"created":"2022-06-27T11:51:05.379Z","text":"le poète invite à faire table rase du passé et ne pas se projeter dans l'avenir ; vivre le moment présent","updated":"2022-06-27T11:51:05.379Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17484,"end":17512},{"type":"TextQuoteSelector","exact":"N'étant que ce qui deviendra","prefix":"x  Le galop soudain des étoiles ","suffix":" Se mêle au hennissement mâle 10"}]}]}
>```
>%%
>*%%PREFIX%%x  Le galop soudain des étoiles%%HIGHLIGHT%% ==N'étant que ce qui deviendra== %%POSTFIX%%Se mêle au hennissement mâle 10*
>%%LINK%%[[#^ak9g3w1r59n|show annotation]]
>%%COMMENT%%
>le poète invite à faire table rase du passé et ne pas se projeter dans l'avenir ; vivre le moment présent
>%%TAGS%%
>
^ak9g3w1r59n


>%%
>```annotation-json
>{"created":"2022-06-27T11:55:00.888Z","text":"interrompt le thème du regret","updated":"2022-06-27T11:55:00.888Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17699,"end":17736},{"type":"TextQuoteSelector","exact":"Qu'au brasier les flammes renaissent ","prefix":"e 15 L'amour est devenu mauvais ","suffix":"Mon âme au soleil se dévêt  Dans"}]}]}
>```
>%%
>*%%PREFIX%%e 15 L'amour est devenu mauvais%%HIGHLIGHT%% ==Qu'au brasier les flammes renaissent== %%POSTFIX%%Mon âme au soleil se dévêt  Dans*
>%%LINK%%[[#^hh7tesv3fah|show annotation]]
>%%COMMENT%%
>interrompt le thème du regret
>%%TAGS%%
>
^hh7tesv3fah


>%%
>```annotation-json
>{"created":"2022-06-27T11:57:05.784Z","text":"garde la dimension cosmique","updated":"2022-06-27T11:57:05.784Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17744,"end":17753},{"type":"TextQuoteSelector","exact":"au soleil","prefix":" les flammes renaissent Mon âme ","suffix":" se dévêt  Dans la plaine ont po"}]}]}
>```
>%%
>*%%PREFIX%%les flammes renaissent Mon âme%%HIGHLIGHT%% ==au soleil== %%POSTFIX%%se dévêt  Dans la plaine ont po*
>%%LINK%%[[#^ky5waxu5unk|show annotation]]
>%%COMMENT%%
>garde la dimension cosmique
>%%TAGS%%
>
^ky5waxu5unk


>%%
>```annotation-json
>{"created":"2022-06-27T11:58:00.603Z","text":"démarquation par rapport au Dieu chrétien","updated":"2022-06-27T11:58:00.603Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17736,"end":17762},{"type":"TextQuoteSelector","exact":"Mon âme au soleil se dévêt","prefix":" brasier les flammes renaissent ","suffix":"  Dans la plaine ont poussé des "}]}]}
>```
>%%
>*%%PREFIX%%brasier les flammes renaissent%%HIGHLIGHT%% ==Mon âme au soleil se dévêt== %%POSTFIX%%Dans la plaine ont poussé des*
>%%LINK%%[[#^hu9h2we8hil|show annotation]]
>%%COMMENT%%
>démarquation par rapport au Dieu chrétien
>%%TAGS%%
>
^hu9h2we8hil


>%%
>```annotation-json
>{"created":"2022-06-27T11:59:06.682Z","text":"nouvelle image","updated":"2022-06-27T11:59:06.682Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17764,"end":17778},{"type":"TextQuoteSelector","exact":"Dans la plaine","prefix":"ent Mon âme au soleil se dévêt  ","suffix":" ont poussé des flammes 20 Nos c"}]}]}
>```
>%%
>*%%PREFIX%%ent Mon âme au soleil se dévêt%%HIGHLIGHT%% ==Dans la plaine== %%POSTFIX%%ont poussé des flammes 20 Nos c*
>%%LINK%%[[#^828h85ytong|show annotation]]
>%%COMMENT%%
>nouvelle image
>%%TAGS%%
>
^828h85ytong


>%%
>```annotation-json
>{"created":"2022-06-27T11:59:56.989Z","text":"métaphore en fruit, symbolisant la naissance et la beauté","updated":"2022-06-27T11:59:56.989Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17809,"end":17814},{"type":"TextQuoteSelector","exact":"cœurs","prefix":"e ont poussé des flammes 20 Nos ","suffix":" pendent aux citronniers Les têt"}]}]}
>```
>%%
>*%%PREFIX%%e ont poussé des flammes 20 Nos%%HIGHLIGHT%% ==cœurs== %%POSTFIX%%pendent aux citronniers Les têt*
>%%LINK%%[[#^mssxq9guox9|show annotation]]
>%%COMMENT%%
>métaphore en fruit, symbolisant la naissance et la beauté
>%%TAGS%%
>
^mssxq9guox9


>%%
>```annotation-json
>{"text":"rupture définitive avec le christianisme parce qu'il est face à ce qu'il a trouvé \nmorbide met mal à l'aise le lecteur","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17839,"end":17872},{"type":"TextQuoteSelector","exact":"Les têtes coupées qui m'acclament","prefix":"s cœurs pendent aux citronniers","suffix":"Et les astres qui ont saigné Ne"}]}],"created":"2022-06-27T12:00:56.638Z","updated":"2022-06-27T12:00:56.638Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf"}
>```
>%%
>*%%PREFIX%%s cœurs pendent aux citronniers%%HIGHLIGHT%% ==Les têtes coupées qui m'acclament== %%POSTFIX%%Et les astres qui ont saigné Ne*
>%%LINK%%[[#^zu4yme4f9sa|show annotation]]
>%%COMMENT%%
>rupture définitive avec le christianisme parce qu'il est face à ce qu'il a trouvé 
>morbide met mal à l'aise le lecteur
>%%TAGS%%
>
^zu4yme4f9sa


>%%
>```annotation-json
>{"created":"2022-06-27T19:34:56.949Z","text":"mélange de thème","updated":"2022-06-27T19:34:56.949Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17938,"end":17947},{"type":"TextQuoteSelector","exact":"Le fleuve","prefix":"ont que des têtes de femmes  25 ","suffix":" épinglé sur la ville T'y fixe c"}]}]}
>```
>%%
>*%%PREFIX%%ont que des têtes de femmes  25%%HIGHLIGHT%% ==Le fleuve== %%POSTFIX%%épinglé sur la ville T'y fixe c*
>%%LINK%%[[#^uusksvfds1l|show annotation]]
>%%COMMENT%%
>mélange de thème
>%%TAGS%%
>
^uusksvfds1l


>%%
>```annotation-json
>{"created":"2022-06-27T19:35:33.634Z","text":"tutoiement","updated":"2022-06-27T19:35:33.634Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17969,"end":17970},{"type":"TextQuoteSelector","exact":"T","prefix":" Le fleuve épinglé sur la ville ","suffix":"'y fixe comme un vêtement Partan"}]}]}
>```
>%%
>*%%PREFIX%%Le fleuve épinglé sur la ville%%HIGHLIGHT%% ==T== %%POSTFIX%%'y fixe comme un vêtement Partan*
>%%LINK%%[[#^x3biu5q2o6q|show annotation]]
>%%COMMENT%%
>tutoiement
>%%TAGS%%
>
^x3biu5q2o6q


>%%
>```annotation-json
>{"created":"2022-06-27T19:37:37.642Z","text":"sous entend des variations de lumière","updated":"2022-06-27T19:37:37.642Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18023,"end":18055},{"type":"TextQuoteSelector","exact":"Tu subis tous les tons charmants","prefix":"ment Partant à l'amphion docile ","suffix":" Qui rendent les pierres agiles "}]}]}
>```
>%%
>*%%PREFIX%%ment Partant à l'amphion docile%%HIGHLIGHT%% ==Tu subis tous les tons charmants== %%POSTFIX%%Qui rendent les pierres agiles*
>%%LINK%%[[#^nbquyjpgkyj|show annotation]]
>%%COMMENT%%
>sous entend des variations de lumière
>%%TAGS%%
>
^nbquyjpgkyj


>%%
>```annotation-json
>{"created":"2022-06-27T19:38:50.912Z","text":"éloge de la modernité","updated":"2022-06-27T19:38:50.912Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":17948,"end":17968},{"type":"TextQuoteSelector","exact":"épinglé sur la ville","prefix":"s têtes de femmes  25 Le fleuve ","suffix":" T'y fixe comme un vêtement Part"}]}]}
>```
>%%
>*%%PREFIX%%s têtes de femmes  25 Le fleuve%%HIGHLIGHT%% ==épinglé sur la ville== %%POSTFIX%%T'y fixe comme un vêtement Part*
>%%LINK%%[[#^7sessth5kvg|show annotation]]
>%%COMMENT%%
>éloge de la modernité
>%%TAGS%%
>
^7sessth5kvg


>%%
>```annotation-json
>{"created":"2022-06-27T19:40:34.003Z","text":"rochers qui perçoivent des sentiments","updated":"2022-06-27T19:40:34.003Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18056,"end":18086},{"type":"TextQuoteSelector","exact":"Qui rendent les pierres agiles","prefix":"u subis tous les tons charmants ","suffix":" 30       Guillaume Apollinaire,"}]}]}
>```
>%%
>*%%PREFIX%%u subis tous les tons charmants%%HIGHLIGHT%% ==Qui rendent les pierres agiles== %%POSTFIX%%30       Guillaume Apollinaire,*
>%%LINK%%[[#^6fz0b6ysgm5|show annotation]]
>%%COMMENT%%
>rochers qui perçoivent des sentiments
>%%TAGS%%
>
^6fz0b6ysgm5


>%%
>```annotation-json
>{"created":"2022-06-27T19:41:40.052Z","text":"musicien capable d'assembler des murs\nref. mythologie ","updated":"2022-06-27T19:41:40.052Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":18008,"end":18022},{"type":"TextQuoteSelector","exact":"amphion docile","prefix":"e comme un vêtement Partant à l'","suffix":" Tu subis tous les tons charmant"}]}]}
>```
>%%
>*%%PREFIX%%e comme un vêtement Partant à l'%%HIGHLIGHT%% ==amphion docile== %%POSTFIX%%Tu subis tous les tons charmant*
>%%LINK%%[[#^poy4mi4fs8|show annotation]]
>%%COMMENT%%
>musicien capable d'assembler des murs
>ref. mythologie 
>%%TAGS%%
>
^poy4mi4fs8



>%%
>```annotation-json
>{"created":"2022-06-28T08:11:49.452Z","text":"présentatif \"il y avait\"\n","updated":"2022-06-28T08:11:49.452Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":12272,"end":12282},{"type":"TextQuoteSelector","exact":"Il y avait","prefix":"e de Clèves, Madame de Lafayette","suffix":" longtemps que monsieur de Nemou"}]}]}
>```
>%%
>*%%PREFIX%%e de Clèves, Madame de Lafayette%%HIGHLIGHT%% ==Il y avait== %%POSTFIX%%longtemps que monsieur de Nemou*
>%%LINK%%[[#^s9dkbwi7eh|show annotation]]
>%%COMMENT%%
>présentatif "il y avait"
>
>%%TAGS%%
>
^s9dkbwi7eh


>%%
>```annotation-json
>{"created":"2022-06-28T08:12:45.433Z","text":"adverbe longtemps\nOn voit M. de Nemours qui a toujours l'envie, qui devient quasiment ancienne -> Auteur dit que la durée ne semble pas impacter grandement cet amoureux qui est obnibulé par l'objet de sa passion","updated":"2022-06-28T08:12:45.433Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":12283,"end":12292},{"type":"TextQuoteSelector","exact":"longtemps","prefix":", Madame de LafayetteIl y avait ","suffix":" que monsieur de Nemours souhait"}]}]}
>```
>%%
>*%%PREFIX%%, Madame de LafayetteIl y avait%%HIGHLIGHT%% ==longtemps== %%POSTFIX%%que monsieur de Nemours souhait*
>%%LINK%%[[#^e5yv6kobaoi|show annotation]]
>%%COMMENT%%
>adverbe longtemps
>On voit M. de Nemours qui a toujours l'envie, qui devient quasiment ancienne -> Auteur dit que la durée ne semble pas impacter grandement cet amoureux qui est obnibulé par l'objet de sa passion
>%%TAGS%%
>
^e5yv6kobaoi


>%%
>```annotation-json
>{"created":"2022-06-28T08:14:46.486Z","text":"On voit que le duc ne peut suptiliser le portrait pour des raisons sociales -> le duc est minutieux dans ces choix","updated":"2022-06-28T08:14:46.486Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":12369,"end":12623},{"type":"TextQuoteSelector","exact":"Lorsqu'il vit celui qui était à monsieur de Clèves, il ne put résister à l'envie de le dérober à un mari qu'il croyait tendrement aimé ; et il pensa que, parmi tant de personnes qui étaient dans ce même lieu, il ne serait pas soupçonné plutôt qu'un autre","prefix":"e portrait de madame de Clèves. ","suffix":".  Madame la dauphine était assi"}]}]}
>```
>%%
>*%%PREFIX%%e portrait de madame de Clèves.%%HIGHLIGHT%% ==Lorsqu'il vit celui qui était à monsieur de Clèves, il ne put résister à l'envie de le dérober à un mari qu'il croyait tendrement aimé ; et il pensa que, parmi tant de personnes qui étaient dans ce même lieu, il ne serait pas soupçonné plutôt qu'un autre== %%POSTFIX%%.  Madame la dauphine était assi*
>%%LINK%%[[#^3znaarrhzat|show annotation]]
>%%COMMENT%%
>On voit que le duc ne peut suptiliser le portrait pour des raisons sociales -> le duc est minutieux dans ces choix
>%%TAGS%%
>
^3znaarrhzat


>%%
>```annotation-json
>{"created":"2022-06-28T08:15:29.108Z","text":"La princesse de clèves surveille le duc, comprend ce qui va se passer, -> elle observe M. de Nemours","updated":"2022-06-28T08:15:29.108Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":12626,"end":12974},{"type":"TextQuoteSelector","exact":"Madame la dauphine était assise sur le lit, et parlait bas à madame de Clèves, qui était 5 debout devant elle. Madame de Clèves aperçut, par un des rideaux qui n'était qu'à demi fermé, monsieur de Nemours, le dos contre la table, qui était au pied du lit, et elle vit que, sans tourner la tête, il prenait adroitement quelque chose sur cette table.","prefix":" soupçonné plutôt qu'un autre.  ","suffix":" Elle n'eut pas de peine à devin"}]}]}
>```
>%%
>*%%PREFIX%%soupçonné plutôt qu'un autre.%%HIGHLIGHT%% ==Madame la dauphine était assise sur le lit, et parlait bas à madame de Clèves, qui était 5 debout devant elle. Madame de Clèves aperçut, par un des rideaux qui n'était qu'à demi fermé, monsieur de Nemours, le dos contre la table, qui était au pied du lit, et elle vit que, sans tourner la tête, il prenait adroitement quelque chose sur cette table.== %%POSTFIX%%Elle n'eut pas de peine à devin*
>%%LINK%%[[#^qgnyxrnmzoj|show annotation]]
>%%COMMENT%%
>La princesse de clèves surveille le duc, comprend ce qui va se passer, -> elle observe M. de Nemours
>%%TAGS%%
>
^qgnyxrnmzoj


>%%
>```annotation-json
>{"created":"2022-06-28T08:16:26.387Z","text":"M. de Nemours se comporte comme un voleur ; elle a compris que son geste est intentionnel","updated":"2022-06-28T08:16:26.387Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":12921,"end":12973},{"type":"TextQuoteSelector","exact":"il prenait adroitement quelque chose sur cette table","prefix":" vit que, sans tourner la tête, ","suffix":". Elle n'eut pas de peine à devi"}]}]}
>```
>%%
>*%%PREFIX%%vit que, sans tourner la tête,%%HIGHLIGHT%% ==il prenait adroitement quelque chose sur cette table== %%POSTFIX%%. Elle n'eut pas de peine à devi*
>%%LINK%%[[#^be6a4wbksqc|show annotation]]
>%%COMMENT%%
>M. de Nemours se comporte comme un voleur ; elle a compris que son geste est intentionnel
>%%TAGS%%
>
^be6a4wbksqc


>%%
>```annotation-json
>{"created":"2022-06-28T08:17:04.474Z","text":"description de l'action de la princesse\npendant toute la scène, elle observe le duc et ne fait pas attention aux propos de son hôtesse -> elle est fascinée","updated":"2022-06-28T08:17:04.474Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":12882,"end":12897},{"type":"TextQuoteSelector","exact":"et elle vit que","prefix":"able, qui était au pied du lit, ","suffix":", sans tourner la tête, il prena"}]}]}
>```
>%%
>*%%PREFIX%%able, qui était au pied du lit,%%HIGHLIGHT%% ==et elle vit que== %%POSTFIX%%, sans tourner la tête, il prena*
>%%LINK%%[[#^1yspvy75blt|show annotation]]
>%%COMMENT%%
>description de l'action de la princesse
>pendant toute la scène, elle observe le duc et ne fait pas attention aux propos de son hôtesse -> elle est fascinée
>%%TAGS%%
>
^1yspvy75blt


>%%
>```annotation-json
>{"created":"2022-06-28T08:19:05.084Z","text":"Le regard concentré sur le duc fait qu'il se sent attiré par elle\non entre dans de la réciprocité","updated":"2022-06-28T08:19:05.084Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":12975,"end":12998},{"type":"TextQuoteSelector","exact":"Elle n'eut pas de peine","prefix":" quelque chose sur cette table. ","suffix":" à deviner que c'était son portr"}]}]}
>```
>%%
>*%%PREFIX%%quelque chose sur cette table.%%HIGHLIGHT%% ==Elle n'eut pas de peine== %%POSTFIX%%à deviner que c'était son portr*
>%%LINK%%[[#^kf0hytmx92|show annotation]]
>%%COMMENT%%
>Le regard concentré sur le duc fait qu'il se sent attiré par elle
>on entre dans de la réciprocité
>%%TAGS%%
>
^kf0hytmx92


>%%
>```annotation-json
>{"created":"2022-06-28T08:20:31.459Z","text":"elle essaye de lui dire qu'elle ne veut pas de ses sentiments -> plus tard elle reprend conscience de ses propres sentiments pour lui","updated":"2022-06-28T08:20:31.459Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":13035,"end":13061},{"type":"TextQuoteSelector","exact":"et elle en fut si troublée","prefix":"viner que c'était son portrait, ","suffix":", que madame la Dauphine remarqu"}]}]}
>```
>%%
>*%%PREFIX%%viner que c'était son portrait,%%HIGHLIGHT%% ==et elle en fut si troublée== %%POSTFIX%%, que madame la Dauphine remarqu*
>%%LINK%%[[#^dpfs4x7sx64|show annotation]]
>%%COMMENT%%
>elle essaye de lui dire qu'elle ne veut pas de ses sentiments -> plus tard elle reprend conscience de ses propres sentiments pour lui
>%%TAGS%%
>
^dpfs4x7sx64


>%%
>```annotation-json
>{"created":"2022-06-28T08:20:55.621Z","text":"a dauphine le voit, met en éveil l'entourage (aussi le duc) -> ce qui était dissimulé apparait devant tout le monde à la manière du soleil quand il fait jour; secret dévoilé","updated":"2022-06-28T08:20:55.621Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":13067,"end":13166},{"type":"TextQuoteSelector","exact":"madame la Dauphine remarqua qu'elle ne l'écoutait pas, et lui demanda tout haut ce qu'elle regardai","prefix":"et elle en fut si troublée, que ","suffix":"t. Monsieur de Nemours se tourna"}]}]}
>```
>%%
>*%%PREFIX%%et elle en fut si troublée, que%%HIGHLIGHT%% ==madame la Dauphine remarqua qu'elle ne l'écoutait pas, et lui demanda tout haut ce qu'elle regardai== %%POSTFIX%%t. Monsieur de Nemours se tourna*
>%%LINK%%[[#^ws4worbbqed|show annotation]]
>%%COMMENT%%
>a dauphine le voit, met en éveil l'entourage (aussi le duc) -> ce qui était dissimulé apparait devant tout le monde à la manière du soleil quand il fait jour; secret dévoilé
>%%TAGS%%
>
^ws4worbbqed


>%%
>```annotation-json
>{"created":"2022-06-28T08:22:50.092Z","text":"\"raison\" qui en amour s'exprime par la préciosité\nDilemme :\nDénoncer le larcin en public serait plus éclairer l'amour du duc, et le dénoncer plus tard en privé serait lui permettre de se déclarer","updated":"2022-06-28T08:22:50.092Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":13381,"end":13425},{"type":"TextQuoteSelector","exact":"Madame de Clèves n'était pas peu embarrassée","prefix":"t vu ce qu'il venait de faire.  ","suffix":". La raison voulait qu'elle dema"}]}]}
>```
>%%
>*%%PREFIX%%t vu ce qu'il venait de faire.%%HIGHLIGHT%% ==Madame de Clèves n'était pas peu embarrassée== %%POSTFIX%%. La raison voulait qu'elle dema*
>%%LINK%%[[#^8fjihb2pk3c|show annotation]]
>%%COMMENT%%
>"raison" qui en amour s'exprime par la préciosité
>Dilemme :
>Dénoncer le larcin en public serait plus éclairer l'amour du duc, et le dénoncer plus tard en privé serait lui permettre de se déclarer
>%%TAGS%%
>
^8fjihb2pk3c


>%%
>```annotation-json
>{"created":"2022-06-28T08:24:34.870Z","text":"principe philosophique :\nDilemme n'est que concevable si l'on adopte la philosophie de l'honnête homme : vertus courtoises : héros courageux ; permettre au duc de se déclarer serait une triple faute : -> injure à son mari, outrage à la fidélité, un péché adultérin -> L' honnête homme sait se régler","updated":"2022-06-28T08:24:34.870Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":13700,"end":13749},{"type":"TextQuoteSelector","exact":"Enfin elle jugea qu'il valait mieux le lui laisse","prefix":"ger à lui parler de sa passion. ","suffix":"r, et elle fut bien aise de lui "}]}]}
>```
>%%
>*%%PREFIX%%ger à lui parler de sa passion.%%HIGHLIGHT%% ==Enfin elle jugea qu'il valait mieux le lui laisse== %%POSTFIX%%r, et elle fut bien aise de lui*
>%%LINK%%[[#^c4heiu0vp6e|show annotation]]
>%%COMMENT%%
>principe philosophique :
>Dilemme n'est que concevable si l'on adopte la philosophie de l'honnête homme : vertus courtoises : héros courageux ; permettre au duc de se déclarer serait une triple faute : -> injure à son mari, outrage à la fidélité, un péché adultérin -> L' honnête homme sait se régler
>%%TAGS%%
>
^c4heiu0vp6e


>%%
>```annotation-json
>{"created":"2022-06-28T08:26:02.228Z","text":"Analyse de la narratrice : Mme de Clèves ne regrette pas sa décision : \"bien aise\" -> touchée par la folie amoureuse","updated":"2022-06-28T08:26:02.228Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":13764,"end":13826},{"type":"TextQuoteSelector","exact":"bien aise de lui accorder une faveur qu'elle lui pouvait faire","prefix":"eux le lui laisser, et elle fut ","suffix":", sans qu'il sût même qu'elle la"}]}]}
>```
>%%
>*%%PREFIX%%eux le lui laisser, et elle fut%%HIGHLIGHT%% ==bien aise de lui accorder une faveur qu'elle lui pouvait faire== %%POSTFIX%%, sans qu'il sût même qu'elle la*
>%%LINK%%[[#^6wtwb46qvcv|show annotation]]
>%%COMMENT%%
>Analyse de la narratrice : Mme de Clèves ne regrette pas sa décision : "bien aise" -> touchée par la folie amoureuse
>%%TAGS%%
>
^6wtwb46qvcv


>%%
>```annotation-json
>{"created":"2022-06-28T08:26:38.000Z","text":"elle pense à tort que sa discrétion ne pourra pas être utilisée par le duc","updated":"2022-06-28T08:26:38.000Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":13828,"end":13871},{"type":"TextQuoteSelector","exact":"sans qu'il sût même qu'elle la lui faisait.","prefix":"veur qu'elle lui pouvait faire, ","suffix":" Monsieur de Nemours, qui remarq"}]}]}
>```
>%%
>*%%PREFIX%%veur qu'elle lui pouvait faire,%%HIGHLIGHT%% ==sans qu'il sût même qu'elle la lui faisait.== %%POSTFIX%%Monsieur de Nemours, qui remarq*
>%%LINK%%[[#^q8l3w2lx4i|show annotation]]
>%%COMMENT%%
>elle pense à tort que sa discrétion ne pourra pas être utilisée par le duc
>%%TAGS%%
>
^q8l3w2lx4i


>%%
>```annotation-json
>{"created":"2022-06-28T08:29:51.656Z","text":"on introduit le bal, et la princesse de Clèves se prépare ce qui indique l’importance de la soirée à venir","updated":"2022-06-28T08:29:51.656Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":9776,"end":9836},{"type":"TextQuoteSelector","exact":"Elle passa tout le jour des fiançailles chez elle à se parer","prefix":" de Clèves, Madame de Lafayette ","suffix":", pour se trouver le soir au bal"}]}]}
>```
>%%
>*%%PREFIX%%de Clèves, Madame de Lafayette%%HIGHLIGHT%% ==Elle passa tout le jour des fiançailles chez elle à se parer== %%POSTFIX%%, pour se trouver le soir au bal*
>%%LINK%%[[#^1dtnli5owuq|show annotation]]
>%%COMMENT%%
>on introduit le bal, et la princesse de Clèves se prépare ce qui indique l’importance de la soirée à venir
>%%TAGS%%
>
^1dtnli5owuq


>%%
>```annotation-json
>{"created":"2022-06-28T08:30:27.335Z","text":"l’évocation de l’évènement participe à créer une attente ; une soirée compléte et fabuleuse au Palais Royal","updated":"2022-06-28T08:30:27.335Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":9865,"end":9918},{"type":"TextQuoteSelector","exact":"bal et au festin  royal  qui  se  faisait  au  Louvre","prefix":"rer, pour se trouver le soir au ","suffix":".  Lorsqu’elle  arriva,  l’on  a"}]}]}
>```
>%%
>*%%PREFIX%%rer, pour se trouver le soir au%%HIGHLIGHT%% ==bal et au festin  royal  qui  se  faisait  au  Louvre== %%POSTFIX%%.  Lorsqu’elle  arriva,  l’on  a*
>%%LINK%%[[#^qjjtmnnm63r|show annotation]]
>%%COMMENT%%
>l’évocation de l’évènement participe à créer une attente ; une soirée compléte et fabuleuse au Palais Royal
>%%TAGS%%
>
^qjjtmnnm63r


>%%
>```annotation-json
>{"created":"2022-06-28T08:32:19.848Z","text":"rappelle la présentation à la cour de la princesse, avec une nouvelle fois un éloge de sa beauté","updated":"2022-06-28T08:32:19.848Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":9921,"end":9983},{"type":"TextQuoteSelector","exact":"Lorsqu’elle  arriva,  l’on  admira  sa  beauté  et  sa  parure","prefix":" qui  se  faisait  au  Louvre.  ","suffix":" ;  le  bal commença et, comme e"}]}]}
>```
>%%
>*%%PREFIX%%qui  se  faisait  au  Louvre.%%HIGHLIGHT%% ==Lorsqu’elle  arriva,  l’on  admira  sa  beauté  et  sa  parure== %%POSTFIX%%;  le  bal commença et, comme e*
>%%LINK%%[[#^krgycisxz3j|show annotation]]
>%%COMMENT%%
>rappelle la présentation à la cour de la princesse, avec une nouvelle fois un éloge de sa beauté
>%%TAGS%%
>
^krgycisxz3j


>%%
>```annotation-json
>{"created":"2022-06-28T08:32:43.952Z","text":"Nous sommes directement immergés dans l’action\tpassé simple","updated":"2022-06-28T08:32:43.952Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":9986,"end":10003},{"type":"TextQuoteSelector","exact":" le  bal commença","prefix":"a  sa  beauté  et  sa  parure ; ","suffix":" et, comme elle dansait avec M. "}]}]}
>```
>%%
>*%%PREFIX%%a  sa  beauté  et  sa  parure ;%%HIGHLIGHT%% ==le  bal commença== %%POSTFIX%%et, comme elle dansait avec M.*
>%%LINK%%[[#^et4yhxfhoak|show annotation]]
>%%COMMENT%%
>Nous sommes directement immergés dans l’action	passé simple
>%%TAGS%%
>
^et4yhxfhoak


>%%
>```annotation-json
>{"created":"2022-06-28T08:33:34.847Z","text":"pose une action de second plan, avec comme valeur de temps\timparfait","updated":"2022-06-28T08:33:34.847Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":10004,"end":10043},{"type":"TextQuoteSelector","exact":"et, comme elle dansait avec M. de Guise","prefix":" sa  parure ;  le  bal commença ","suffix":", il se fit un assez grand bruit"}]}]}
>```
>%%
>*%%PREFIX%%sa  parure ;  le  bal commença%%HIGHLIGHT%% ==et, comme elle dansait avec M. de Guise== %%POSTFIX%%, il se fit un assez grand bruit*
>%%LINK%%[[#^wsbaelia6x|show annotation]]
>%%COMMENT%%
>pose une action de second plan, avec comme valeur de temps	imparfait
>%%TAGS%%
>
^wsbaelia6x


>%%
>```annotation-json
>{"created":"2022-06-28T08:34:01.208Z","text":"En effet l’action de premier plan est évidemment le suspens organisé autour de l’apparition de M. de Nemours\tpassé simple","updated":"2022-06-28T08:34:01.208Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":10045,"end":10159},{"type":"TextQuoteSelector","exact":"il se fit un assez grand bruit vers la porte de la salle, comme de quelqu’un qui entrait et à qui on faisait place","prefix":" elle dansait avec M. de Guise, ","suffix":". Mme de Clèves acheva de danser"}]}]}
>```
>%%
>*%%PREFIX%%elle dansait avec M. de Guise,%%HIGHLIGHT%% ==il se fit un assez grand bruit vers la porte de la salle, comme de quelqu’un qui entrait et à qui on faisait place== %%POSTFIX%%. Mme de Clèves acheva de danser*
>%%LINK%%[[#^81gloiyfesp|show annotation]]
>%%COMMENT%%
>En effet l’action de premier plan est évidemment le suspens organisé autour de l’apparition de M. de Nemours	passé simple
>%%TAGS%%
>
^81gloiyfesp


>%%
>```annotation-json
>{"created":"2022-06-28T08:34:40.530Z","text":"l’élément perturbateur à la situation initiale, vient du roi","updated":"2022-06-28T08:34:40.530Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":10275,"end":10301},{"type":"TextQuoteSelector","exact":"le roi lui cria de prendre","prefix":"’elle avait dessein de prendre, ","suffix":" 5 celui qui arrivait. Elle se t"}]}]}
>```
>%%
>*%%PREFIX%%’elle avait dessein de prendre,%%HIGHLIGHT%% ==le roi lui cria de prendre== %%POSTFIX%%5 celui qui arrivait. Elle se t*
>%%LINK%%[[#^madk37v75ck|show annotation]]
>%%COMMENT%%
>l’élément perturbateur à la situation initiale, vient du roi
>%%TAGS%%
>
^madk37v75ck


>%%
>```annotation-json
>{"created":"2022-06-28T08:35:07.354Z","text":"la venue de M. de Nemours à travers son regard ; Elle le connaît à peine, elle doute -> Son identité est donc dévoilée, et son arrivée reste fracassante\tElle se tourna, et vit ; elle crut d’abord -> qui passait par-dessus quelques sièges pour arriver où l’on dansait","updated":"2022-06-28T08:35:07.354Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":10161,"end":10274},{"type":"TextQuoteSelector","exact":"Mme de Clèves acheva de danser et, pendant qu’elle cherchait des yeux quelqu’un qu’elle avait dessein de prendre,","prefix":"rait et à qui on faisait place. ","suffix":" le roi lui cria de prendre 5 ce"}]}]}
>```
>%%
>*%%PREFIX%%rait et à qui on faisait place.%%HIGHLIGHT%% ==Mme de Clèves acheva de danser et, pendant qu’elle cherchait des yeux quelqu’un qu’elle avait dessein de prendre,== %%POSTFIX%%le roi lui cria de prendre 5 ce*
>%%LINK%%[[#^chyrfrac4qr|show annotation]]
>%%COMMENT%%
>la venue de M. de Nemours à travers son regard ; Elle le connaît à peine, elle doute -> Son identité est donc dévoilée, et son arrivée reste fracassante	Elle se tourna, et vit ; elle crut d’abord -> qui passait par-dessus quelques sièges pour arriver où l’on dansait
>%%TAGS%%
>
^chyrfrac4qr


>%%
>```annotation-json
>{"created":"2022-06-28T08:35:55.446Z","text":"Suit une description laudative, un éloge rapide de M. de Nemours sur sa naissance -> allure de Nemour","updated":"2022-06-28T08:35:55.446Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":10480,"end":10719},{"type":"TextQuoteSelector","exact":"Ce prince était fait d’une sorte qu’il était difficile de n’être pas surprise de le voir quand on ne l’avait jamais vu, surtout ce soir-là, où le soin qu’il avait pris de se parer augmentait encore l’air brillant qui était dans sa personne","prefix":"s pour arriver où l’on dansait. ","suffix":" ; mais il était difficile aussi"}]}]}
>```
>%%
>*%%PREFIX%%s pour arriver où l’on dansait.%%HIGHLIGHT%% ==Ce prince était fait d’une sorte qu’il était difficile de n’être pas surprise de le voir quand on ne l’avait jamais vu, surtout ce soir-là, où le soin qu’il avait pris de se parer augmentait encore l’air brillant qui était dans sa personne== %%POSTFIX%%; mais il était difficile aussi*
>%%LINK%%[[#^etmt2zbbpk|show annotation]]
>%%COMMENT%%
>Suit une description laudative, un éloge rapide de M. de Nemours sur sa naissance -> allure de Nemour
>%%TAGS%%
>
^etmt2zbbpk


>%%
>```annotation-json
>{"created":"2022-06-28T08:36:18.923Z","text":"éloge hyperbolique de la beauté de la princesse, mais de complémentarité","updated":"2022-06-28T08:36:18.923Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":10795,"end":10826},{"type":"TextQuoteSelector","exact":" sans avoir un grand étonnement","prefix":" de Clèves pour la première fois","suffix":". 10 M. de Nemours fut tellement"}]}]}
>```
>%%
>*%%PREFIX%%de Clèves pour la première fois%%HIGHLIGHT%% ==sans avoir un grand étonnement== %%POSTFIX%%. 10 M. de Nemours fut tellement*
>%%LINK%%[[#^xvf6qqenpos|show annotation]]
>%%COMMENT%%
>éloge hyperbolique de la beauté de la princesse, mais de complémentarité
>%%TAGS%%
>
^xvf6qqenpos


>%%
>```annotation-json
>{"created":"2022-06-28T08:37:21.862Z","text":"Le point de vue change, nous sommes sur une focalisation interne de M. de Nemours, qui une nouvelle fois idéalise la beauté de madame de Clèves\tchangement de point de vue ; ton est encore fortement hyperbolique","updated":"2022-06-28T08:37:21.862Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":10831,"end":10879},{"type":"TextQuoteSelector","exact":"M. de Nemours fut tellement surpris de sa beauté","prefix":"s avoir un grand étonnement. 10 ","suffix":" que, lorsqu’il fut proche d’ell"}]}]}
>```
>%%
>*%%PREFIX%%s avoir un grand étonnement. 10%%HIGHLIGHT%% ==M. de Nemours fut tellement surpris de sa beauté== %%POSTFIX%%que, lorsqu’il fut proche d’ell*
>%%LINK%%[[#^34ffcl9jkhh|show annotation]]
>%%COMMENT%%
>Le point de vue change, nous sommes sur une focalisation interne de M. de Nemours, qui une nouvelle fois idéalise la beauté de madame de Clèves	changement de point de vue ; ton est encore fortement hyperbolique
>%%TAGS%%
>
^34ffcl9jkhh


>%%
>```annotation-json
>{"created":"2022-06-28T08:37:41.971Z","text":"Le début du paragraphe marque aussi le premier rapprochement physique entre les deux","updated":"2022-06-28T08:37:41.971Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":10885,"end":10905},{"type":"TextQuoteSelector","exact":"lorsqu’il fut proche","prefix":"ement surpris de sa beauté que, ","suffix":" d’elle, et qu’elle lui fit la r"}]}]}
>```
>%%
>*%%PREFIX%%ement surpris de sa beauté que,%%HIGHLIGHT%% ==lorsqu’il fut proche== %%POSTFIX%%d’elle, et qu’elle lui fit la r*
>%%LINK%%[[#^w78fkxmig4|show annotation]]
>%%COMMENT%%
>Le début du paragraphe marque aussi le premier rapprochement physique entre les deux
>%%TAGS%%
>
^w78fkxmig4


>%%
>```annotation-json
>{"created":"2022-06-28T08:38:11.465Z","text":"nous voyons la construction d’une scène théâtrale avec les deux acteurs et le public -> leur danse est un spectacle\t(passé simple ;) scène théâtrale","updated":"2022-06-28T08:38:11.465Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":11009,"end":11089},{"type":"TextQuoteSelector","exact":"Quand ils commencèrent à danser, il s’éleva dans la salle un murmure de louanges","prefix":" des marques de son admiration. ","suffix":". Le roi et les reines se souvin"}]}]}
>```
>%%
>*%%PREFIX%%des marques de son admiration.%%HIGHLIGHT%% ==Quand ils commencèrent à danser, il s’éleva dans la salle un murmure de louanges== %%POSTFIX%%. Le roi et les reines se souvin*
>%%LINK%%[[#^r0iaivp5j0c|show annotation]]
>%%COMMENT%%
>nous voyons la construction d’une scène théâtrale avec les deux acteurs et le public -> leur danse est un spectacle	(passé simple ;) scène théâtrale
>%%TAGS%%
>
^r0iaivp5j0c


>%%
>```annotation-json
>{"created":"2022-06-28T08:38:41.267Z","text":"rappelle que La Princesse de Clèves est aussi un roman historique, un témoignage sur la cour non d’Henri II, mais de Louis XIV","updated":"2022-06-28T08:38:41.267Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":11091,"end":11159},{"type":"TextQuoteSelector","exact":"Le roi et les reines se souvinrent qu’ils ne s’étaient  jamais  vus,","prefix":"a salle un murmure de louanges. ","suffix":"  et  trouvèrent  quelque  chose"}]}]}
>```
>%%
>*%%PREFIX%%a salle un murmure de louanges.%%HIGHLIGHT%% ==Le roi et les reines se souvinrent qu’ils ne s’étaient  jamais  vus,== %%POSTFIX%%et  trouvèrent  quelque  chose*
>%%LINK%%[[#^g3f1bgv066w|show annotation]]
>%%COMMENT%%
>rappelle que La Princesse de Clèves est aussi un roman historique, un témoignage sur la cour non d’Henri II, mais de Louis XIV
>%%TAGS%%
>
^g3f1bgv066w



>%%
>```annotation-json
>{"created":"2022-06-28T08:39:45.589Z","text":"L’alchimie semble opérer dès leur premier contact","updated":"2022-06-28T08:39:45.589Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":11161,"end":11259},{"type":"TextQuoteSelector","exact":"et  trouvèrent  quelque  chose  de  singulier  de  les  voir  danser  ensemble  sans  se connaître","prefix":"ils ne s’étaient  jamais  vus,  ","suffix":". Ils les appelèrent quand ils e"}]}]}
>```
>%%
>*%%PREFIX%%ils ne s’étaient  jamais  vus,%%HIGHLIGHT%% ==et  trouvèrent  quelque  chose  de  singulier  de  les  voir  danser  ensemble  sans  se connaître== %%POSTFIX%%. Ils les appelèrent quand ils e*
>%%LINK%%[[#^5hmtawt3arg|show annotation]]
>%%COMMENT%%
>L’alchimie semble opérer dès leur premier contact
>%%TAGS%%
>
^5hmtawt3arg


>%%
>```annotation-json
>{"created":"2022-06-28T08:40:00.942Z","text":"La position supérieure du couple royale est rappelée dans la dernière phrase -> sont entremetteurs\tdiscours indirect","updated":"2022-06-28T08:40:00.942Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":11261,"end":11349},{"type":"TextQuoteSelector","exact":"Ils les appelèrent quand ils eurent fini sans leur donner le loisir de parler à personne","prefix":"  ensemble  sans  se connaître. ","suffix":" et leur 15 demandèrent s’ils n’"}]}]}
>```
>%%
>*%%PREFIX%%ensemble  sans  se connaître.%%HIGHLIGHT%% ==Ils les appelèrent quand ils eurent fini sans leur donner le loisir de parler à personne== %%POSTFIX%%et leur 15 demandèrent s’ils n’*
>%%LINK%%[[#^xr52fya494|show annotation]]
>%%COMMENT%%
>La position supérieure du couple royale est rappelée dans la dernière phrase -> sont entremetteurs	discours indirect
>%%TAGS%%
>
^xr52fya494


>%%
>```annotation-json
>{"created":"2022-06-28T08:41:55.838Z","text":"M.de Nemours se comporte en gentilhomme, en galant homme ; flatte madame de Clèves tout en jouant l’humilité\tdiscours direct + lilote","updated":"2022-06-28T08:41:55.838Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":11504,"end":11647},{"type":"TextQuoteSelector","exact":"je n’ai pas d’incertitude ; mais comme Mme de Clèves n’a pas les mêmes raisons pour deviner qui je suis que celles que j’ai pour la reconnaître","prefix":"moi, Madame, dit M. de Nemours, ","suffix":", je voudrais bien que Votre Maj"}]}]}
>```
>%%
>*%%PREFIX%%moi, Madame, dit M. de Nemours,%%HIGHLIGHT%% ==je n’ai pas d’incertitude ; mais comme Mme de Clèves n’a pas les mêmes raisons pour deviner qui je suis que celles que j’ai pour la reconnaître== %%POSTFIX%%, je voudrais bien que Votre Maj*
>%%LINK%%[[#^1fvbchvdxhw|show annotation]]
>%%COMMENT%%
>M.de Nemours se comporte en gentilhomme, en galant homme ; flatte madame de Clèves tout en jouant l’humilité	discours direct + lilote
>%%TAGS%%
>
^1fvbchvdxhw


>%%
>```annotation-json
>{"created":"2022-06-28T08:44:24.935Z","text":"n’oublie pas non plus de manière très adroite de remettre la famille royale au centre de la discussion -> réalisme\tdiscours direct","updated":"2022-06-28T08:44:24.935Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":11649,"end":11721},{"type":"TextQuoteSelector","exact":"je voudrais bien que Votre Majesté eût la bonté de lui apprendre mon nom","prefix":"s que j’ai pour la reconnaître, ","suffix":". – Je crois, dit Mme la dauphin"}]}]}
>```
>%%
>*%%PREFIX%%s que j’ai pour la reconnaître,%%HIGHLIGHT%% ==je voudrais bien que Votre Majesté eût la bonté de lui apprendre mon nom== %%POSTFIX%%. – Je crois, dit Mme la dauphin*
>%%LINK%%[[#^ybbbvgnr89|show annotation]]
>%%COMMENT%%
>n’oublie pas non plus de manière très adroite de remettre la famille royale au centre de la discussion -> réalisme	discours direct
>%%TAGS%%
>
^ybbbvgnr89


>%%
>```annotation-json
>{"created":"2022-06-28T08:54:15.680Z","text":"répond de manière amusée. On comprend dans sa réplique qu’elle n’est pas dupe de la fausse modestie de M. de Nemours.","updated":"2022-06-28T08:54:15.680Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":11725,"end":11806},{"type":"TextQuoteSelector","exact":"Je crois, dit Mme la dauphine, qu’elle le sait aussi bien que vous savez le sien.","prefix":"nté de lui apprendre mon nom. – ","suffix":" 20 – Je vous assure, Madame, re"}]}]}
>```
>%%
>*%%PREFIX%%nté de lui apprendre mon nom. –%%HIGHLIGHT%% ==Je crois, dit Mme la dauphine, qu’elle le sait aussi bien que vous savez le sien.== %%POSTFIX%%20 – Je vous assure, Madame, re*
>%%LINK%%[[#^my5vui8xbh|show annotation]]
>%%COMMENT%%
>répond de manière amusée. On comprend dans sa réplique qu’elle n’est pas dupe de la fausse modestie de M. de Nemours.
>%%TAGS%%
>
^my5vui8xbh


>%%
>```annotation-json
>{"created":"2022-06-28T08:54:43.033Z","text":"L’innocence et la gêne de la princesse de Clèves tranchent avec l’habitude des autres participants\tsorte de didascalie","updated":"2022-06-28T08:54:43.033Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":11858,"end":11891},{"type":"TextQuoteSelector","exact":"qui paraissait un peu embarrassée","prefix":", Madame, reprit Mme de Clèves, ","suffix":", que je ne devine pas si bien q"}]}]}
>```
>%%
>*%%PREFIX%%, Madame, reprit Mme de Clèves,%%HIGHLIGHT%% ==qui paraissait un peu embarrassée== %%POSTFIX%%, que je ne devine pas si bien q*
>%%LINK%%[[#^ce6rzugpigu|show annotation]]
>%%COMMENT%%
>L’innocence et la gêne de la princesse de Clèves tranchent avec l’habitude des autres participants	sorte de didascalie
>%%TAGS%%
>
^ce6rzugpigu


>%%
>```annotation-json
>{"created":"2022-06-28T08:55:06.117Z","text":"en partie impressionnée par la compagnie prestigieuse et veut à tout prix éviter de commettre une erreur -> rappelle de ce que lui avait dit ça mère","updated":"2022-06-28T08:55:06.117Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":11900,"end":11937},{"type":"TextQuoteSelector","exact":"ne devine pas si bien que vous pensez","prefix":"sait un peu embarrassée, que je ","suffix":". – Vous devinez fort bien, répo"}]}]}
>```
>%%
>*%%PREFIX%%sait un peu embarrassée, que je%%HIGHLIGHT%% ==ne devine pas si bien que vous pensez== %%POSTFIX%%. – Vous devinez fort bien, répo*
>%%LINK%%[[#^wn1np050k9|show annotation]]
>%%COMMENT%%
>en partie impressionnée par la compagnie prestigieuse et veut à tout prix éviter de commettre une erreur -> rappelle de ce que lui avait dit ça mère
>%%TAGS%%
>
^wn1np050k9


>%%
>```annotation-json
>{"created":"2022-06-28T08:55:36.304Z","text":"Mais la dauphine une nouvelle fois ne se laisse pas tromper ; compliment à M.de Nemours","updated":"2022-06-28T08:55:36.304Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":11941,"end":12032},{"type":"TextQuoteSelector","exact":"Vous devinez fort bien, répondit Mme la dauphine ; et il y a même quelque chose d’obligeant","prefix":" pas si bien que vous pensez. – ","suffix":" pour M. de Nemours à ne vouloir"}]}]}
>```
>%%
>*%%PREFIX%%pas si bien que vous pensez. –%%HIGHLIGHT%% ==Vous devinez fort bien, répondit Mme la dauphine ; et il y a même quelque chose d’obligeant== %%POSTFIX%%pour M. de Nemours à ne vouloir*
>%%LINK%%[[#^gxllxqn0yq4|show annotation]]
>%%COMMENT%%
>Mais la dauphine une nouvelle fois ne se laisse pas tromper ; compliment à M.de Nemours
>%%TAGS%%
>
^gxllxqn0yq4


>%%
>```annotation-json
>{"created":"2022-06-28T08:56:28.257Z","text":"Nous comprenons aussi que le caractère obligeant mis en avant tient au fait que M. de Nemours n’a pas entièrement bonne réputation…\tparadoxe assez saisissant","updated":"2022-06-28T08:56:28.257Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":12052,"end":12122},{"type":"TextQuoteSelector","exact":"à ne vouloir pas avouer que vous le connaissez sans l’avoir jamais vu.","prefix":" d’obligeant pour M. de Nemours ","suffix":" Madame de Lafayette, La Princes"}]}]}
>```
>%%
>*%%PREFIX%%d’obligeant pour M. de Nemours%%HIGHLIGHT%% ==à ne vouloir pas avouer que vous le connaissez sans l’avoir jamais vu.== %%POSTFIX%%Madame de Lafayette, La Princes*
>%%LINK%%[[#^mv7k0lpyek|show annotation]]
>%%COMMENT%%
>Nous comprenons aussi que le caractère obligeant mis en avant tient au fait que M. de Nemours n’a pas entièrement bonne réputation…	paradoxe assez saisissant
>%%TAGS%%
>
^mv7k0lpyek


>%%
>```annotation-json
>{"created":"2022-06-28T08:56:50.671Z","text":"Cette scène illustre la galanterie et la préciosité de l’époque.\nrappelle de ce que lui avait dit ça mère","updated":"2022-06-28T08:56:50.671Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":9696,"end":9708},{"type":"TextQuoteSelector","exact":"Extrait n° 1","prefix":"persanes (1721), lettre CLXI. 3 ","suffix":" de l’œuvre intégrale : La Princ"}]}]}
>```
>%%
>*%%PREFIX%%persanes (1721), lettre CLXI. 3%%HIGHLIGHT%% ==Extrait n° 1== %%POSTFIX%%de l’œuvre intégrale : La Princ*
>%%LINK%%[[#^dwgmd1f9qnp|show annotation]]
>%%COMMENT%%
>Cette scène illustre la galanterie et la préciosité de l’époque.
>rappelle de ce que lui avait dit ça mère
>%%TAGS%%
>
^dwgmd1f9qnp


>%%
>```annotation-json
>{"created":"2022-06-28T08:58:41.516Z","text":"adverbe ; rythme quaternaire avec verbes au passé composé ; champ lexical de la supercherie\taveu tromperie ; héroïne provocatrice et manipulatrice","updated":"2022-06-28T08:58:41.516Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":7752,"end":7909},{"type":"TextQuoteSelector","exact":"Oui, je t’ai trompé ; j’ai séduit tes eunuques ; je me suis jouée de ta jalousie ; et j’ai su, de ton affreux sérail, faire un lieu de délices et de plaisirs","prefix":" CLXI. ROXANE À USBEK. À Paris. ","suffix":".  Je  vais  mourir  ;  le  pois"}]}]}
>```
>%%
>*%%PREFIX%%CLXI. ROXANE À USBEK. À Paris.%%HIGHLIGHT%% ==Oui, je t’ai trompé ; j’ai séduit tes eunuques ; je me suis jouée de ta jalousie ; et j’ai su, de ton affreux sérail, faire un lieu de délices et de plaisirs== %%POSTFIX%%.  Je  vais  mourir  ;  le  pois*
>%%LINK%%[[#^yfkstzedxa|show annotation]]
>%%COMMENT%%
>adverbe ; rythme quaternaire avec verbes au passé composé ; champ lexical de la supercherie	aveu tromperie ; héroïne provocatrice et manipulatrice
>%%TAGS%%
>
^yfkstzedxa


>%%
>```annotation-json
>{"created":"2022-06-28T08:58:58.511Z","text":"pronom personnel\taffirme supériorité","updated":"2022-06-28T08:58:58.511Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":7757,"end":7759},{"type":"TextQuoteSelector","exact":"je","prefix":". ROXANE À USBEK. À Paris. Oui, ","suffix":" t’ai trompé ; j’ai séduit tes e"}]}]}
>```
>%%
>*%%PREFIX%%. ROXANE À USBEK. À Paris. Oui,%%HIGHLIGHT%% ==je== %%POSTFIX%%t’ai trompé ; j’ai séduit tes e*
>%%LINK%%[[#^4rxfvpxzxix|show annotation]]
>%%COMMENT%%
>pronom personnel	affirme supériorité
>%%TAGS%%
>
^4rxfvpxzxix


>%%
>```annotation-json
>{"created":"2022-06-28T08:59:33.504Z","text":"antiphrase\tingéniosité héroïne qui est parvenue à transformer le harem du tyran en un lieu plus conforme à ses désirs","updated":"2022-06-28T08:59:33.504Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":7854,"end":7909},{"type":"TextQuoteSelector","exact":"affreux sérail, faire un lieu de délices et de plaisirs","prefix":"a jalousie ; et j’ai su, de ton ","suffix":".  Je  vais  mourir  ;  le  pois"}]}]}
>```
>%%
>*%%PREFIX%%a jalousie ; et j’ai su, de ton%%HIGHLIGHT%% ==affreux sérail, faire un lieu de délices et de plaisirs== %%POSTFIX%%.  Je  vais  mourir  ;  le  pois*
>%%LINK%%[[#^dr6gkk3wj5k|show annotation]]
>%%COMMENT%%
>antiphrase	ingéniosité héroïne qui est parvenue à transformer le harem du tyran en un lieu plus conforme à ses désirs
>%%TAGS%%
>
^dr6gkk3wj5k


>%%
>```annotation-json
>{"created":"2022-06-28T09:00:14.816Z","text":"présent valeur de futur proche\tsort scellé -> elle défie Usbek, et choisit sa punition","updated":"2022-06-28T09:00:14.816Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":7912,"end":7974},{"type":"TextQuoteSelector","exact":"Je  vais  mourir  ;  le  poison  va  couler  dans  mes  veines","prefix":"ieu de délices et de plaisirs.  ","suffix":"  :  car  que  ferais-je  ici, p"}]}]}
>```
>%%
>*%%PREFIX%%ieu de délices et de plaisirs.%%HIGHLIGHT%% ==Je  vais  mourir  ;  le  poison  va  couler  dans  mes  veines== %%POSTFIX%%:  car  que  ferais-je  ici, p*
>%%LINK%%[[#^7mocn2igd46|show annotation]]
>%%COMMENT%%
>présent valeur de futur proche	sort scellé -> elle défie Usbek, et choisit sa punition
>%%TAGS%%
>
^7mocn2igd46


>%%
>```annotation-json
>{"created":"2022-06-28T09:01:09.020Z","text":"allitération en v ; périphrase\tappuie la détermination -> la rupture avec Usbek devient totale, et explique son suicide par la mort de son amant","updated":"2022-06-28T09:01:09.020Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":7979,"end":8218},{"type":"TextQuoteSelector","exact":"car  que  ferais-je  ici, puisque le seul homme qui me retenait à la vie n’est plus ? Je meurs ; mais mon ombre s’envole bien accompagnée : je viens d’envoyer devant moi ces gardiens sacrilèges, 5 qui ont répandu le plus beau sang du monde","prefix":"  couler  dans  mes  veines  :  ","suffix":".  Comment  as-tu  pensé  que  j"}]}]}
>```
>%%
>*%%PREFIX%%couler  dans  mes  veines  :%%HIGHLIGHT%% ==car  que  ferais-je  ici, puisque le seul homme qui me retenait à la vie n’est plus ? Je meurs ; mais mon ombre s’envole bien accompagnée : je viens d’envoyer devant moi ces gardiens sacrilèges, 5 qui ont répandu le plus beau sang du monde== %%POSTFIX%%.  Comment  as-tu  pensé  que  j*
>%%LINK%%[[#^l0ymvf9j0up|show annotation]]
>%%COMMENT%%
>allitération en v ; périphrase	appuie la détermination -> la rupture avec Usbek devient totale, et explique son suicide par la mort de son amant
>%%TAGS%%
>
^l0ymvf9j0up


>%%
>```annotation-json
>{"created":"2022-06-28T09:02:00.729Z","text":"métaphorique\tpoétique, et révèle qu'elle a vengé son amant en tuant ses meurtriers","updated":"2022-06-28T09:02:00.729Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":8081,"end":8099},{"type":"TextQuoteSelector","exact":"mon ombre s’envole","prefix":"ie n’est plus ? Je meurs ; mais ","suffix":" bien accompagnée : je viens d’e"}]}]}
>```
>%%
>*%%PREFIX%%ie n’est plus ? Je meurs ; mais%%HIGHLIGHT%% ==mon ombre s’envole== %%POSTFIX%%bien accompagnée : je viens d’e*
>%%LINK%%[[#^ah7ex9v4euk|show annotation]]
>%%COMMENT%%
>métaphorique	poétique, et révèle qu'elle a vengé son amant en tuant ses meurtriers
>%%TAGS%%
>
^ah7ex9v4euk


>%%
>```annotation-json
>{"created":"2022-06-28T09:02:56.145Z","text":"adj\tUsbek tout puissant, contre nature -> deux mouvements s'opposent","updated":"2022-06-28T09:02:56.145Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":8266,"end":8274},{"type":"TextQuoteSelector","exact":" crédule","prefix":"u  pensé  que  je  fusse  assez ","suffix":"  pour  m’imaginer  que  je  ne "}]}]}
>```
>%%
>*%%PREFIX%%u  pensé  que  je  fusse  assez%%HIGHLIGHT%% ==crédule== %%POSTFIX%%pour  m’imaginer  que  je  ne*
>%%LINK%%[[#^ow2175b7okf|show annotation]]
>%%COMMENT%%
>adj	Usbek tout puissant, contre nature -> deux mouvements s'opposent
>%%TAGS%%
>
^ow2175b7okf


>%%
>```annotation-json
>{"created":"2022-06-28T09:03:37.302Z","text":"verbe d'action\tportrait femme rusée -> su modifier les règles du sérail en déjouant la surveillance des géoliers","updated":"2022-06-28T09:03:37.302Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":8448,"end":8524},{"type":"TextQuoteSelector","exact":"j’ai pu vivre dans la servitude, mais j’ai toujours été libre : j’ai réformé","prefix":"ffliger tous mes désirs ? Non : ","suffix":" tes lois sur celles de la natur"}]}]}
>```
>%%
>*%%PREFIX%%ffliger tous mes désirs ? Non :%%HIGHLIGHT%% ==j’ai pu vivre dans la servitude, mais j’ai toujours été libre : j’ai réformé== %%POSTFIX%%tes lois sur celles de la natur*
>%%LINK%%[[#^gy93qwctd7v|show annotation]]
>%%COMMENT%%
>verbe d'action	portrait femme rusée -> su modifier les règles du sérail en déjouant la surveillance des géoliers
>%%TAGS%%
>
^gy93qwctd7v


>%%
>```annotation-json
>{"created":"2022-06-28T09:04:32.946Z","text":"répétition du verbe paraitre\tRoxane montre que sa fidélité était feinte","updated":"2022-06-28T09:04:32.946Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":8727,"end":8735},{"type":"TextQuoteSelector","exact":"paraître","prefix":" je me suis abaissée jusqu’à te ","suffix":" fidèle ; de ce que j’ai lâcheme"}]}]}
>```
>%%
>*%%PREFIX%%je me suis abaissée jusqu’à te%%HIGHLIGHT%% ==paraître== %%POSTFIX%%fidèle ; de ce que j’ai lâcheme*
>%%LINK%%[[#^w0hj91a9wv|show annotation]]
>%%COMMENT%%
>répétition du verbe paraitre	Roxane montre que sa fidélité était feinte
>%%TAGS%%
>
^w0hj91a9wv


>%%
>```annotation-json
>{"created":"2022-06-28T09:06:02.417Z","text":"regret de ne pas s'être révolté plus tôt, profane la vertue et la force de l'âme -> on voit qu'Usbek ne sait pas chercher la sagesse car elle est chez ça femme","updated":"2022-06-28T09:06:02.417Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":8657,"end":8666},{"type":"TextQuoteSelector","exact":"sacrifice","prefix":"rais me rendre grâces encore du ","suffix":" que je t’ai fait ; de ce que je"}]}]}
>```
>%%
>*%%PREFIX%%rais me rendre grâces encore du%%HIGHLIGHT%% ==sacrifice== %%POSTFIX%%que je t’ai fait ; de ce que je*
>%%LINK%%[[#^x5or6ixxqs|show annotation]]
>%%COMMENT%%
>regret de ne pas s'être révolté plus tôt, profane la vertue et la force de l'âme -> on voit qu'Usbek ne sait pas chercher la sagesse car elle est chez ça femme
>%%TAGS%%
>
^x5or6ixxqs


>%%
>```annotation-json
>{"created":"2022-06-28T09:06:37.880Z","text":"adverbe\tElle se sent méprisable -> mais il y a de la réussite car il se croyait tout-puissant","updated":"2022-06-28T09:06:37.880Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":8760,"end":8769},{"type":"TextQuoteSelector","exact":"lâchement","prefix":"araître fidèle ; de ce que j’ai ","suffix":" gardé dans mon cœur ce que j’au"}]}]}
>```
>%%
>*%%PREFIX%%araître fidèle ; de ce que j’ai%%HIGHLIGHT%% ==lâchement== %%POSTFIX%%gardé dans mon cœur ce que j’au*
>%%LINK%%[[#^p2smt9h1h|show annotation]]
>%%COMMENT%%
>adverbe	Elle se sent méprisable -> mais il y a de la réussite car il se croyait tout-puissant
>%%TAGS%%
>
^p2smt9h1h


>%%
>```annotation-json
>{"created":"2022-06-28T09:07:12.586Z","text":"modalité d'une négation totale\til a été aveuglé de posséder Roxane alors qu'elle n'a ressenti que du mépris, touche à la vie privé de Usbek","updated":"2022-06-28T09:07:12.586Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":8785,"end":8840},{"type":"TextQuoteSelector","exact":"cœur ce que j’aurais dû faire paraître à toute la terre","prefix":"e j’ai lâchement gardé dans mon ","suffix":" ; enfin de ce que j’ai profané "}]}]}
>```
>%%
>*%%PREFIX%%e j’ai lâchement gardé dans mon%%HIGHLIGHT%% ==cœur ce que j’aurais dû faire paraître à toute la terre== %%POSTFIX%%; enfin de ce que j’ai profané*
>%%LINK%%[[#^tl3aa36a66l|show annotation]]
>%%COMMENT%%
>modalité d'une négation totale	il a été aveuglé de posséder Roxane alors qu'elle n'a ressenti que du mépris, touche à la vie privé de Usbek
>%%TAGS%%
>
^tl3aa36a66l


>%%
>```annotation-json
>{"created":"2022-06-28T09:08:04.748Z","text":"verbe de soumission (forcer) ; substansif (courage)\trenverse les rôles ; elle rappelle que c'est la véritable héroïne","updated":"2022-06-28T09:08:04.748Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":9329,"end":9437},{"type":"TextQuoteSelector","exact":"Serait-il  possible  qu’après  t’avoir 20 accablé de douleurs, je te forçasse encore d’admirer mon courage ?","prefix":"  doute,  te  paraît  nouveau.  ","suffix":" Mais c’en est fait, le poison m"}]}]}
>```
>%%
>*%%PREFIX%%doute,  te  paraît  nouveau.%%HIGHLIGHT%% ==Serait-il  possible  qu’après  t’avoir 20 accablé de douleurs, je te forçasse encore d’admirer mon courage ?== %%POSTFIX%%Mais c’en est fait, le poison m*
>%%LINK%%[[#^dmpbtgi33g9|show annotation]]
>%%COMMENT%%
>verbe de soumission (forcer) ; substansif (courage)	renverse les rôles ; elle rappelle que c'est la véritable héroïne
>%%TAGS%%
>
^dmpbtgi33g9


>%%
>```annotation-json
>{"created":"2022-06-28T09:09:34.365Z","text":"propositions brèves séparées\tdifficultée à écrire mais elle prive Usbek de son pouvoir tyrannique -> silence elle meurt -> mort tragique, c'est un accomplissement","updated":"2022-06-28T09:09:34.365Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":9438,"end":9581},{"type":"TextQuoteSelector","exact":"Mais c’en est fait, le poison me consume, ma force m’abandonne ; la plume me tombe des mains ; je sens affaiblir jusqu’à ma haine ; je me meurs","prefix":" encore d’admirer mon courage ? ","suffix":". Du sérail d’Ispahan, le 8 de l"}]}]}
>```
>%%
>*%%PREFIX%%encore d’admirer mon courage ?%%HIGHLIGHT%% ==Mais c’en est fait, le poison me consume, ma force m’abandonne ; la plume me tombe des mains ; je sens affaiblir jusqu’à ma haine ; je me meurs== %%POSTFIX%%. Du sérail d’Ispahan, le 8 de l*
>%%LINK%%[[#^wec2qu4bv|show annotation]]
>%%COMMENT%%
>propositions brèves séparées	difficultée à écrire mais elle prive Usbek de son pouvoir tyrannique -> silence elle meurt -> mort tragique, c'est un accomplissement
>%%TAGS%%
>
^wec2qu4bv


>%%
>```annotation-json
>{"created":"2022-06-28T11:43:51.079Z","text":"discours direct ce qui donne de l'importance ","updated":"2022-06-28T11:43:51.079Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":14295,"end":14296},{"type":"TextQuoteSelector","exact":"—","prefix":"e de Clèves, Madame de Lafayette","suffix":"  J'avoue,  répondit-elle,  que "}]}]}
>```
>%%
>*%%PREFIX%%e de Clèves, Madame de Lafayette%%HIGHLIGHT%% ==—== %%POSTFIX%%J'avoue,  répondit-elle,  que*
>%%LINK%%[[#^5b174bk3lik|show annotation]]
>%%COMMENT%%
>discours direct ce qui donne de l'importance 
>%%TAGS%%
>
^5b174bk3lik


>%%
>```annotation-json
>{"created":"2022-06-28T11:44:30.544Z","text":"thématique de l'aveu personnel\nprésent d'actualité\n1° personne","updated":"2022-06-28T11:44:30.544Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":14298,"end":14305},{"type":"TextQuoteSelector","exact":"J'avoue","prefix":"e Clèves, Madame de Lafayette—  ","suffix":",  répondit-elle,  que  les  pas"}]}]}
>```
>%%
>*%%PREFIX%%e Clèves, Madame de Lafayette—%%HIGHLIGHT%% ==J'avoue== %%POSTFIX%%,  répondit-elle,  que  les  pas*
>%%LINK%%[[#^erh9lw8ktcv|show annotation]]
>%%COMMENT%%
>thématique de l'aveu personnel
>présent d'actualité
>1° personne
>%%TAGS%%
>
^erh9lw8ktcv


>%%
>```annotation-json
>{"created":"2022-06-28T11:45:41.666Z","text":"conjonction de coordination \nraisonnement concessif, exprime la connaissance de ses faiblesses et sous entendant qu'elle est en mesure de les contrôler","updated":"2022-06-28T11:45:41.666Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":14370,"end":14374},{"type":"TextQuoteSelector","exact":"mais","prefix":"ions  peuvent  me  conduire  ;  ","suffix":"  elles  ne sauraient m'aveugler"}]}]}
>```
>%%
>*%%PREFIX%%ions  peuvent  me  conduire  ;%%HIGHLIGHT%% ==mais== %%POSTFIX%%elles  ne sauraient m'aveugler*
>%%LINK%%[[#^usjbqxrct3f|show annotation]]
>%%COMMENT%%
>conjonction de coordination 
>raisonnement concessif, exprime la connaissance de ses faiblesses et sous entendant qu'elle est en mesure de les contrôler
>%%TAGS%%
>
^usjbqxrct3f


>%%
>```annotation-json
>{"created":"2022-06-28T11:49:20.088Z","text":"affirmation de sa lucidité et souligne le fait qu'elle fait usage de raison et qu'elle ne se laisse dominer les par les passions (ref. classicisme)","updated":"2022-06-28T11:49:20.088Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":14408,"end":14445},{"type":"TextQuoteSelector","exact":"Rien ne me peut empêcher de connaître","prefix":"elles  ne sauraient m'aveugler. ","suffix":" que vous êtes né avec toutes le"}]}]}
>```
>%%
>*%%PREFIX%%elles  ne sauraient m'aveugler.%%HIGHLIGHT%% ==Rien ne me peut empêcher de connaître== %%POSTFIX%%que vous êtes né avec toutes le*
>%%LINK%%[[#^7om1lf6153l|show annotation]]
>%%COMMENT%%
>affirmation de sa lucidité et souligne le fait qu'elle fait usage de raison et qu'elle ne se laisse dominer les par les passions (ref. classicisme)
>%%TAGS%%
>
^7om1lf6153l


>%%
>```annotation-json
>{"created":"2022-06-28T11:52:38.517Z","text":"portrait du duc de Nemours qui semble laudatif (éloge) thème de la galanterie car il est connu comme un séducteur","updated":"2022-06-28T11:52:38.517Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":14450,"end":14462},{"type":"TextQuoteSelector","exact":"vous êtes né","prefix":" peut empêcher de connaître que ","suffix":" avec toutes les  dispositions  "}]}]}
>```
>%%
>*%%PREFIX%%peut empêcher de connaître que%%HIGHLIGHT%% ==vous êtes né== %%POSTFIX%%avec toutes les  dispositions*
>%%LINK%%[[#^85krwt4z6dh|show annotation]]
>%%COMMENT%%
>portrait du duc de Nemours qui semble laudatif (éloge) thème de la galanterie car il est connu comme un séducteur
>%%TAGS%%
>
^85krwt4z6dh


>%%
>```annotation-json
>{"created":"2022-06-28T11:55:19.265Z","text":"explicatif et ce qui conduit à la décision irréversible de la princesse. ça lui permet de faire le bilan avec le passé composé","updated":"2022-06-28T11:55:19.265Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":14598,"end":14634},{"type":"TextQuoteSelector","exact":"Vous avez déjà eu plusieurs passions","prefix":" y  donner  des succès heureux. ","suffix":", vous en auriez encore ; je ne "}]}]}
>```
>%%
>*%%PREFIX%%y  donner  des succès heureux.%%HIGHLIGHT%% ==Vous avez déjà eu plusieurs passions== %%POSTFIX%%, vous en auriez encore ; je ne*
>%%LINK%%[[#^no7xch6qk7|show annotation]]
>%%COMMENT%%
>explicatif et ce qui conduit à la décision irréversible de la princesse. ça lui permet de faire le bilan avec le passé composé
>%%TAGS%%
>
^no7xch6qk7


>%%
>```annotation-json
>{"created":"2022-06-28T11:57:09.237Z","text":"se projette avec le conditionnel à valeur de possible. On observe une tournure négative du bonheur ","updated":"2022-06-28T11:57:09.237Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":14636,"end":14770},{"type":"TextQuoteSelector","exact":"vous en auriez encore ; je ne ferais plus  votre  bonheur  ;  je  vous  verrais  pour  une  autre  comme  vous  auriez  été  pour  moi","prefix":"vez déjà eu plusieurs passions, ","suffix":".  J'en 5 aurais une douleur mor"}]}]}
>```
>%%
>*%%PREFIX%%vez déjà eu plusieurs passions,%%HIGHLIGHT%% ==vous en auriez encore ; je ne ferais plus  votre  bonheur  ;  je  vous  verrais  pour  une  autre  comme  vous  auriez  été  pour  moi== %%POSTFIX%%.  J'en 5 aurais une douleur mor*
>%%LINK%%[[#^wv2oycje15|show annotation]]
>%%COMMENT%%
>se projette avec le conditionnel à valeur de possible. On observe une tournure négative du bonheur 
>%%TAGS%%
>
^wv2oycje15


>%%
>```annotation-json
>{"created":"2022-06-28T11:59:34.629Z","text":"hyperbole","updated":"2022-06-28T11:59:34.629Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":14791,"end":14807},{"type":"TextQuoteSelector","exact":"douleur mortelle","prefix":"  pour  moi.  J'en 5 aurais une ","suffix":", et je ne serais pas même assur"}]}]}
>```
>%%
>*%%PREFIX%%pour  moi.  J'en 5 aurais une%%HIGHLIGHT%% ==douleur mortelle== %%POSTFIX%%, et je ne serais pas même assur*
>%%LINK%%[[#^6cayzwa56ih|show annotation]]
>%%COMMENT%%
>hyperbole
>%%TAGS%%
>
^6cayzwa56ih


>%%
>```annotation-json
>{"created":"2022-06-28T12:00:35.877Z","text":"comparaison représentant une séduction infinie","updated":"2022-06-28T12:00:35.877Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":14735,"end":14741},{"type":"TextQuoteSelector","exact":"comme ","prefix":"ous  verrais  pour  une  autre  ","suffix":" vous  auriez  été  pour  moi.  "}]}]}
>```
>%%
>*%%PREFIX%%ous  verrais  pour  une  autre%%HIGHLIGHT%% ==comme== %%POSTFIX%%vous  auriez  été  pour  moi.*
>%%LINK%%[[#^16b443ghxkg|show annotation]]
>%%COMMENT%%
>comparaison représentant une séduction infinie
>%%TAGS%%
>
^16b443ghxkg


>%%
>```annotation-json
>{"created":"2022-06-28T12:02:54.476Z","text":"insiste sur la thématique de l'aveu","updated":"2022-06-28T12:02:54.476Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":14886,"end":14925},{"type":"TextQuoteSelector","exact":"Je vous en ai trop dit pour vous cacher","prefix":"oint le malheur de la jalousie. ","suffix":" que vous me l'avez fait connaît"}]}]}
>```
>%%
>*%%PREFIX%%oint le malheur de la jalousie.%%HIGHLIGHT%% ==Je vous en ai trop dit pour vous cacher== %%POSTFIX%%que vous me l'avez fait connaît*
>%%LINK%%[[#^vv92g920eve|show annotation]]
>%%COMMENT%%
>insiste sur la thématique de l'aveu
>%%TAGS%%
>
^vv92g920eve


>%%
>```annotation-json
>{"created":"2022-06-28T12:03:47.094Z","text":"lexique de la souffrance\njustification principale","updated":"2022-06-28T12:03:47.094Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":14972,"end":15006},{"type":"TextQuoteSelector","exact":"souffris  de  si  cruelles  peines","prefix":"avez fait connaître, et que je  ","suffix":"  le  soir  que  la  reine  me  "}]}]}
>```
>%%
>*%%PREFIX%%avez fait connaître, et que je%%HIGHLIGHT%% ==souffris  de  si  cruelles  peines== %%POSTFIX%%le  soir  que  la  reine  me*
>%%LINK%%[[#^xqv8tc22upk|show annotation]]
>%%COMMENT%%
>lexique de la souffrance
>justification principale
>%%TAGS%%
>
^xqv8tc22upk


>%%
>```annotation-json
>{"created":"2022-06-28T12:04:34.731Z","text":"conclusion déclamatoire\nprésent de vérité générale","updated":"2022-06-28T12:04:34.731Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":15128,"end":15147},{"type":"TextQuoteSelector","exact":"il m'en est demeuré","prefix":"sait qui s'adressait à vous, qu'","suffix":" une idée qui me fait croire que"}]}]}
>```
>%%
>*%%PREFIX%%sait qui s'adressait à vous, qu'%%HIGHLIGHT%% ==il m'en est demeuré== %%POSTFIX%%une idée qui me fait croire que*
>%%LINK%%[[#^wj1sp2hno9m|show annotation]]
>%%COMMENT%%
>conclusion déclamatoire
>présent de vérité générale
>%%TAGS%%
>
^wj1sp2hno9m


>%%
>```annotation-json
>{"created":"2022-06-28T12:13:26.900Z","text":"contexte\ncaractère galant de Nemours","updated":"2022-06-28T12:13:26.900Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":15251,"end":15305},{"type":"TextQuoteSelector","exact":" toutes  les  femmes  souhaitent  de  vous  attacher. ","prefix":" 10 Par  vanité  ou  par  goût, ","suffix":" Il  y  en  a  peu  à  qui vous "}]}]}
>```
>%%
>*%%PREFIX%%10 Par  vanité  ou  par  goût,%%HIGHLIGHT%% ==toutes  les  femmes  souhaitent  de  vous  attacher.== %%POSTFIX%%Il  y  en  a  peu  à  qui vous*
>%%LINK%%[[#^ixljsumhkr|show annotation]]
>%%COMMENT%%
>contexte
>caractère galant de Nemours
>%%TAGS%%
>
^ixljsumhkr


>%%
>```annotation-json
>{"created":"2022-06-28T12:14:53.867Z","text":"champs lexical de la séduction","updated":"2022-06-28T12:14:53.867Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":15340,"end":15348},{"type":"TextQuoteSelector","exact":"plaisiez","prefix":"  y  en  a  peu  à  qui vous ne ","suffix":" ; mon expérience me ferait croi"}]}]}
>```
>%%
>*%%PREFIX%%y  en  a  peu  à  qui vous ne%%HIGHLIGHT%% ==plaisiez== %%POSTFIX%%; mon expérience me ferait croi*
>%%LINK%%[[#^hal1se6xca4|show annotation]]
>%%COMMENT%%
>champs lexical de la séduction
>%%TAGS%%
>
^hal1se6xca4


>%%
>```annotation-json
>{"created":"2022-06-28T12:15:58.113Z","text":"démontre et se projette avec de multiples conditionnels","updated":"2022-06-28T12:15:58.113Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":15369,"end":15375},{"type":"TextQuoteSelector","exact":"ferait","prefix":"ne plaisiez ; mon expérience me ","suffix":" croire qu'il n'y en a point à q"}]}]}
>```
>%%
>*%%PREFIX%%ne plaisiez ; mon expérience me%%HIGHLIGHT%% ==ferait== %%POSTFIX%%croire qu'il n'y en a point à q*
>%%LINK%%[[#^cdx3rel08v8|show annotation]]
>%%COMMENT%%
>démontre et se projette avec de multiples conditionnels
>%%TAGS%%
>
^cdx3rel08v8


>%%
>```annotation-json
>{"created":"2022-06-28T12:18:55.635Z","text":"montre qu'elle ne peut que souffrir\nrappel du statut soumis des épouses","updated":"2022-06-28T12:18:55.635Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":15539,"end":15565},{"type":"TextQuoteSelector","exact":" je n'aurais d'autre parti","prefix":"ouvent. Dans cet état néanmoins,","suffix":" à prendre que celui de la souff"}]}]}
>```
>%%
>*%%PREFIX%%ouvent. Dans cet état néanmoins,%%HIGHLIGHT%% ==je n'aurais d'autre parti== %%POSTFIX%%à prendre que celui de la souff*
>%%LINK%%[[#^njk1bjbvdd8|show annotation]]
>%%COMMENT%%
>montre qu'elle ne peut que souffrir
>rappel du statut soumis des épouses
>%%TAGS%%
>
^njk1bjbvdd8


>%%
>```annotation-json
>{"created":"2022-06-28T12:20:57.034Z","text":"question rhétorique","updated":"2022-06-28T12:20:57.034Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":15647,"end":15770},{"type":"TextQuoteSelector","exact":"On fait des reproches à un amant ; mais en fait-on à un mari, 15 quand on n'a à lui reprocher que de n'avoir plus d'amour ?","prefix":" même si j'oserais me plaindre. ","suffix":" Quand je pourrais m'accoutumer "}]}]}
>```
>%%
>*%%PREFIX%%même si j'oserais me plaindre.%%HIGHLIGHT%% ==On fait des reproches à un amant ; mais en fait-on à un mari, 15 quand on n'a à lui reprocher que de n'avoir plus d'amour ?== %%POSTFIX%%Quand je pourrais m'accoutumer*
>%%LINK%%[[#^0jjbt5q4udua|show annotation]]
>%%COMMENT%%
>question rhétorique
>%%TAGS%%
>
^0jjbt5q4udua


>%%
>```annotation-json
>{"created":"2022-06-28T12:23:31.051Z","text":"tournure concessive","updated":"2022-06-28T12:23:31.051Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":15771,"end":15776},{"type":"TextQuoteSelector","exact":"Quand","prefix":"r que de n'avoir plus d'amour ? ","suffix":" je pourrais m'accoutumer à cett"}]}]}
>```
>%%
>*%%PREFIX%%r que de n'avoir plus d'amour ?%%HIGHLIGHT%% ==Quand== %%POSTFIX%%je pourrais m'accoutumer à cett*
>%%LINK%%[[#^t4sfbgv1hy|show annotation]]
>%%COMMENT%%
>tournure concessive
>%%TAGS%%
>
^t4sfbgv1hy


>%%
>```annotation-json
>{"created":"2022-06-28T12:24:18.295Z","text":"accumulation","updated":"2022-06-28T12:24:18.295Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":15909,"end":15941},{"type":"TextQuoteSelector","exact":"accuser de sa mort, me reprocher","prefix":"oujours monsieur de Clèves vous ","suffix":" de vous avoir aimé, de vous avo"}]}]}
>```
>%%
>*%%PREFIX%%oujours monsieur de Clèves vous%%HIGHLIGHT%% ==accuser de sa mort, me reprocher== %%POSTFIX%%de vous avoir aimé, de vous avo*
>%%LINK%%[[#^2i5n37tyq9z|show annotation]]
>%%COMMENT%%
>accumulation
>%%TAGS%%
>
^2i5n37tyq9z


>%%
>```annotation-json
>{"created":"2022-06-28T12:35:08.894Z","text":"rythme ternaire, gradation et une attaque au duc De Nemours \nElle lui sous-entend qu'il n'est pas au niveau de ces attentes","updated":"2022-06-28T12:35:08.894Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":15885,"end":15982},{"type":"TextQuoteSelector","exact":"monsieur de Clèves vous accuser de sa mort, me reprocher de vous avoir aimé, de vous avoir épousé","prefix":"à celui de croire voir toujours ","suffix":" et me faire sentir la différenc"}]}]}
>```
>%%
>*%%PREFIX%%à celui de croire voir toujours%%HIGHLIGHT%% ==monsieur de Clèves vous accuser de sa mort, me reprocher de vous avoir aimé, de vous avoir épousé== %%POSTFIX%%et me faire sentir la différenc*
>%%LINK%%[[#^l2vdkz1n44n|show annotation]]
>%%COMMENT%%
>rythme ternaire, gradation et une attaque au duc De Nemours 
>Elle lui sous-entend qu'il n'est pas au niveau de ces attentes
>%%TAGS%%
>
^l2vdkz1n44n


>%%
>```annotation-json
>{"created":"2022-06-28T12:39:29.727Z","text":"clot la réponse","updated":"2022-06-28T12:39:29.727Z","document":{"title":"Microsoft Word - ADEF-2022-AAK-Récap-EAF-604-2022  copie.docx","link":[{"href":"urn:x-pdf:c8b4111992c8de69e781c0251325c6ea"},{"href":"vault:/Commun/textes_oral_bac.pdf"}],"documentFingerprint":"c8b4111992c8de69e781c0251325c6ea"},"uri":"vault:/Commun/textes_oral_bac.pdf","target":[{"source":"vault:/Commun/textes_oral_bac.pdf","selector":[{"type":"TextPositionSelector","start":16232,"end":16238},{"type":"TextQuoteSelector","exact":"jamais","prefix":" que j'ai prises de n'en sortir ","suffix":".    Madame de Lafayette, La Pri"}]}]}
>```
>%%
>*%%PREFIX%%que j'ai prises de n'en sortir%%HIGHLIGHT%% ==jamais== %%POSTFIX%%.    Madame de Lafayette, La Pri*
>%%LINK%%[[#^tgajomhxzsb|show annotation]]
>%%COMMENT%%
>clot la réponse
>%%TAGS%%
>
^tgajomhxzsb
