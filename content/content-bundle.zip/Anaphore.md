[[français]] [[bac_français]] [[figure de style]]
___
répétition du même mot (ou expression) en début de proposition.