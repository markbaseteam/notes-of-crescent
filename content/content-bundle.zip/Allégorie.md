[[français]] [[bac_français]] [[figure de style]]
___
personnification d'une *grande (littéralement)* idée