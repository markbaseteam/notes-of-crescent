[[français]] [[bac_français]] [[figure de style]]
___
expression adoucie par rapport à la réalité