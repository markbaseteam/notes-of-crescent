[[français]] [[bac_français]] [[figure de style]]
___
montre un point commun avec l'objet du texte et autre chose