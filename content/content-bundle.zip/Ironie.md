[[français]] [[bac_français]] [[figure de style]]
___
dire l'opposé pour rire