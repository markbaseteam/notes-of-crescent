#☀️ 
___
Produit de l'énergie thermique, fonction affine croissante [[coefficient directeur.jpg]]
1. $$P=R\times I²$$
2. $$P=\frac {U²} {R}$$