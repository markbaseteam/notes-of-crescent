[[français]] [[bac_français]] [[figure de style]]
___
mélange entre [[Hyperbole]] et [[Ironie]]. On dit avec positif/affirmatif ce qui est vraiment/très négatif, inverse on dit avec négation ce qui est vraiment/très positif