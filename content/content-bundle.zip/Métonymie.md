[[français]] [[bac_français]] [[figure de style]]
___
proposition considérant une partie de contenu pour sa forme ou sa forme pour une partie du contenu