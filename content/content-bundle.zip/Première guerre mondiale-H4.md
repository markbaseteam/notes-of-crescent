[[Cours_Histoire-Géo]] #📝/cours
___
# Le "suicide de l'Europe" et la fin des empires européens
## En quoi la Première guerre mondiale marque-t-elle le suicide de l'Europe ?
### Un embrasement mondial et ses grandes étapes
#### L'engrenage infernal
1. *28 juin 1914* Attentat de Sarajevo contre héritier Empire austro-hongrois
	1. Autriche-Hongrie (se sent aggressé) déclare la guerre à la Russie et fait alliance avec **l'Allemagne**
		1. Russie déclare la guerre à la Russie