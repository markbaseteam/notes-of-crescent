[[français]] [[bac_français]] [[figure de style]]
___
répétition de consonnes 
- en texte traditionnel dans groupe nominal ou verbal
- sinon simplement une répétition de consonnes