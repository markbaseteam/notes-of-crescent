[[Modèle fiches français]] 
___
# Automne malade
## Introduction
##### Auteur (nom, époque, mouvement, principales œuvres): 
[[Guillaume Apollinaire]]
##### Œuvre (titre, genre, date, si besoin court résumé, thèmes, contexte) :
==J'insiste pour dire que== c'est un recueil novateur et inclassable qui renouvelle la conception de la modernité en l'inscrivant à la fois dans une nouveauté surprenante et dans un héritage poétique assumé
##### Extrait (place dans l’œuvre, résumé, rôle dans l’œuvre et présentation des personnages si nécessaire) :
fait partie du cycle d'Annie, s'éloigne de la tradition poétique -> **s'adresse à la saison** en vers libre
## Lecture Expressive
## Problématique/enjeu 
==À la lecture de se passage, nous pouvons nous demander:== en quoi cette invocation mélancolique à l'automne renouvelle-t-elle un topos de la poésie et se transforme-t-elle en méditation sur la condition humaine.
## Mouvements
1. ==nous verrons dans un premier temps== de la ligne _ à la ligne _ ==l'auteur/le narrateur== au chevet d'un automne mourant
2. ==Puis dans un deuxième temps== de la ligne _ à la ligne _ ==nous voyons que== l'expression mélancolie amoureuse
3. ==Enfin== de la ligne _ à la ligne _ ==nous constatons== que le temps fuit

## Analyse Linéaire
#### mouvement n°1 :
analyse de l'effet produit|nom du procédé|extrait|ligne
--- | --- | --- | --

##### résumé des idées du mouvement :
#### mouvement n°2 :
analyse de l'effet produit|nom du procédé|extrait|ligne
--- | --- | --- | --

##### résumé des idées du mouvement :
#### mouvement n°3 :
analyse de l'effet produit|nom du procédé|extrait|ligne
--- | --- | --- | --

##### résumé des idées du mouvement :
## **Conclusion**
#### Idées principales :

#### Réponse à la problématique :

#### Ouverture :



> 
\-

\-
