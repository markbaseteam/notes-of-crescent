[[blog]]
___
*ancienne dernière du préambule de la constitution suisse* "La force de la communauté se mesure au bien-être du plus fort de ces membres"

Je souhaiterai continuer cet exposé par dire que je n'aime pas ce que les gens font, franchement moi je vous le dis, j'en ai marre quand les gens rentrent chez eux, je pense qu'ils ont oublié leur cerveau au monde du travail. 
Vous les voyez maintenant les barrières chaque jour elle guide votre vie, chaque jour vous vous réveillez et vous vous dites si seulement je pourrai jouer toute la journée mais sachez que c'est possible et en plus c'est beaucoup plus facile que ce que vous croyez. 
	- *Exemple du [[pilote de chasse.png]]* : il est entrainé sur un simulateur donc c'est littéralement un jeu-vidéo. Il a un casque super ergonomique le pilote de chasse, avant il y avait un simple joystick pour envoyer des missiles maintenant il suffit que le pilote cligne des yeux et le missile part. 
On a ce sur quoi Aberkane a fondé son livre c'est la neuro-ergonomie. 
Une des manière la plus simple d'apprendre c'est par le jeu -> les animaux le font

- exemple du [[buffet à volonté]] 
	- Imaginez Ce buffet c'est le buffet de votre vie c'est le meilleur repas que vous allez dévorer.
	- Imaginez qu'il y ait un maitre d'hôtel qui débarque et qui vous dise vous devez tout manger, et chaque aliment que tu ne finis pas ce sera un aliment que tu devras payer. Tu payeras alors ce que tu n'as pas manger. 
		- Si tu en laisses trop on te vire et on fera tout pour t'humilier
		- Tu as une heure parce qu'on sait que c'est possible puisque quelqu'un l'a fait
			- **Là on est en enfer** et on a toujours notre magnifique buffet
				- Vous savez pourquoi ? parce qu'on a changé les règles pourtant le buffet lui il a rien fait, le buffet est le même mais en fonction des règles que l'on applique et bien on dégoute les gens. 
- Dans la réalité, si on vous séquestre pour manger vous auriez fait quoi ? 
	- Cette situation qu'Idriss Aberkane a décrite c'est quoi ?
		- c'est l'enseignement puisque l'on est sanctionner sur ce que notre cerveau n'a pas digéré
			- Vous avez beau être intelligent, mais on s'appelle pas tous disque dur dans cette classe, parce qu'on est peut-être un peu plus intelligent que la tablette que j'ai entre les mains, vous allez dire mais Adrien t'es paumé, mais il se trouve que j'ai la fine impression d'être bien plus humain que les gens ne le pensent et Idriss Aberkane va vous expliquer pourquoi.

"Vous allez prendre des décisions, c'est pas vos décisions, vous allez vivre dans les idées de quelqu'un d'autre"
Le truc dans ton cerveau qui te dit mais regarde les maths c'est pas fait pour toi. Vous voyez pourquoi j'en ai marre parce que vous passez votre temps à regarder votre moyenne à regarder le nombre de truc que vous n'avez pas mangé, en se disant j'y arriverai pas j'y arriverai pas et c'est normal, c'est considéré comme la norme de jamais y arriver, de ce dire, (moi de mon côté je me demande : "Est-ce que je suis assez conforme pour l'éducation nationale ?")
"Se dire que son chemin est tellement loin de la note maximale c'est se dire" mais c'est absolument logique puisque tu n'as tout simplement pas mangé ce qui restait sur le buffet. Alors voilà on te dit littéralement tu vaux tant de moyenne, alors que c'est toujours faux, puisque si ça avait du sens tout le monde aurait envie de manger.

(La société entière est là pour que vous avez tant de moyenne, même vos parents, même vos camarades de classe vous diront ah bah c'est normal lui il est pas très intelligent). Vous voulez qu'Aberkane vous dise c'est qui les gens qui sont pas très intelligents, ce seront ceux qui quand ne seront plus à l'école y auront oublié leur cerveau, et ça *dans un monde rationnel* ça ne s'explique pas puisque totalement et intégralement stupide et d'une débilité profonde. Concrétement c'est vivre dans les idées de quelqu'un d'autre et je ne voudrai jamais vivre dans les idées de quelqu'un et encore plus **comme en parle ==Josef Schovanec==** si c'est un politique : "Moi président ! Moi président !". On verra à la fin de l'exposé les *[politiques]*.
Ces gens là ne voudront jamais l'admettre car ils auront perdu tellement de temps. 

Peut-être que si l'éducation nationale met autant de pression sur les élèves pour qu'ils regardent tous leurs notes, je pense que ça reflète que le système ne sait pas construire ou construire avec les moyens de cinquante ans en arrière. 
Et l'incompétence c'est quelque chose que des gens comme peuvent voir. 

On parle souvent aujourd'hui du réchauffement climatique, il faut arrêter de polluer, arrêter de polluer, arrêter de polluer ; mais on se retrouve avec des imbéciles qui ne savent pas résoudre le problème parce qu'ils doivent respecter la diplomatie quoi. 
(C'est un peu comme l'éducation nationale, si tu sais parfaitement écrire parce que tu es autiste et bien vous devrez apprendre par coeur les textes d'Apollinaire ce qui pourrait te servir si ce n'est que apprendre par coeur ne sert à rien en soi. Et puis si vous savez pas écrire que ce n'est pas une passion vous allez apprendre par coeur sans que ça ait strictement aucun sens, combien de personnes dans notre classe n'ont pas ressenti l'envie d'écrire pour soi, moi je pense que c'est la grande majorité du lycée.)
Les [politiques] sont super étrange : ils vous regardent dans les *yeux* ; pourtant quand M. Macron a dû téléphoner à M. Putin, je crois qu'il n'a pas pu le regarder dans les yeux, cependant M. Macron a dû emettre des petits bruits, toutes les 5 secondes, **rationnellement** tout ça *c'est de la poudre de perlinpinpin* si j'ose dire ; ils adorent regarder les gens je pense. Et les gens aiment bien quand on ne leur raconte pas des histoires ironiquement, les français aiment apprendre une langue avec les autres, mais pas en lisant tout seul toute la nuit. Les français n'aiment pas apprendre l'orthographe, mais la meilleure manière d'apprendre l'orthographe c'est d'écrire pour le plaisir, curieusement les fautes après sont beaucoup moins nombreuses.
### le mode de fonctionnement autistique est le plus optimal et original
Prenons une situation **social**, on fait semblant de me bloquer parce qu'on ne veut plus me parler. L'autiste réagit par rapport au "je te bloque" n'ayant pas de raison valable, et donc l'idée de base n'est pas visible à l'autiste. 
Maintenant prenons l'**inverse** la personne dit je n'ai plus envie de discuter avec toi parce que la réflexion philosophique ne m'intéresse pas, on a donc une personne normale qui va réagir de manière vexée et ça n'aurait pas été le cas précédemment. Le mode de fonctionnement autistique permet de se débrouiller avec ce qu'il considère comme la vérité fondamentale soit une vérité fondamentale à l'échelle d'une personne. 

Ça prouve également que ce que vous appelez autisme est *probablement* un trouble dysocial.

==Je casse, et je brise la règle que nous a imposé notre professeur qui est de faire une recherche sur un seul lanceur d'alerte ; moi que vous le vouliez ou non j'utilise mon cerveau et j'en parle de plusieurs.==

# Un trouble dysocial
Mais alors pourquoi me diriez vous l'autisme serait un trouble dysocial ?
tout d'abord, il faut savoir ce qu'est un trouble "dys", c'est-à-dire un fonctionnement cognitif différent -> info via internet, dans la définition je surligne les infos qui sont à l'évidence communes avec l'autisme bien qu'un autiste n'ait que plus ou moins ces types de troubles.

"**Les [troubles cognitifs spécifiques](https://www.ffdys.com/glossaire#troublespecifiquescognitifs) ==apparaissent au cours du développement de l’enfant**, avant ou lors des premiers apprentissages, **et persistent à l’âge adulte.** Ils ont des répercussions sur la vie scolaire, professionnelle et sociale, et peuvent provoquer **un déséquilibre psycho-affectif**. Leur repérage, leur dépistage et leur diagnostic sont déterminants.==

**Certains de ces troubles affectent les ==apprentissages précoces** : langage,== geste…  
==**D’autres affectent plus spécifiquement les apprentissages scolaires** comme le langage écrit, le calcul. Ils sont le plus souvent appelés troubles spécifiques des apprentissages.==

==**Ces troubles sont innés**==, mais certains enfants victimes d’un traumatisme crânien ou opérés et soignés pour une tumeur cérébrale peuvent également présenter des [troubles cognitifs spécifiques](https://www.ffdys.com/glossaire#troublespecifiquescognitifs) gênant la poursuite de leurs apprentissages."

On peut ensuite voir comment les dys sont classés par *troubles*, ce que je sais en terme de points communs :
- écrit : difficulté d'habilité
- oral : **décalage** -> absence d'explication sur ce dont parle la personne 
- moteur et visuo-spatiales : difficulté d'utilisation et de manipulation ; "**Difficultés visuo-spatiales** ne permettant pas un bon repérage dans l’espace, en particulier pour se déplacer dans des lieux peu familiers, pour se repérer sur un plan, ou dans l’espace de la feuille du cahier, dans les pages d’un livre ou d’un dictionnaire, pour lire un graphique, des tableaux …"
- tda/h : "**Grande distractivité**" ; "**Difficultés à diriger son attention, et à la mener à son terme**" ; "**Difficulté à réguler son impulsivité dans les échanges sociaux**"
- mnésiques : "**Oubli des consignes** données (l’enfant ou l’adulte doit relire plusieurs fois)." ; "**Égarement et perte d’objets** personnels fréquents." ; "**Difficulté à donner du sens aux textes longs** par oubli du contenu des premières phrases alors que la lecture est courante."

"**On regroupe ces troubles en 6 catégories** :  
• Les troubles spécifiques de l’acquisition du langage écrit, communément appelés **dyslexie et dysorthographie**.  
• Les troubles spécifiques du développement du langage oral, communément appelés **dysphasie**.  
• Les troubles spécifiques du développement moteur et/ou des fonctions visuo-spatiales, communément appelé **dyspraxie**.  
• Les troubles spécifiques du développement des processus attentionnels et/ou des fonctions exécutives, communément appelés **troubles d’attention avec ou sans hyperactivité**.  
• **Les troubles spécifiques du développement des processus mnésiques.**  
• Les troubles spécifiques des activités numériques, communément appelés **dyscalculie**."
## Le problème social
Le problème est que notre monde fonctionne de manière social, et la socialité ayant une place particulièrement importante dans la société, les personnes autistes pourraient être plus handicapées en plus de leur fonctionnement cognitif spécifique. 