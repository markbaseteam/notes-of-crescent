[[MOOC_Ecriture]]
___
# Pont Musical
Le pont auquel on pense est la musique ;
Où nous roulons, 
Un besoin sacré,
Notre désir profond.
Notre pont est plus que matériel, pourtant pas très économique

Le désir artistique sait où mène le pont
C'est le miel de nos ciels et pas celui du PIB
Un monde sans pareil
Nos airs sont des pontons vers l'amitié

Nos oreilles veulent garder la musique
Un son différent et nouveau
Meilleur qu'un désir, une réalité