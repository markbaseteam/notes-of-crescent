
Ich war in der vierten Klasse wenn es anfig. 
## Anfang
- Ich wollte die Welt beschreiben, um sie zu verstehen, aber ich war völlig unkonventionell
- Das Ziel war, sich besser zu fühlen, und es wurde nicht gewonnen. Ich habe es geschafft, das Problem zu sehen, weil ich Kommunikationsprobleme hatte und im Urlaub war, also habe ich es ausgenutzt.
## Meine Methode 
- rester concentré tout le temps sur les sentiments|*Wir brachen* auf Gefühle fokussiert bleiben
- Etre attentif à ce qui se passe autour de soi|Achten Sie darauf, was um Sie herum passiert
## und hier war ich 
1. Ich war im Paris, die Hauptstadt von Frankreich. Ich ging auf die Musikschule in Paris
2. Ich liebte es, in der U-Bahn zu schreiben, aber ich  auch auf der Straße schrieb und auch vor und nach dem Schlafen
## die Feststellung | conclusion
- Je n'avais absolument pas prévu ce qui a pu se passer dans ma tête, ça fait une sorte de tornade de remise en ordre|Ich hatte absolut nicht vorhergesehen, was in meinem Kopf hätte passieren können, es war eine Art Tornado, die Dinge wieder in Ordnung zu bringen
- Le résultat est très intéressant puisque l'on atteint un niveau de bien-être très impressionant|Das Ergebnis ist sehr interessant, da wir ein sehr beeindruckendes Wohlbefinden erreichen.
- Je recommande ça pour les personnes qui ont un véritable problème avec eux-même et ce qu'elles montrent.|Ich empfehle dies für Leute, die ein echtes Problem mit sich selbst und dem haben, was sie zeigen