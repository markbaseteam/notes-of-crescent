- [ ] [[ebook-apprendre-feraste]]
	chaine youtube : https://www.youtube.com/channel/UCCLmaHvhoFWz30Y22PzP9Gg
- [ ] [[Livre GTD]]
- [ ] influence et manipulation
- [ ] [[Père riche, père pauvre]]
- [ ] [[différences asperger et hp]]