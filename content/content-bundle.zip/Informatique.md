[[moc_informatique]] #✅
___
- [ ] changer emplacement corbeille ★
- [ ] trouver/programmer une barre d'exp sur obsidian