[[français]] [[bac_français]] [[figure de style]]
___
plus particulier que l'[[Antithèse]] car dans un même groupe