[[auteur]] [[bac_français]]
___
Mme Delafayette est une autrice du 17° siècle, elle est fille du médecin du roi (et elle a écris sur le milieu de la haute noblesse). Elle est dame ( ou plutôt demoiselle) de compagnie. Elle est heureuse à la cour, se fait des amies, devient une personne sentimentale puis vraiment littéraire avec son temps avec la parution de *La princesse de Montpensier* en 1662