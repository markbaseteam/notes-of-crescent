[[Zettelkasten]]
___
Composé de nombres dans obsidian. On voit aussi que c'était utilisé quand on utilise pas l'informatique.
