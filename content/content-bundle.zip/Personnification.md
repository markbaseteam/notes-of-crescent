[[français]] [[bac_français]] [[figure de style]]
___
même chose qu'une [[Métaphore]] mais le comparant est quelque chose d'humain