[[permanent]]
# Caractéristiques
- bidirectionnel
- fait le réseau
- on peut faire une note qui mène à plusieurs  fichiers 