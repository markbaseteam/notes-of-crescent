[[maths]] #☀️/cours
___
# Probabilité
Noté $\Omega$ désigne l'ensemble des résultats possibles pour une expérience aléatoire