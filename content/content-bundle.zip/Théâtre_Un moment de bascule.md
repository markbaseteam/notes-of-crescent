
___
Louis 1" a interdit aux protestants d'avoir des places fortes
Fronde des aristocrates quand Louis 14 était enfant -> l'Eglise a prêché pour le roi "Le roi est un soleil"
A partir du 17° le roi "ne bouge plus" et le centre est Versailles, même si l'Eglise ne voit pas le soleil de la même façon mais ça avantage le roi. 
___
Le roi semble executer un pas de danse. Le costume est doré, avec une couronne qui imite les rayons du soleil. Un grand soleil décor son pourpoint
Les souliers sont précieusement ornés, il porte un chapeau à plume, le costume est léger pour faciliter la danse -> le but est de l'identifier, le repérer
Il se présente comme un personnage charismatique et comme le centre de l'attention.