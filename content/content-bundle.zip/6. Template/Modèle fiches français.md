#⚙️ [[11 étude linéaire molière 2]] 
___
# Nom de l'extrait
## Introduction
##### Auteur (nom, époque, mouvement, principales œuvres): 

##### Œuvre (titre, genre, date, si besoin court résumé, thèmes, contexte) :
==J'insiste pour dire que==
##### Extrait (place dans l’œuvre, résumé, rôle dans l’œuvre et présentation des personnages si nécessaire) :

## Lecture Expressive
## Problématique/enjeu 
==À la lecture de se passage, nous pouvons nous demander:== 
## Mouvements
1. ==nous verrons dans un premier temps== de la ligne _ à la ligne _ ==l'auteur/le narrateur== ...
2. ==Puis dans un deuxième temps== de la ligne _ à la ligne _ ==nous voyons que== ...
3. ==Enfin== de la ligne _ à la ligne _ ==nous constatons== ...

## Analyse Linéaire
#### mouvement n°1 :
analyse de l'effet produit|nom du procédé|extrait|ligne
--- | --- | --- | --

##### résumé des idées du mouvement :
#### mouvement n°2 :
analyse de l'effet produit|nom du procédé|extrait|ligne
--- | --- | --- | --

##### résumé des idées du mouvement :
#### mouvement n°3 :
analyse de l'effet produit|nom du procédé|extrait|ligne
--- | --- | --- | --

##### résumé des idées du mouvement :
## **Conclusion**
#### Idées principales :

#### Réponse à la problématique :

#### Ouverture :



> 
\-

\-
