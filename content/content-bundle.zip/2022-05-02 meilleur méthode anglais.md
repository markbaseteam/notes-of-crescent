[[MOOC_Ecriture]] #📥
___
Sachant qu'en matière scientifique, l'éducation utilise la vérité, ce qui donne des cours sous forme de ressource