[[français]] [[bac_français]] [[figure de style]]
___
énonciation de qualification **inutile** (littéralement)