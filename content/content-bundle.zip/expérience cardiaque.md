#☀️ 
___
[[utilisation electrocardiogramme]]. On ne fait rien écouter tout d'abord, puis à 30 secondes on met du bruit. En même temps on mesure.
![[Pasted image 20220603110750.png]] 