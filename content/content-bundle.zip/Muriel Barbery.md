[[auteur]] [[bac_français]]
___
Elle normalienne et agrégée de philosophie, elle aime vivre loin des médias mais elle a eu de nombreux prix littéraires.