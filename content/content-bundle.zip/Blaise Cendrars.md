[[auteur]] [[bac_français]]
___
Blaise Cendrars (1887-1964), de son vrai nom Frédéric Louis Sauser quitte très tôt sa Suisse natale pour voyager, est un poète suisse puis naturalisé français du 20° siècle. Son pseudonyme fait allusion aux braises et aux cendres permettant une renaissance cyclique au phénix. Il est comme [[Guillaume Apollinaire]] volontaire pour l'armée, il est amputé du bras droit et écrit sur le sujet. Il a inspiré [[Guillaume Apollinaire]] pour écrire en prose, et à la fin de ça vie s'oriente vers le roman avec *L'or* en 1925.
___
# Source
[Wikipédia](https://fr.wikipedia.org/wiki/Blaise_Cendrars)