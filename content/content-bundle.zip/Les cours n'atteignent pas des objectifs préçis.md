#🌲 [[les erreurs de l'éducation national]]
___
Les cours ne sont pas comme le concept que [[Les evergreen notes doivent être atomique]] mais ils utilisent des propriétés classés avec des titres et des sous-titres à assimiler.

Par exemple : Si on prend un cours (français) de maths (ce qui est censé être de la logique) qui n'est pas censé demander une reformulation perpétuelle pour l'assimiler, au hasard [[maths_trigonométrie]], pour réussir en trigonométrie vous avez besoin comprendre (l'énoncé + la leçon) et c'est tout. 

Pourquoi cela ? [[Les cours de l'éducation national handicapent la réflexion individuelles]]