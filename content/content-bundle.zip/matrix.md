#☀️ [[vocabulaire allemand]]
___
der Rat ; le conseil
ehrlich ; honnête
die Ehre ; l'honneur
sich fuhlen ; se sentir
Alice in Wunderland ; Alice au pays des merveilles
das Schicksal ; le destin
die Steuer ; l'impôt
die Wharheit ; la vérité
der Sklave ; l'esclave
das Gefängnis ; la prison
der Vestand ; la raison
an/bieten [[particule séparable]] ; offrir, proposer