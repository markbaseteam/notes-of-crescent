ich nemme die rote Pille weil ich im Wahrheit gehen mag, und konnen machen, aber es ist hart.
[[matrix]]