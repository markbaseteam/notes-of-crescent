[[psychologie]]
___
1. La stratégie d'intérêt est la stratégie qui a le plus de chance de satisfaire ses intérets
2. La stratégie double fonctions est la stratégie qui propose une vie professionnel et social "normale" et en parallèle les choses stimulantes
3. La stratégie d'abandon
___
# Référence
[[DOUANCE] FAQ Très Haut QI (supérieur à 145 = THQI)](http://www.douance.org/qi/thqi.html)