```todoist
{
"name": "My Tasks",
"filter": "today | overdue"
}
```
