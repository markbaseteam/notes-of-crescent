[[français]] [[bac_français]] [[figure de style]]
___
même chose que la [[Comparaison]] mais sans le mot de comparaison