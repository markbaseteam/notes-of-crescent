[[français]] [[bac_français]] [[figure de style]]
___
série de groupe marquant de plus en plus ou de moins en moins