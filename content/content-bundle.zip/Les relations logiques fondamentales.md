#📥 [[cours_Français]]
___
# L'expression de la cause de la conséquence et du but
## Exercice 1
1. but
2. conséquence
3. cause
4. but
5. conséquence
## Exercice 2
1. Il est puni car il est coupable
2. La route est barrée et donc elle a besoin d'être entretenue
3. Il lui a parlé dans ce but l'a invité
4. Comme nous partons ensemble, nous arrivons en même temps
## Exercice 3
1. thème de son sujet ; accident ; faire la part de l'accident
2. réalisme
Les deux causes sont le fait que d'une part que la vie est pleine de hasard et sue d'autre part les gens peuvent y mourir par accident
Mautpassant met en lumière de composition de l'artiste qui ne cherche pas à montrer la réalité telle quelle est mais à faire sens et à propser une certaine vision de la réalité en occultant le reste devenu secondaire