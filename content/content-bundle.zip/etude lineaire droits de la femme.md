[[étude linéaire]]
___
 
Comment ce préambule sert-il la cause des femmes ?
L'importance de défie et la multiplication des interrogations rhétoriques pour remettre en question la domination masculine
Elles sont multiples et teintes d'ironie. Olympe de Gouge avec Ironie met en doute les talents de l'homme avec des tournures hypothétiques expriment le défis
Leur impossibilité intellectuel de s'imposer aux idée de l'autrice. Apostrophe dun discours explicitement tenu a l'homme. le tutoiement place tout le monde sur un pied d'égalité
## 1° mouvement

La confrontation apparaît clairement dans l'antithese, l'usage du singulier renforce l'idée d'un duel. L'adoption d'une posture d'autorité par l'emploi à futur a valeur impératif et par la multiplication des impératifs Malgré le ton polémique une réflexion organisée.

Les marques du ton polémique, la posture d autorité se poursuit par la multiplication des impératif donne a l'homme le rôle de simple executant. Elle apparaît meme en position de maître, c est ici la personne qui est sujet et c est la femme qui initie l'action 

==L'argument de la nature==

Le champs lexical de la nature est tres présent (animaux végétaux ), elle propose de prendre la nature comme le chant d'une sorte d'expérience scientifique (essor des sciences naturelles avec Buffon). Cette expérience est perceptible dans le lexique et l'emploi de quatre propositions qui s'enchaînent dans le deuxième paragraphe. Le terme enfin induit l'idée d'une expérience chronologique et donc parfaitement ordonnée le rend toi à l'évidence, conduit à la conclusion, elle invite l'homme à procéder à un raisonnement inductif en tirant de l'observation de la nature une loi générale qu'elle affirme à la toute fin du paragraphe.

## 2° mouvement

Une nouvelle accumulation, cherche fouille et distingue reprend la même idée de l'expérimentation en y ajoutant l'objet de l'expérience :,, les sexes dans l'administration de la nature

Olympe de Gouges prouve ainsi sa supériorité alors que l'homme est ignorant et n'est pas capable de se soumettre aux principes généraux, elle montre qu'elle est capable de faire reposer sa réflexion sur une observation raisonnée et sur la logique.

La dernière phrase su paragraphe rappelle la conclusion qu'il faut tirer de l'expérience. Le parallélisme de construction est la répétition de partout indiqué qu'il s'agit bien d'une loi générale, le lexique de la coopération et de l'alliance (coopère, confondu, harmonieux) insiste sur cette idée d'une alliance des sexes et de leur complémentarité. Elle détruit la supériorité légitime.

Enfin l'éloge de la nature grâce à l'hyperbole chef d'œuvre immortel. Le terme administration insiste sur l'idée d'une nature bâtie sur les lois, il faut probablement

entendre que ces lois ont quelque chose de divin: le terme œuvre. La nature est l'oeuvre de dieu comme l'indique la périphrase créateur avec un C majuscule auquel elle prête une qualité : la sagesse, c'est une manière implicite dinsister sur lilleligimite de la domination masculine. On voit donc que Olympe de Gouges adopte le ton du défie mais tient aussi à ce que ces idées à l'homme et aux femmes qui la liront en ayant recours à la raison