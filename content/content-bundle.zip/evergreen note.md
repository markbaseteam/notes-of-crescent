---
enableLinks: true
---
[[organisation]] #🌲 

---
**Quand elle terminée** c'est une note à laquelle on pense qui est une idée et qu'on comprend comme un concept.
On la comprend avec les idées suivantes :
- [[Les evergreen notes doivent être axée pour un concept]]
- [[Les evergreen notes doivent être atomique]] 
- [[Les evergreen notes doivent être liées à ce qu'on pense]]
---
## Référence
[Evergreen notes - Andy Matuschak Notes - Obsidian Publish](https://publish.obsidian.md/andymatuschak/Andy+Matuschak/Evergreen+notes)
### En action
https://youtu.be/s43YzOt-1oE?t=4042