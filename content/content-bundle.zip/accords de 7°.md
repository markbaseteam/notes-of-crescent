# Les accords de 7°
ceci est l'état fondamental![[Pasted image 20220611092219.png]]
