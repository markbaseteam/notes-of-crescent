[[français]] [[bac_français]] [[figure de style]]
___
cas particulier de la [[Métonymie]] visant une proportion et de manière logique et rationnel ==par exemple== le fait qu'on ne peut pas manger une assiette