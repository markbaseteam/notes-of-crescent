[[philo]] #🌱 
___
L'utilitarisme se définit par le fait qu'on doit systématiquement donner le plus de plaisir à l'ensemble des individus. C'est pas une bonne philosophie mais elle est très commune ; puisque ce que va faire un individu avec cette doctrine simple c'est compter le plaisir d'un ensemble de personnes, pour qu'une fois une situation sociale terminée on ait pu optimiser le plaisir pour tous.

[[Quand une personne avec utilitarisme ne ressent pas le plaisir chez l'autre il est égocentrique]]