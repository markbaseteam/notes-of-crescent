[[français]] [[bac_français]] [[figure de style]]
___
2 termes opposés dans une phrase