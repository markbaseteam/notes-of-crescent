#☀️/cours
___
On appelle l'espérance mathématique de X :
$E[X]=x_1 \times p_1 +x_2 \times p_2 + ... +  