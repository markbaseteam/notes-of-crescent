#☀️ 
___
# Comment on mesure ?
La fréquence cardique se mesure en battement par minute (bpm)