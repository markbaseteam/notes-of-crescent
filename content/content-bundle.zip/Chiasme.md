[[français]] [[bac_français]] [[figure de style]]
___
forme de mots qui relie un groupe de mots à un autre sans forcément d'association