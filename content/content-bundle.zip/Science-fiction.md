⬜ Changer pour taskade ★
⬜ Rajouter to do liste pour Discord sur salon Discord ★
⬜ envoyer lien serveur discord à justine fox ★
⬜ serveur discord ? et créer un engouement social ★
        ✅ Mettre les liens du To Do et du Docxs sur discord
        ⬜ mettre des règles
        ⬜ désactiver notif salon général au moins
⬜ Faire en sorte que les années soient bien cohérentes ★
        ⬜ quelle année pour le texte de JM
        ⬜ Que fait la technologie en 2028 et que se passe t-il en 2032
⬜ Regardes les liens comme [[bases_inspirantes]] ★
        ⬜ https://vincent.callebaut.org/object/151223_aequorea/aequorea/projects
        ⬜ https://powerlisting-fandom-com.translate.goog/wiki/Technomagic?_x_tr_sl=en&_x_tr_tl=fr&_x_tr_hl=fr&_x_tr_pto=sc
        ⬜ https://powerlisting.fandom.com/wiki/Technomagic
        ⬜ https://mahouka--koukou--no--rettousei-fandom-com.translate.goog/wiki/Psion?_x_tr_sl=en&_x_tr_tl=fr&_x_tr_hl=fr&_x_tr_pto=sc
        ⬜ https://mahouka-koukou-no-rettousei.fandom.com/wiki/Psion
        ⬜ https://www.youtube.com/channel/UCP56Td-URBxm2y8cdXzdU1g/videos
        ⬜ https://www.businessinsider.fr/elon-musk-annonce-que-spacex-compte-extraire-du-co2-de-latmosphere-pour-lutiliser-comme-carburant-de-fusee-189322
⬜ Bienvenue ! (Tutoriel) ★
        ✅ cocher ce qui est vraiment fini (si problème envoyer un message)
        ✅ mettre un raccourci web de to do sur le téléphone (sauf si on a l'application sur le téléphone)
        ✅ aller dans la section affectées à moi pour voir les tâches attribuées
        ✅ Vous pouvez créer des tâches (les idées sont pas en trop)
        ⬜ présenter (petit quiz -> lien en note)
        ✅ merci
        Notes: https://forms.gle/FXABXqscSp7ziC6B9


vidéo sur habitudes : https://youtu.be/JepyqLcIpgM
⬜ Bienvenue ! (Tutoriel) ★
        ⬜ cocher ce qui est vraiment fini
        ⬜ mettre raccourci web To do téléphone
        ⬜ voir section affectées à moi
        ⬜ pouvoir de créer taches et affecter
        ⬜ télécharger To do sur pc
        ⬜ si problème envoyer un message
        ⬜ présenter (petit quiz -> lien en note)
        ⬜ merci :)
        Notes: https://forms.gle/FXABXqscSp7ziC6B9

vidéo sur habitudes : https://youtu.be/JepyqLcIpgM
⬜ Bienvenue ! (Tutoriel) ★
        ⬜ cocher ce qui est vraiment fini
        ⬜ mettre raccourci web To do téléphone
        ⬜ voir section affectées à moi
        ⬜ pouvoir de créer taches et affecter
        ⬜ télécharger To do sur pc
        ⬜ si problème envoyer un message
        ⬜ présenter (petit quiz -> lien en note)
        ⬜ merci :)
        Notes: https://forms.gle/FXABXqscSp7ziC6B9

vidéo sur habitudes : https://youtu.be/JepyqLcIpgM
⬜ Bienvenue ! (Tutoriel)
        ⬜ cocher ce qui est vraiment fini
        ⬜ mettre raccourci web To do téléphone
        ⬜ voir section affectées à moi
        ⬜ pouvoir de créer taches et affecter
        ⬜ télécharger To do sur pc
        ⬜ si problème envoyer un message
        ⬜ présenter (petit quiz -> lien en note)
        ⬜ merci :)
        Notes: https://forms.gle/FXABXqscSp7ziC6B9

vidéo sur habitudes : https://youtu.be/JepyqLcIpgM
⬜ Bienvenue ! (Tutoriel) ★
        ⬜ cocher ce qui est vraiment fini
        ⬜ mettre raccourci web To do téléphone
        ⬜ voir section affectées à moi
        ⬜ pouvoir de créer taches et affecter
        ⬜ télécharger To do sur pc
        ⬜ si problème envoyer un message
        ⬜ présenter (petit quiz -> lien en note)
        ⬜ merci :)
        Notes: https://forms.gle/FXABXqscSp7ziC6B9

vidéo sur habitudes : https://youtu.be/JepyqLcIpgM
⬜ Bienvenue ! (Tutoriel) ★
        ⬜ cocher ce qui est vraiment fini
        ⬜ avoir app "votre téléphone" et activer la version beta dans les paramètres de celle-ci
        ⬜ mettre raccourci web To do téléphone
        ⬜ voir section affectées à moi
        ⬜ pouvoir de créer taches et affecter
        ⬜ télécharger To do sur pc
        ⬜ si problème envoyer un message
        ⬜ présenter (petit quiz -> lien en note)
        ⬜ merci :)
        Notes: https://forms.gle/FXABXqscSp7ziC6B9

vidéo sur habitudes : https://youtu.be/JepyqLcIpgM
⬜ Avoir google docs pour entreprise ? ★
⬜ Représenter l'économie dans entre 2028 et 2032 ★
        ⬜ Nécessite cohérence de temps
        ⬜ Nécessite elle même que tout soit dans l'histoire
⬜ Chercher définition de l'ingénierie ★
⬜ Voir si Timothée rejoint la liste et dans ce cas lui donner le lien du docs pour qu'il puisse lire
⬜ voir dans quel ordre s'affiche les taches pour les autres
⬜ choisir support pour publier (il y a mon blog si ça vous dit)
⬜ représenter l'économie ★
        ⬜ Demander c'est quoi l'économie
        ⬜ par une autre organisation qui s'opposerait à l'autre ?
        ⬜ Blue economie soit vidéo Aberkane soit ma future explication
        ⬜ [[Blue-economie]]
⬜ raconter comment les hommes ont appris ça (flashback)
⬜ Histoire commentée sous forme de podcast ?
⬜ [[Blue-economie]]
⬜ Critiquer le " je pense donc je suis" (erreur la plus fondamentale)
⬜ Loi de Moore ?
⬜ Chercher def Hard science
⬜ Chercher def science fantasy
⬜ Enregistrer études milde
⬜ base philo James clear pour les autres ?
⬜ trouver le moment où l'on met les maths, les sciences dans le système scolaire
⬜ "loi universelle des stéréotypes"
⬜ [[philo]] créativité forcée par le système par contradiction
        Notes: exemple : faire étudier beaucoup de domaines au lycée qui sont censés nous éduquer alors qu'ils sont très restreints exemple : prof qui dit il faut qu'on lie les matières entres elles mais qui ne sait pas à quoi ça sert donc pas de sens donc confusion chez les élèves.
⬜ [[philo]] Vidéos Idriss Aberkane
        ✅ le Re checking https://youtu.be/M8W-9_40m98
        ✅ Insolence https://youtu.be/kuigb7GNIY0?t=1311
        ⬜ Idée d'Organisation https://youtu.be/VOrVa96gUb8
        ⬜ Elon Musk https://youtu.be/PaVgCwVNuZA
        Notes: Ce que je t'envoie c'est utile et j'ai déjà regardé(base pour philo). C'est pour votre bien !
⬜ [[philo]] Vidéos Idriss Aberkane
        ⬜ le Re checking https://youtu.be/M8W-9_40m98
        ⬜ Insolence https://youtu.be/kuigb7GNIY0?t=1311
        ⬜ Idée d'Organisation https://youtu.be/VOrVa96gUb8
        ⬜ Elon Musk https://youtu.be/PaVgCwVNuZA
        Notes: Ce que je t'envoie c'est utile et j'ai déjà regardé(base pour philo). C'est pour votre bien !
⬜ [[philo]] Vidéos Idriss Aberkane
        ⬜ le Re checking https://youtu.be/M8W-9_40m98
        ⬜ Insolence https://youtu.be/kuigb7GNIY0?t=1311
        ⬜ Idée d'Organisation https://youtu.be/VOrVa96gUb8
        ⬜ Elon Musk https://youtu.be/PaVgCwVNuZA
        Notes: Ce que je t'envoie c'est utile et j'ai déjà regardé(base pour philo). C'est pour votre bien !
⬜ [[philo]] Vidéos Idriss Aberkane
        ⬜ le Re checking https://youtu.be/M8W-9_40m98
        ⬜ Insolence https://youtu.be/kuigb7GNIY0?t=1311
        ⬜ Idée d'Organisation https://youtu.be/VOrVa96gUb8
        ⬜ Elon Musk https://youtu.be/PaVgCwVNuZA
        Notes: Ce que je t'envoie c'est utile et j'ai déjà regardé(base pour philo). C'est pour votre bien !
⬜ [[philo]] Vidéos Idriss Aberkane
        ⬜ le Re checking https://youtu.be/M8W-9_40m98
        ⬜ Insolence https://youtu.be/kuigb7GNIY0?t=1311
        ⬜ Idée d'Organisation https://youtu.be/VOrVa96gUb8
        ⬜ Elon Musk https://youtu.be/PaVgCwVNuZA
        Notes: Ce que je t'envoie c'est utile et j'ai déjà regardé(base pour philo). C'est pour votre bien !
⬜ [[philo]] Vidéos Idriss Aberkane
        ⬜ le Re checking https://youtu.be/M8W-9_40m98
        ⬜ Insolence https://youtu.be/kuigb7GNIY0?t=1311
        ⬜ Idée d'Organisation https://youtu.be/VOrVa96gUb8
        ⬜ Elon Musk https://youtu.be/PaVgCwVNuZA
        Notes: Ce que je t'envoie c'est utile et j'ai déjà regardé(base pour philo). C'est pour votre bien !
⬜ [[philo]] Vidéos Idriss Aberkane
        ⬜ le Re checking https://youtu.be/M8W-9_40m98
        ⬜ Insolence https://youtu.be/kuigb7GNIY0?t=1311
        ⬜ Idée d'Organisation https://youtu.be/VOrVa96gUb8
        ⬜ Elon Musk https://youtu.be/PaVgCwVNuZA
        Notes: Ce que je t'envoie c'est utile et j'ai déjà regardé(base pour philo). C'est pour votre bien !
⬜ parler de la liberté dans cet univers et son avantage
⬜ Résoudre le problème de quelqu'un de parfait qui remet toujours tout en question
⬜ Lien doc (commentateur)  https://docs.google.com/document/d/1UP8Q7jIvpIp4RIDpjyA1Zw3jrKlCm5ismNcc1HWNP0Y/edit?usp=drivesdk
⬜ Voir pour collaborer avec obsidian
⬜ loi de gaal