[[compositeur]]
___
Mozart aime les [[accords de 7°]] il était souvent incompris parce qu'il avait un [[le génie autistique]] 