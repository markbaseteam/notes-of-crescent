### I. La satyre de certaines pratiques médicales
#### 1.1 Le ridicule de la médecine
#### 1.2 Argan malade imaginaire est subjugué par la médecine
#### 1.3 Argan et Bérald la médecine comme source de conflit
### II. La force comique suscité par la caricature des médecins
#### 2.1 Les personnages de médecins un héritage comique de la comedia del'arte
#### 2.2 Le bas corporel : Un ressort comique
#### 2.3 La satyre du pédantisme et du manque de bon sens
### III. Jouer pour se divertir et pour comprendre
#### 3.1 La connivence mondaine avec le spectateur comme une façon de conjurer ses angoisses
#### 3.2 Une critique cachée des pouvoirs de la croyance ?
#### 3.3 Une réflexion philosophique sur la peur de la maladie et de la mort toujours d'actualité
Pour montrer que le texte parle toujours aux gens, que ça nous concerne ; il parle des travers de la nature humaine