#🌱 [[erreurs éducation national]] 
___

Les cours ne sont pas comme le concept que
[[Les evergreen notes doivent être atomique]]
mais ==utilise des propriétés== exemple : comment est-ce qu'on explique que des personnes qui ont des bonnes notes ont des bonnes notes dans toutes les matières ? Si on a des bonnes notes ça veut dire qu'on doit être passionner par ce que l'on fait mais être passionner par tout ce qu'il y a [[cours lycée]], ça n'a absolument aucun sens pourtant ces personnes sont contentes parce qu'elles sont en très grande majorité avec de l'[[utilitarisme]]. 

Pourquoi cela ? [[Les cours de l'éducation national ont oublié la réflexion individuelle]]