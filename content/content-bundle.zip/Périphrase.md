[[français]] [[bac_français]] [[figure de style]]
___
remplace un mot par sa signification