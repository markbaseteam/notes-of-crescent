---
dg-publish:true

---

[[Cours_Allemand]] #📥 
___
# Ashra
%%%%Ashra ist ein Grupp auf Rock. Ich mage diese Grupp weil es ist ein Musik ist rühe. Ich denke es ist ein gut Hintergrundmusik. Es ist sehr interessant obwohl es kein Text gibt. Manuel Göttsching ist bescheiden über seine Gruppe. Wie können Fellen sein Einschlag über das elektronische Musik. Er hat dazu beigetragen, etwas Konvergentes in der deutschen Musik zu schaffen mit andere Gruppen. %%%%
- [Midnight On Mars - YouTube](https://youtu.be/Yga14wTBQ4M?t=30)
# Jan Hammer
%%%%Jan Hammer ist ein Komposer und es macht Fusion-Jazz ([[Jazz fusion]]).
%%%%
- [Jan Hammer - Crockett's Theme (live by Kebu @ Dynamo) - YouTube](https://youtu.be/TRCQmNMOqUY?t=25)
